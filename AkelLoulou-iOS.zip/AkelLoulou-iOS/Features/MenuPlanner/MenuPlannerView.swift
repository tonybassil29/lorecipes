import SwiftUI

struct MenuPlannerView: View {
    @Bindable var viewModel: MenuPlannerViewModel
    @Binding var path: NavigationPath

    @State private var selectedDay: String?
    @State private var selectedMeal: MealType?
    @State private var showRecipePicker = false
    @State private var dayToDelete: String?
    @State private var mealToDelete: MealType?
    @State private var showCellDeleteConfirm = false
    @State private var checkedItems = Set<String>()

    private let days = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
    private let meals: [MealType] = [.midi, .gouter, .soir]
    private let adminTabOptions: [AdminTab] = [.site, .gallery, .manual]

    var body: some View {
        mainContent
            .navigationTitle("Menu")
            .navigationBarTitleDisplayMode(.inline)
                .sheet(isPresented: $viewModel.showShoppingList) { shoppingListSheet }
                .sheet(isPresented: $viewModel.showSimpleRecipeModal) { simpleRecipeSheet }
                .sheet(isPresented: $showRecipePicker) { recipePickerSheet }
                .alert("Supprimer cette recette ?", isPresented: $showCellDeleteConfirm) {
                    Button("Supprimer", role: .destructive) {
                        if let day = dayToDelete, let meal = mealToDelete {
                            viewModel.removeRecipeFromDay(day: day, meal: meal)
                        }
                    }
                    Button("Annuler", role: .cancel) {}
                }
                .alert("Erreur", isPresented: $viewModel.showError) {
                    Button("OK", role: .cancel) {}
                } message: {
                    Text(viewModel.errorMessage ?? "Une erreur est survenue")
                }
                .task {
                    await viewModel.loadRecipes()
                }
    }

    // MARK: - Main Content

    private var mainContent: some View {
        VStack(spacing: 0) {
            headerView
            alertsBanner
            if viewModel.isLoading {
                loadingView
            } else if viewModel.errorMessage != nil && viewModel.showError {
                errorView
            } else {
                plannerBody
            }
        }
        .background(Color.bgMain)
    }

    private var plannerBody: some View {
        HStack(spacing: 0) {
            sidebar
            Divider()
            gridArea
        }
    }

    // MARK: - Header

    private var headerView: some View {
        VStack(spacing: 8) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Construis ton Menu")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundStyle(.textMain)
                    Text("Planifie tes repas de la semaine")
                        .font(.subheadline)
                        .foregroundStyle(.textSecondary)
                }
                Spacer()
                HStack(spacing: 16) {
                    suggestButton
                    shoppingListButton
                    shareButton
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 12)
    }

    private var suggestButton: some View {
        Button {
            path.append(NavigationDestination.recipeSuggestion)
        } label: {
            Image(systemName: "lightbulb")
                .font(.title3)
                .foregroundStyle(.accentPrimary)
        }
        .accessibilityLabel("Suggérer une recette")
        .accessibilityHint("Proposer une nouvelle recette")
    }

    private var shoppingListButton: some View {
        Button {
            viewModel.showShoppingList = true
        } label: {
            Image(systemName: "cart")
                .font(.title3)
                .foregroundStyle(.accentPrimary)
        }
        .accessibilityLabel("Liste de courses")
        .accessibilityHint("Voir la liste de courses générée")
    }

    private var shareButton: some View {
        ShareLink(item: menuShareText) {
            Image(systemName: "square.and.arrow.up")
                .font(.title3)
                .foregroundStyle(.accentPrimary)
        }
        .accessibilityLabel("Partager le menu")
        .accessibilityHint("Partager le menu de la semaine")
    }

    private var menuShareText: String {
        var text = "📅 Menu de la semaine - Akel Loulou\n\n"
        for day in viewModel.weekMenu.days {
            text += "• \(day.day)\n"
            if let midi = day.midi { text += "  Midi: \(midi.title)\n" }
            if let gouter = day.gouter { text += "  Goûter: \(gouter.title)\n" }
            if let soir = day.soir { text += "  Soir: \(soir.title)\n" }
            text += "\n"
        }
        return text
    }

    // MARK: - Alerts

    private var alertsBanner: some View {
        Group {
            if !viewModel.alerts.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(viewModel.alerts, id: \.self) { alert in
                        HStack(spacing: 8) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundStyle(.accentGold)
                            Text(alert)
                                .font(.caption)
                                .foregroundStyle(.textMain)
                            Spacer()
                        }
                    }
                }
                .padding()
                .background(Color.accentGold.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.accentGold.opacity(0.3), lineWidth: 1)
                )
                .padding(.horizontal)
                .padding(.bottom, 8)
            }
        }
    }

    // MARK: - Loading / Error

    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.2)
            Text("Chargement des recettes...")
                .font(.subheadline)
                .foregroundStyle(.textSecondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }

    private var errorView: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundStyle(.accentGold)
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
                .font(.subheadline)
                .foregroundStyle(.textSecondary)
                .multilineTextAlignment(.center)
            Button("Réessayer") {
                Task {
                    await viewModel.loadRecipes()
                }
            }
            .shimmerButtonStyle()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }

    // MARK: - Sidebar

    private var sidebar: some View {
        VStack(spacing: 0) {
            searchBar
            if viewModel.isAdmin {
                adminTabs
            }
            recipeList
            if viewModel.isAdmin && viewModel.adminTab == .manual {
                addSimpleRecipeButton
            }
        }
        .frame(width: 280)
        .background(Color.bgMain)
    }

    private var searchBar: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.textPlaceholder)
            TextField("Rechercher", text: $viewModel.searchTerm)
                .foregroundStyle(.textMain)
            if !viewModel.searchTerm.isEmpty {
                Button {
                    viewModel.searchTerm = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.textPlaceholder)
                }
                .accessibilityLabel("Effacer la recherche")
            }
        }
        .padding(10)
        .background(Color.bgInput)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.borderInput, lineWidth: 1)
        )
        .padding(.horizontal)
        .padding(.vertical, 8)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Rechercher une recette")
    }

    private var adminTabs: some View {
        HStack(spacing: 8) {
            ForEach(adminTabOptions, id: \.self) { tab in
                Button {
                    viewModel.adminTab = tab
                } label: {
                    Text(tabLabel(tab))
                        .font(.caption)
                        .fontWeight(.medium)
                        .pillStyle(isActive: viewModel.adminTab == tab)
                }
                .accessibilityLabel("Onglet \(tabLabel(tab))")
            }
        }
        .padding(.horizontal)
        .padding(.bottom, 8)
    }

    private func tabLabel(_ tab: AdminTab) -> String {
        switch tab {
        case .site: return "Site"
        case .gallery: return "Galerie"
        case .manual: return "Manuels"
        }
    }

    private var recipeList: some View {
        ScrollView {
            LazyVStack(spacing: 8) {
                if viewModel.isAdmin && viewModel.adminTab == .gallery {
                    if viewModel.filteredGalleryImages.isEmpty {
                        emptyListView(message: "Aucune image dans la galerie")
                    } else {
                        ForEach(viewModel.filteredGalleryImages) { item in
                            sidebarGalleryRow(item: item)
                        }
                    }
                } else {
                    if viewModel.activeRecipes.isEmpty {
                        emptyListView(message: "Aucune recette trouvée")
                    } else {
                        ForEach(viewModel.activeRecipes) { recipe in
                            sidebarRecipeRow(recipe: recipe)
                        }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
        }
    }

    private func sidebarRecipeRow(recipe: Recipe) -> some View {
        HStack(spacing: 12) {
            recipeThumbnail(recipe: recipe, size: 48)
            VStack(alignment: .leading, spacing: 2) {
                Text(recipe.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundStyle(.textMain)
                    .lineLimit(1)
                Text(recipe.category)
                    .font(.caption2)
                    .foregroundStyle(.textMuted)
                    .textCase(.uppercase)
            }
            Spacer()
            if viewModel.isAdmin && viewModel.adminTab == .manual {
                Button {
                    Task {
                        await viewModel.deleteSimpleRecipe(recipe)
                    }
                } label: {
                    Image(systemName: "trash")
                        .foregroundStyle(.red)
                }
                .accessibilityLabel("Supprimer \(recipe.title)")
            }
        }
        .padding(8)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel(recipe.title)
    }

    private func sidebarGalleryRow(item: GalleryImage) -> some View {
        HStack(spacing: 12) {
            if let url = URL(string: item.url) {
                AsyncImageView(url: url)
                    .frame(width: 48, height: 48)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                placeholderImage(size: 48)
            }
            Text(item.name ?? "Image")
                .font(.subheadline)
                .foregroundStyle(.textMain)
                .lineLimit(1)
            Spacer()
        }
        .padding(8)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .accessibilityLabel(item.name ?? "Image sans nom")
    }

    private var addSimpleRecipeButton: some View {
        Button {
            viewModel.showSimpleRecipeModal = true
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "plus.circle.fill")
                Text("Recette minute")
            }
            .font(.subheadline)
            .fontWeight(.medium)
            .foregroundStyle(.accentPrimary)
            .padding(.vertical, 10)
            .frame(maxWidth: .infinity)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.accentPrimary, lineWidth: 1)
            )
        }
        .padding(.horizontal)
        .padding(.bottom, 8)
        .accessibilityLabel("Ajouter une recette minute")
    }

    private func emptyListView(message: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.title2)
                .foregroundStyle(.textPlaceholder)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.textSecondary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity)
    }

    // MARK: - Grid

    private var gridArea: some View {
        ScrollView(.horizontal) {
            mealGrid
        }
        .background(Color.bgMain)
    }

    private var mealGrid: some View {
        Grid(horizontalSpacing: 8, verticalSpacing: 8) {
            GridRow {
                Text("")
                    .frame(width: 60)
                ForEach(days, id: \.self) { day in
                    Text(day.prefix(3))
                        .font(.caption)
                        .fontWeight(.semibold)
                        .frame(width: 100)
                        .foregroundStyle(.textSecondary)
                }
            }
            ForEach(meals, id: \.self) { meal in
                GridRow {
                    Text(meal.displayName)
                        .font(.caption)
                        .fontWeight(.medium)
                        .frame(width: 60)
                        .foregroundStyle(.textSecondary)
                    ForEach(days, id: \.self) { day in
                        gridCell(day: day, meal: meal)
                            .frame(width: 100, height: 100)
                    }
                }
            }
        }
        .padding(12)
    }

    private func gridCell(day: String, meal: MealType) -> some View {
        let recipe = recipeFor(day: day, meal: meal)
        return Group {
            if let recipe = recipe {
                filledCell(recipe: recipe, day: day, meal: meal)
            } else {
                emptyCell(day: day, meal: meal)
            }
        }
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.borderCard, lineWidth: 1)
        )
    }

    private func filledCell(recipe: Recipe, day: String, meal: MealType) -> some View {
        VStack(spacing: 4) {
            recipeThumbnail(recipe: recipe, size: 50)
            Text(recipe.title)
                .font(.caption2)
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .foregroundStyle(.textMain)
                .padding(.horizontal, 4)
        }
        .padding(4)
        .contentShape(Rectangle())
        .onTapGesture {
            dayToDelete = day
            mealToDelete = meal
            showCellDeleteConfirm = true
        }
        .accessibilityLabel("Recette \(recipe.title) pour \(day) \(meal.displayName)")
        .accessibilityHint("Double-tap pour supprimer")
    }

    private func emptyCell(day: String, meal: MealType) -> some View {
        VStack {
            Image(systemName: "plus")
                .font(.title2)
                .foregroundStyle(.textPlaceholder)
        }
        .contentShape(Rectangle())
        .onTapGesture {
            selectedDay = day
            selectedMeal = meal
            showRecipePicker = true
        }
        .accessibilityLabel("Ajouter une recette pour \(day) \(meal.displayName)")
        .accessibilityHint("Double-tap pour choisir une recette")
    }

    // MARK: - Sheets

    private var recipePickerSheet: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 12) {
                    if viewModel.isAdmin && viewModel.adminTab == .gallery {
                        if viewModel.filteredGalleryImages.isEmpty {
                            emptyListView(message: "Aucune image disponible")
                        } else {
                            ForEach(viewModel.filteredGalleryImages) { item in
                                Button {
                                    addGalleryItemToDay(item: item)
                                } label: {
                                    pickerGalleryRow(item: item)
                                }
                            }
                        }
                    } else {
                        if viewModel.activeRecipes.isEmpty {
                            emptyListView(message: "Aucune recette disponible")
                        } else {
                            ForEach(viewModel.activeRecipes) { recipe in
                                Button {
                                    addRecipeToDay(recipe: recipe)
                                } label: {
                                    pickerRecipeRow(recipe: recipe)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Choisir une recette")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Annuler") {
                        showRecipePicker = false
                    }
                }
            }
        }
    }

    private var shoppingListSheet: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 16) {
                    if !viewModel.shoppingList.recipesToMake.isEmpty {
                        recipesToMakeSection
                    }
                    ForEach(viewModel.shoppingList.grouped.keys.sorted(), id: \.self) { category in
                        if let items = viewModel.shoppingList.grouped[category] {
                            shoppingCategorySection(category: category, items: items)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Liste de Courses")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Fermer") {
                        viewModel.showShoppingList = false
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                copyButton
            }
        }
    }

    private var simpleRecipeSheet: some View {
        NavigationStack {
            Form {
                Section("Nom") {
                    TextField("Nom de la recette", text: $viewModel.simpleRecipeName)
                }
                Section("Ingrédients (un par ligne)") {
                    TextEditor(text: $viewModel.simpleRecipeIngredients)
                        .frame(minHeight: 100)
                }
                Section("Image URL (optionnel)") {
                    TextField("URL de l'image", text: $viewModel.simpleRecipeImageUrl)
                }
            }
            .navigationTitle("Recette Minute")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annuler") {
                        viewModel.showSimpleRecipeModal = false
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Sauvegarder") {
                        Task {
                            await viewModel.addSimpleRecipe()
                        }
                    }
                    .disabled(viewModel.simpleRecipeName.isBlank || viewModel.simpleRecipeIngredients.isBlank || viewModel.isSavingSimple)
                }
            }
        }
    }

    // MARK: - Shopping List Sections

    private var recipesToMakeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Recettes à préparer")
                .font(.headline)
                .foregroundStyle(.textMain)
            ForEach(Array(viewModel.shoppingList.recipesToMake).sorted(), id: \.self) { recipe in
                HStack(spacing: 8) {
                    Image(systemName: "chef.hat")
                        .foregroundStyle(.accentPrimary)
                    Text(recipe)
                        .font(.subheadline)
                        .foregroundStyle(.textSecondary)
                }
            }
        }
        .padding()
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.borderCard, lineWidth: 1)
        )
    }

    private func shoppingCategorySection(category: String, items: [String: ShoppingItem]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(category)
                .font(.headline)
                .foregroundStyle(.textMain)
            ForEach(items.values.sorted(by: { $0.name < $1.name }), id: \.name) { item in
                shoppingItemRow(item: item)
            }
        }
        .padding()
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.borderCard, lineWidth: 1)
        )
    }

    private func shoppingItemRow(item: ShoppingItem) -> some View {
        HStack(spacing: 12) {
            Image(systemName: checkedItems.contains(item.name) ? "checkmark.square.fill" : "square")
                .foregroundStyle(checkedItems.contains(item.name) ? .accentPrimary : .textPlaceholder)
                .onTapGesture {
                    toggleChecked(item: item)
                }
                .accessibilityLabel(checkedItems.contains(item.name) ? "Décocher \(item.name)" : "Cocher \(item.name)")

            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.subheadline)
                    .foregroundStyle(checkedItems.contains(item.name) ? .textMuted : .textMain)
                    .strikethrough(checkedItems.contains(item.name))
                if item.qty > 0 {
                    Text("\(item.qty, specifier: "%.1f") \(item.unit)")
                        .font(.caption)
                        .foregroundStyle(.textMuted)
                }
            }
            Spacer()
        }
        .padding(.vertical, 4)
    }

    private var copyButton: some View {
        Button {
            viewModel.copyShoppingList()
        } label: {
            HStack {
                Image(systemName: "doc.on.doc")
                Text("Copier la liste")
            }
            .font(.subheadline)
            .fontWeight(.semibold)
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.accentPrimary)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .padding()
        .background(Color.bgMain)
        .accessibilityLabel("Copier la liste de courses dans le presse-papier")
    }

    // MARK: - Picker Rows

    private func pickerRecipeRow(recipe: Recipe) -> some View {
        HStack(spacing: 12) {
            recipeThumbnail(recipe: recipe, size: 40)
            Text(recipe.title)
                .font(.subheadline)
                .foregroundStyle(.textMain)
                .lineLimit(1)
            Spacer()
        }
        .padding(8)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .contentShape(Rectangle())
    }

    private func pickerGalleryRow(item: GalleryImage) -> some View {
        HStack(spacing: 12) {
            if let url = URL(string: item.url) {
                AsyncImageView(url: url)
                    .frame(width: 40, height: 40)
                    .clipShape(RoundedRectangle(cornerRadius: 6))
            } else {
                placeholderImage(size: 40)
            }
            Text(item.name ?? "Image")
                .font(.subheadline)
                .foregroundStyle(.textMain)
                .lineLimit(1)
            Spacer()
        }
        .padding(8)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .contentShape(Rectangle())
    }

    // MARK: - Helpers

    private func recipeFor(day: String, meal: MealType) -> Recipe? {
        guard let dayMenu = viewModel.weekMenu.days.first(where: { $0.day == day }) else { return nil }
        switch meal {
        case .midi: return dayMenu.midi
        case .gouter: return dayMenu.gouter
        case .soir: return dayMenu.soir
        }
    }

    private func addRecipeToDay(recipe: Recipe) {
        guard let day = selectedDay, let meal = selectedMeal else { return }
        viewModel.addRecipeToDay(recipe, day: day, meal: meal)
        showRecipePicker = false
    }

    private func addGalleryItemToDay(item: GalleryImage) {
        guard let day = selectedDay, let meal = selectedMeal else { return }
        let recipe = Recipe(
            id: item.id,
            title: item.name ?? "Image",
            description: nil,
            ingredients: [],
            spices: nil,
            equipment: nil,
            instructions: "",
            category: "gallery",
            servings: 2,
            showPortions: false,
            imageUrl: item.url,
            country: nil,
            hidden: false,
            isSecondary: false,
            isFavorite: false,
            relatedRecipes: nil,
            createdAt: nil,
            updatedAt: nil
        )
        viewModel.addRecipeToDay(recipe, day: day, meal: meal)
        showRecipePicker = false
    }

    private func toggleChecked(item: ShoppingItem) {
        if checkedItems.contains(item.name) {
            checkedItems.remove(item.name)
        } else {
            checkedItems.insert(item.name)
        }
    }

    private func recipeThumbnail(recipe: Recipe, size: CGFloat) -> some View {
        Group {
            if let imageUrl = recipe.imageUrl, let url = URL(string: imageUrl) {
                AsyncImageView(url: url)
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                placeholderImage(size: size)
            }
        }
    }

    private func placeholderImage(size: CGFloat) -> some View {
        Color.bgHover
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(
                Image(systemName: "photo")
                    .foregroundStyle(.textPlaceholder)
            )
    }
}

#Preview {
    MenuPlannerView(viewModel: MenuPlannerViewModel(), path: .constant(NavigationPath()))
}
