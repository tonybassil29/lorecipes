import Foundation

@Observable
final class MenuPlannerViewModel {
    var weekMenu = WeekMenu()
    var recipes: [Recipe] = []
    var isLoading = false
    var errorMessage: String?
    var showError = false
    var searchTerm = ""
    var isAdmin = false
    var showShoppingList = false
    var showSimpleRecipeModal = false
    var showDeleteConfirm = false
    var recipeToDelete: Recipe?
    var adminTab: AdminTab = .site
    var galleryItems: [GalleryImage] = []
    var simpleRecipeName = ""
    var simpleRecipeIngredients = ""
    var simpleRecipeImageUrl = ""
    var isSavingSimple = false

    private let supabase = SupabaseService.shared
    private let userDefaults = UserDefaults.standard
    private let menuKey = "menu_planner_week"

    var filteredSiteRecipes: [Recipe] {
        recipes.filter { r in
            if r.hidden == true || r.isSecondary == true { return false }
            if r.category == "menu_only" { return false }
            return matchesSearch(r)
        }
    }

    var filteredManualRecipes: [Recipe] {
        recipes.filter { r in
            r.category == "menu_only" && matchesSearch(r)
        }
    }

    var filteredGalleryImages: [GalleryImage] {
        galleryItems.filter { g in
            if searchTerm.isBlank { return true }
            return (g.name ?? "").normalizedForSearch().contains(searchTerm.normalizedForSearch())
        }
    }

    var activeRecipes: [Recipe] {
        if !isAdmin { return filteredSiteRecipes }
        switch adminTab {
        case .site: return filteredSiteRecipes
        case .manual: return filteredManualRecipes
        case .gallery: return []
        }
    }

    var alerts: [String] {
        var result: [String] = []
        var dessertCount = 0
        var emptyDinners = 0
        var seenPlats = Set<String>()
        var duplicateFound = false

        for day in weekMenu.days {
            if day.soir == nil { emptyDinners += 1 }
            for meal in [day.midi, day.gouter, day.soir] {
                if let recipe = meal {
                    if recipe.category == "dessert" { dessertCount += 1 }
                    if recipe.category == "plat" {
                        let id = recipe.id ?? recipe.title
                        if seenPlats.contains(id) && !duplicateFound {
                            result.append("Tu as mis \"\(recipe.title)\" plusieurs fois !")
                            duplicateFound = true
                        }
                        seenPlats.insert(id)
                    }
                }
            }
        }
        if dessertCount > 3 { result.append("Beaucoup de desserts cette semaine 🍰") }
        if emptyDinners > 5 { result.append("Quelques soirs vides cette semaine") }
        return result
    }

    var shoppingList: ShoppingList {
        var list: [String: ShoppingItem] = [:]
        var recipesToMake = Set<String>()
        let recipeMap = Dictionary(grouping: recipes, by: { $0.title.lowercased() })

        func addIngredient(_ ing: String) {
            let parts = ing.split(separator: "||").map { String($0).trimmingCharacters(in: .whitespaces) }
            let main = parts.first ?? ing
            let sub = parts.count > 1 ? parts[1] : nil

            let parsed = parseIngredient(main)
            let key = sub != nil ? "\(parsed.name) (ou \(parseIngredient(sub!).name))" : parsed.name

            if let existing = list[key] {
                list[key] = ShoppingItem(
                    name: key,
                    qty: existing.qty + parsed.qty,
                    unit: existing.unit,
                    original: existing.original + [ing],
                    category: existing.category,
                    isChecked: existing.isChecked
                )
            } else {
                list[key] = ShoppingItem(
                    name: key,
                    qty: parsed.qty,
                    unit: parsed.unit,
                    original: [ing],
                    category: categoryForIngredient(parsed.name),
                    isChecked: false
                )
            }
        }

        for day in weekMenu.days {
            for meal in [day.midi, day.gouter, day.soir] {
                if let recipe = meal {
                    for ing in recipe.ingredients {
                        let parsed = parseIngredient(ing)
                        if let subRecipes = recipeMap[parsed.name], let subRecipe = subRecipes.first {
                            recipesToMake.insert(subRecipe.title)
                            for subIng in subRecipe.ingredients {
                                addIngredient(subIng)
                            }
                        } else {
                            addIngredient(ing)
                        }
                    }
                }
            }
        }

        var grouped: [String: [String: ShoppingItem]] = [:]
        for (_, item) in list {
            if item.name == "eau" || item.name.contains("eau ") { continue }
            grouped[item.category, default: [:]][item.name] = item
        }
        return ShoppingList(grouped: grouped, recipesToMake: recipesToMake)
    }

    func loadRecipes() async {
        isLoading = true
        do {
            recipes = try await supabase.fetchRecipes(includeHidden: true, includeSecondary: true)
            if let data = userDefaults.data(forKey: menuKey) {
                weekMenu = try JSONDecoder().decode(WeekMenu.self, from: data)
            }
            if isAdmin {
                galleryItems = try await supabase.fetchGalleryImages()
            }
        } catch {
            errorMessage = "Erreur: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func addRecipeToDay(_ recipe: Recipe, day: String, meal: MealType) {
        if let idx = weekMenu.days.firstIndex(where: { $0.day == day }) {
            switch meal {
            case .midi: weekMenu.days[idx].midi = recipe
            case .gouter: weekMenu.days[idx].gouter = recipe
            case .soir: weekMenu.days[idx].soir = recipe
            }
            saveWeekMenu()
        }
    }

    func removeRecipeFromDay(day: String, meal: MealType) {
        if let idx = weekMenu.days.firstIndex(where: { $0.day == day }) {
            switch meal {
            case .midi: weekMenu.days[idx].midi = nil
            case .gouter: weekMenu.days[idx].gouter = nil
            case .soir: weekMenu.days[idx].soir = nil
            }
            saveWeekMenu()
        }
    }

    func saveWeekMenu() {
        do {
            let data = try JSONEncoder().encode(weekMenu)
            userDefaults.set(data, forKey: menuKey)
        } catch {
            print("Error saving week menu: \(error)")
        }
    }

    func copyShoppingList() {
        var text = "🛒 Ma Liste de Courses Akel Loulou\n\n"
        if !shoppingList.recipesToMake.isEmpty {
            text += "🍳 Recettes à préparer :\n"
            for r in shoppingList.recipesToMake { text += "• \(r)\n" }
            text += "\n"
        }
        for (category, items) in shoppingList.grouped {
            text += "--- \(category) ---\n"
            for (_, item) in items {
                text += "☐ \(item.name)\n"
            }
            text += "\n"
        }
        UIPasteboard.general.string = text
    }

    func addSimpleRecipe() async {
        guard !simpleRecipeName.isBlank, !simpleRecipeIngredients.isBlank else { return }
        isSavingSimple = true
        let newRecipe = Recipe(
            id: nil,
            title: simpleRecipeName,
            description: nil,
            ingredients: simpleRecipeIngredients.split(separator: "\n").map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty },
            spices: nil,
            equipment: nil,
            instructions: "",
            category: "menu_only",
            servings: 2,
            showPortions: false,
            imageUrl: simpleRecipeImageUrl.isBlank ? nil : simpleRecipeImageUrl,
            country: nil,
            hidden: false,
            isSecondary: false,
            isFavorite: false,
            relatedRecipes: nil,
            createdAt: nil,
            updatedAt: nil
        )
        do {
            _ = try await supabase.addRecipe(newRecipe)
            await loadRecipes()
            showSimpleRecipeModal = false
            simpleRecipeName = ""
            simpleRecipeIngredients = ""
            simpleRecipeImageUrl = ""
        } catch {
            errorMessage = "Erreur: \(error.localizedDescription)"
            showError = true
        }
        isSavingSimple = false
    }

    func deleteSimpleRecipe(_ recipe: Recipe) async {
        guard let id = recipe.id else { return }
        do {
            try await supabase.deleteRecipe(id: id)
            await loadRecipes()
        } catch {
            errorMessage = "Erreur: \(error.localizedDescription)"
            showError = true
        }
    }

    private func matchesSearch(_ recipe: Recipe) -> Bool {
        if searchTerm.isBlank { return true }
        let query = searchTerm.normalizedForSearch()
        return recipe.title.normalizedForSearch().contains(query)
            || recipe.ingredients.contains { $0.normalizedForSearch().contains(query) }
            || (recipe.description ?? "").normalizedForSearch().contains(query)
            || (recipe.country ?? "").normalizedForSearch().contains(query)
    }

    private func parseIngredient(_ ing: String) -> ParsedIngredient {
        let pattern = "^([\\d.,/]+)?\\s*(g|kg|ml|cl|l|càs|càc|cuillère|pincée|verres?|tasses?|sachets?|gousses?|tranches?|boîtes?|cc|cs)?\\s*(?:de\\s+|d'|s\\s+de\\s+)?(.*)$"
        if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive),
           let match = regex.firstMatch(in: ing, options: [], range: NSRange(location: 0, length: ing.utf16.count)) {
            let qtyRange = match.range(at: 1)
            let unitRange = match.range(at: 2)
            let nameRange = match.range(at: 3)
            let qtyStr = qtyRange.location != NSNotFound ? (Range(qtyRange, in: ing).map { String(ing[$0]) } ?? "") : ""
            let unit = unitRange.location != NSNotFound ? (Range(unitRange, in: ing).map { String(ing[$0]) } ?? "") : ""
            let name = nameRange.location != NSNotFound ? (Range(nameRange, in: ing).map { String(ing[$0]) } ?? ing) : ing
            let qty = Double(qtyStr.replacingOccurrences(of: ",", with: ".")) ?? 0
            return ParsedIngredient(qty: qty, unit: unit.lowercased(), name: cleanName(name))
        }
        return ParsedIngredient(qty: 0, unit: "", name: cleanName(ing))
    }

    private func cleanName(_ name: String) -> String {
        let exceptions = ["pois", "ananas", "maïs", "mais", "radis", "jus", "cassis", "souris", "épices", "herbes", "riz"]
        let lower = name.lowercased().trimmingCharacters(in: .whitespaces)
        if lower.hasSuffix("s") && !exceptions.contains(lower) {
            return String(lower.dropLast())
        }
        return lower
    }

    private func categoryForIngredient(_ name: String) -> String {
        let categories: [(String, [String])] = [
            ("Produits laitiers 🥛", ["lait", "beurre", "crème", "fromage", "yaourt", "oeuf", "oeufs", "mascarpone", "mozzarella", "parmesan", "gruyère", "comté", "skyr", "petit suisse", "ricotta", "feta", "emmental", "cheddar", "gorgonzola", "roquefort", "camembert", "brie", "chèvre"]),
            ("Épicerie sèche 🌾", ["farine", "sucre", "sel", "poivre", "huile", "levure", "pâtes", "riz", "cacao", "chocolat", "vanille", "amande", "noix", "miel", "vinaigre", "moutarde", "bouillon", "épices", "curry", "cumin", "paprika", "semoule", "lentilles", "pois chiches", "haricots secs", "quinoa", "boulgour", "café", "thé", "biscuit", "gâteau", "confiture", "pâte à tartiner", "céréales", "muesli", "flocons d'avoine", "maïzena", "fécule", "chapelure", "sauce soja", "ketchup", "mayonnaise", "sauce tomate", "coulis", "concentré de tomate", "pesto", "tapenade", "olives", "cornichons", "câpres"]),
            ("Viandes & poissons 🥩", ["poulet", "boeuf", "saumon", "poisson", "viande", "jambon", "porc", "veau", "crevette", "lardon", "thon", "saucisse", "chorizo", "dinde", "canard", "agneau", "merguez", "chipolata", "bacon", "pancetta", "sardine", "maquereau", "cabillaud", "colin", "truite", "moule", "huître", "calamar", "encornet", "crabe", "surimi"]),
            ("Fruits & légumes 🥦", ["tomate", "carotte", "oignon", "pomme", "citron", "banane", "poivron", "ail", "salade", "pomme de terre", "courgette", "aubergine", "fraise", "framboise", "poireau", "champignon", "épinard", "avocat", "brocoli", "chou", "haricot", "orange", "clémentine", "mandarine", "pamplemousse", "kiwi", "poire", "pêche", "abricot", "nectarine", "prune", "cerise", "melon", "pastèque", "raisin", "ananas", "mangue", "fruit de la passion", "grenade", "figue", "datte", "pruneau", "raisin sec", "abricot sec", "cranberry", "baie de goji", "myrtille", "mûre", "cassis", "groseille", "navet", "radis", "céleri", "fenouil", "asperge", "artichaut", "petit pois", "fève", "maïs", "potiron", "potimarron", "butternut", "patate douce", "topinambour", "panais", "betterave", "concombre", "mâche", "roquette", "endive", "cresson", "pourpier", "pissenlit", "échalote", "ciboulette", "persil", "coriandre", "menthe", "basilic", "thym", "romarin", "laurier", "sauge", "aneth", "estragon", "cerfeuil"]),
            ("Boulangerie 🥖", ["pain", "baguette", "croissant", "pain au chocolat", "brioche", "biscotte", "pain de mie", "pain burger", "pain pita", "tortilla", "wrap", "pâte feuilletée", "pâte brisée", "pâte à pizza"]),
            ("Surgelés ❄️", ["glace", "sorbet", "glaçon", "frites", "légumes surgelés", "poisson pané", "pizza surgelée", "plat préparé surgelé"]),
            ("Boissons 🧃", ["eau", "jus", "soda", "sirop", "bière", "vin", "alcool", "cidre", "champagne", "lait de soja", "lait d'amande", "lait d'avoine", "lait de coco", "lait de riz"]),
        ]
        for (cat, keywords) in categories {
            if keywords.contains(where: { name.contains($0) }) {
                return cat
            }
        }
        return "Autres 🧴"
    }
}

struct ShoppingList: Sendable {
    var grouped: [String: [String: ShoppingItem]]
    var recipesToMake: Set<String>
}

struct ShoppingItem: Sendable {
    var name: String
    var qty: Double
    var unit: String
    var original: [String]
    var category: String
    var isChecked: Bool
}

struct ParsedIngredient: Sendable {
    var qty: Double
    var unit: String
    var name: String
}
