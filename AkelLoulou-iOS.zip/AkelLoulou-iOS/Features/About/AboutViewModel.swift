import SwiftUI
import UIKit

@Observable
final class AboutViewModel {
    var data = AboutSettings()
    var isLoading = false
    var isEditing = false
    var isAdmin = false
    var recipesCount = 0
    var errorMessage: String?
    var showError = false

    private let settings = SettingsService.shared
    private let cloudinary = CloudinaryService.shared
    private let supabase = SupabaseService.shared

    func loadData() async {
        isLoading = true
        errorMessage = nil
        showError = false
        do {
            data = await settings.loadAboutSettings()
            let recipes = try await supabase.fetchRecipes(includeHidden: isAdmin, includeSecondary: isAdmin)
            recipesCount = recipes.filter(\.isMainRecipe).count
        } catch {
            errorMessage = "Erreur de chargement: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func saveData() async {
        isLoading = true
        errorMessage = nil
        showError = false
        do {
            var appSettings = AppSettings()
            appSettings.about = data
            try await settings.saveSettings(appSettings)
            isEditing = false
        } catch {
            errorMessage = "Erreur de sauvegarde: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func handleImageUpload(_ image: UIImage) async {
        isLoading = true
        errorMessage = nil
        showError = false
        do {
            let url = try await cloudinary.uploadImage(image)
            data.imageUrl = url
        } catch {
            errorMessage = "Erreur d'upload: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }
}
