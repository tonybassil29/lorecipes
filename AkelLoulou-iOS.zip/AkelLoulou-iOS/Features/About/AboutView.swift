import SwiftUI
import PhotosUI

struct AboutView: View {
    @Bindable var viewModel: AboutViewModel
    var isAdmin: Bool

    @State private var selectedItem: PhotosPickerItem?

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                if viewModel.isLoading && viewModel.data.titlePart1.isEmpty {
                    ProgressView()
                        .padding(.top, 40)
                } else if viewModel.isEditing {
                    editForm
                } else {
                    profileImageSection
                    titleSection
                    descriptionSection
                    statsSection
                    storySection
                    quoteSection
                }
            }
        }
        .background(Color.bgMain)
        .navigationTitle("À propos")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            if isAdmin {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(viewModel.isEditing ? "Enregistrer" : "Modifier") {
                        if viewModel.isEditing {
                            Task {
                                await viewModel.saveData()
                            }
                        } else {
                            viewModel.isEditing = true
                        }
                    }
                    .accessible(label: viewModel.isEditing ? "Enregistrer les modifications" : "Modifier le profil")
                }
            }
        }
        .task {
            await viewModel.loadData()
        }
        .alert("Erreur", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
        }
    }

    // MARK: - Display Sections

    private var profileImageSection: some View {
        VStack(spacing: 16) {
            AsyncImageView(url: URL(string: viewModel.data.imageUrl))
                .frame(height: 320)
                .clipped()

            Text(viewModel.data.badgeText)
                .font(.system(size: 11, weight: .medium))
                .tracking(0.32)
                .textCase(.uppercase)
                .foregroundStyle(.accentPrimary)
        }
        .padding(.top, 8)
    }

    private var titleSection: some View {
        HStack(alignment: .firstTextBaseline, spacing: 4) {
            Text(viewModel.data.titlePart1)
                .font(.system(size: 42, weight: .medium, design: .serif))
                .italic()
            Text(viewModel.data.titleHighlight)
                .font(.system(size: 42, weight: .medium, design: .serif))
                .italic()
                .gradientText()
            Text(viewModel.data.titlePart2)
                .font(.system(size: 42, weight: .medium, design: .serif))
                .italic()
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
    }

    private var descriptionSection: some View {
        Text(viewModel.data.description)
            .font(.system(size: 15))
            .foregroundStyle(.textSecondary)
            .lineSpacing(4)
            .padding(.horizontal, 20)
            .padding(.top, 12)
    }

    private var statsSection: some View {
        HStack(spacing: 20) {
            StatItem(value: "\(viewModel.recipesCount)", label: viewModel.data.stat1Label)
            Divider().frame(height: 40)
            StatItem(value: viewModel.data.stat2Num, label: viewModel.data.stat2Label)
            Divider().frame(height: 40)
            StatItem(value: viewModel.data.stat3Num, label: viewModel.data.stat3Label)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 24)
    }

    private var storySection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(viewModel.data.storyTitle)
                .font(.system(size: 11, weight: .medium))
                .tracking(0.32)
                .textCase(.uppercase)
                .foregroundStyle(.accentPrimary)

            BoldMarkdownText(text: viewModel.data.storyText)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 24)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .padding(.horizontal, 20)
    }

    private var quoteSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(viewModel.data.quote)
                .font(.system(size: 18, weight: .medium, design: .serif))
                .italic()
                .foregroundStyle(.textMain)
                .lineSpacing(4)

            Text(viewModel.data.quoteAuthor)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(.accentPrimary)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 24)
        .padding(.bottom, 32)
    }

    // MARK: - Edit Form

    private var editForm: some View {
        VStack(spacing: 20) {
            editImageSection

            Group {
                TextField("Badge", text: $viewModel.data.badgeText)
                TextField("Titre partie 1", text: $viewModel.data.titlePart1)
                TextField("Titre highlight", text: $viewModel.data.titleHighlight)
                TextField("Titre partie 2", text: $viewModel.data.titlePart2)
                TextField("Description", text: $viewModel.data.description, axis: .vertical)
            }
            .textFieldStyle(.roundedBorder)

            HStack(spacing: 12) {
                VStack(spacing: 4) {
                    TextField("Stat 1 nombre", text: $viewModel.data.stat1Num)
                    TextField("Stat 1 label", text: $viewModel.data.stat1Label)
                }
                VStack(spacing: 4) {
                    TextField("Stat 2 nombre", text: $viewModel.data.stat2Num)
                    TextField("Stat 2 label", text: $viewModel.data.stat2Label)
                }
                VStack(spacing: 4) {
                    TextField("Stat 3 nombre", text: $viewModel.data.stat3Num)
                    TextField("Stat 3 label", text: $viewModel.data.stat3Label)
                }
            }

            TextField("Titre histoire", text: $viewModel.data.storyTitle)

            TextEditor(text: $viewModel.data.storyText)
                .frame(minHeight: 150)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.borderInput, lineWidth: 1)
                )

            TextField("Citation", text: $viewModel.data.quote, axis: .vertical)
            TextField("Auteur citation", text: $viewModel.data.quoteAuthor)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 24)
    }

    private var editImageSection: some View {
        VStack(spacing: 12) {
            AsyncImageView(url: URL(string: viewModel.data.imageUrl))
                .frame(height: 200)
                .clipped()
                .clipShape(RoundedRectangle(cornerRadius: 12))

            PhotosPicker(selection: $selectedItem, matching: .images) {
                Label("Changer l'image", systemImage: "photo")
                    .shimmerButtonStyle()
            }
            .accessible(label: "Changer l'image de profil")
            .onChange(of: selectedItem) { _, newValue in
                Task {
                    if let data = await newValue?.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        await viewModel.handleImageUpload(image)
                    }
                }
            }
        }
    }
}

// MARK: - Bold Markdown Text

private struct BoldMarkdownText: View {
    let text: String

    var body: some View {
        let paragraphs = text.components(separatedBy: "\n\n")
        VStack(alignment: .leading, spacing: 12) {
            ForEach(0..<paragraphs.count, id: \.self) { index in
                paragraphText(for: paragraphs[index])
            }
        }
    }

    private func paragraphText(for string: String) -> some View {
        let parts = string.components(separatedBy: "**")
        var result = Text("")
        for (index, part) in parts.enumerated() {
            if index % 2 == 1 {
                result = result + Text(part).bold()
            } else {
                result = result + Text(part)
            }
        }
        return result
            .font(.system(size: 15))
            .foregroundStyle(.textSecondary)
            .lineSpacing(4)
    }
}

// MARK: - Stat Item

private struct StatItem: View {
    let value: String
    let label: String

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(.system(size: 28, weight: .medium, design: .serif))
                .italic()
                .foregroundStyle(.accentPrimary)
            Text(label)
                .font(.system(size: 10, weight: .medium))
                .tracking(0.28)
                .textCase(.uppercase)
                .foregroundStyle(.textSecondary)
        }
    }
}

#Preview {
    NavigationStack {
        AboutView(viewModel: AboutViewModel(), isAdmin: true)
    }
}
