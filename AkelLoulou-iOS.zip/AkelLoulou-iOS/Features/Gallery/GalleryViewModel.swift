import SwiftUI

@Observable
final class GalleryViewModel {
    var images: [GalleryImage] = []
    var isLoading = false
    var errorMessage: String?
    var showError = false
    var isAdmin = false
    var searchQuery = ""
    var filteredRecipes: [Recipe] = []
    var editingImage: GalleryImage?
    var selectedRecipeId: String?
    var recipes: [Recipe] = []

    private let supabase = SupabaseService.shared
    private let cloudinary = CloudinaryService.shared

    func loadImages() async {
        isLoading = true
        errorMessage = nil
        do {
            images = try await supabase.fetchGalleryImages()
        } catch {
            errorMessage = "Erreur de chargement: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func loadRecipes() async {
        do {
            let fetched = try await supabase.fetchRecipes(includeHidden: isAdmin, includeSecondary: isAdmin)
            recipes = fetched
            applyRecipeFilter()
        } catch {
            errorMessage = "Erreur de chargement des recettes: \(error.localizedDescription)"
            showError = true
        }
    }

    func applyRecipeFilter() {
        if searchQuery.isBlank {
            filteredRecipes = recipes
        } else {
            let query = searchQuery.normalizedForSearch()
            filteredRecipes = recipes.filter { $0.title.normalizedForSearch().contains(query) }
        }
    }

    func uploadImage(_ uiImage: UIImage) async {
        isLoading = true
        errorMessage = nil
        do {
            let imageUrl = try await cloudinary.uploadImage(uiImage)
            let newImage = try await supabase.addGalleryImage(url: imageUrl)
            images.insert(newImage, at: 0)
        } catch {
            errorMessage = "Erreur d'upload: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func deleteImage(_ image: GalleryImage) async {
        isLoading = true
        errorMessage = nil
        do {
            try await supabase.deleteGalleryImage(id: image.id)
            images.removeAll { $0.id == image.id }
        } catch {
            errorMessage = "Erreur de suppression: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func updateImageRecipe(imageId: String, recipeId: String?) async {
        isLoading = true
        errorMessage = nil
        do {
            try await supabase.updateGalleryImageRecipe(id: imageId, recipeId: recipeId)
            if let idx = images.firstIndex(where: { $0.id == imageId }) {
                images[idx].recipeId = recipeId
            }
        } catch {
            errorMessage = "Erreur de mise à jour: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }
}
