import SwiftUI
import PhotosUI

struct GalleryView: View {
    @Bindable var viewModel: GalleryViewModel
    @Binding var path: NavigationPath
    var isAdmin: Bool

    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var imageToDelete: GalleryImage?
    @State private var showDeleteAlert = false

    var body: some View {
        galleryGrid
            .background(Color.bgMain)
            .navigationTitle("Galerie")
            .navigationBarTitleDisplayMode(.large)
            .toolbar { adminToolbar }
            .task { await viewModel.loadImages() }
            .onChange(of: selectedPhotoItem) { _, newItem in
                handlePhotoSelection(newItem)
            }
            .alert("Erreur", isPresented: $viewModel.showError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(viewModel.errorMessage ?? "Une erreur est survenue")
            }
            .alert("Supprimer l'image ?", isPresented: $showDeleteAlert) {
                deleteAlertButtons
            } message: {
                deleteAlertMessage
            }
            .sheet(item: $viewModel.editingImage) { image in
                LinkRecipeSheet(viewModel: viewModel, image: image)
            }
            .onAppear {
                viewModel.isAdmin = isAdmin
            }
    }

    private var galleryGrid: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 120), spacing: 12)], spacing: 12) {
                ForEach(viewModel.images) { image in
                    GalleryImageCell(
                        image: image,
                        isAdmin: isAdmin,
                        onTap: {
                            if isAdmin {
                                viewModel.editingImage = image
                                viewModel.selectedRecipeId = image.recipeId
                                viewModel.searchQuery = ""
                                viewModel.applyRecipeFilter()
                            }
                        },
                        onDelete: {
                            imageToDelete = image
                            showDeleteAlert = true
                        },
                        onLink: {
                            viewModel.editingImage = image
                            viewModel.selectedRecipeId = image.recipeId
                            viewModel.searchQuery = ""
                            viewModel.applyRecipeFilter()
                        }
                    )
                }
            }
            .padding(16)
        }
    }

    @ToolbarContentBuilder
    private var adminToolbar: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            if isAdmin {
                PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.accentPrimary)
                }
                .accessible(label: "Ajouter une photo")
            }
        }
    }

    private func handlePhotoSelection(_ newItem: PhotosPickerItem?) {
        guard let newItem else { return }
        Task {
            if let data = try? await newItem.loadTransferable(type: Data.self),
               let uiImage = UIImage(data: data) {
                await viewModel.uploadImage(uiImage)
            }
        }
    }

    @ViewBuilder
    private var deleteAlertButtons: some View {
        Button("Annuler", role: .cancel) {}
        Button("Supprimer", role: .destructive) {
            if let image = imageToDelete {
                Task {
                    await viewModel.deleteImage(image)
                }
            }
        }
    }

    private var deleteAlertMessage: some View {
        if let name = imageToDelete?.name, !name.isBlank {
            Text("Es-tu sûr de vouloir supprimer \"\(name)\" ?")
        } else {
            Text("Es-tu sûr de vouloir supprimer cette image ?")
        }
    }
}

// MARK: - Gallery Image Cell

private struct GalleryImageCell: View {
    let image: GalleryImage
    let isAdmin: Bool
    let onTap: () -> Void
    let onDelete: () -> Void
    let onLink: () -> Void

    var body: some View {
        Button(action: onTap) {
            ZStack(alignment: .bottom) {
                AsyncImageView(url: URL(string: image.url))
                    .aspectRatio(1, contentMode: .fill)
                    .frame(minHeight: 120)
                    .clipped()

                imageOverlay
            }
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.borderCard, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessible(label: image.name ?? "Image de la galerie")
        .overlay(alignment: .topTrailing) {
            if isAdmin {
                AdminImageControls(onDelete: onDelete, onLink: onLink)
            }
        }
    }

    private var imageOverlay: some View {
        ZStack(alignment: .bottomLeading) {
            LinearGradient(
                colors: [.clear, .black.opacity(0.6)],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(height: 60)

            VStack(alignment: .leading, spacing: 2) {
                if let name = image.name, !name.isBlank {
                    Text(name)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                }

                Text(image.recipeId != nil ? "Liée à une recette" : "Non liée")
                    .font(.system(size: 10))
                    .foregroundStyle(image.recipeId != nil ? .white.opacity(0.8) : .white.opacity(0.6))
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 8)
        }
    }
}

private struct AdminImageControls: View {
    let onDelete: () -> Void
    let onLink: () -> Void

    var body: some View {
        HStack(spacing: 4) {
            Button(action: onLink) {
                Image(systemName: "link")
                    .font(.system(size: 12))
                    .frame(width: 28, height: 28)
                    .background(.ultraThinMaterial)
                    .clipShape(Circle())
                    .foregroundStyle(.white)
            }
            .accessible(label: "Lier à une recette")

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .font(.system(size: 12))
                    .frame(width: 28, height: 28)
                    .background(.ultraThinMaterial)
                    .clipShape(Circle())
                    .foregroundStyle(.red)
            }
            .accessible(label: "Supprimer l'image")
        }
        .padding(6)
    }
}

// MARK: - Link Recipe Sheet

private struct LinkRecipeSheet: View {
    @Bindable var viewModel: GalleryViewModel
    let image: GalleryImage
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    searchBar
                    RecipeLinkList(viewModel: viewModel)
                }
            }
            .background(Color.bgMain)
            .navigationTitle("Lier à une recette")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { linkSheetToolbar }
        }
        .task {
            await viewModel.loadRecipes()
        }
        .onChange(of: viewModel.searchQuery) { _, _ in
            viewModel.applyRecipeFilter()
        }
    }

    private var searchBar: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.textPlaceholder)
            TextField("Rechercher une recette…", text: $viewModel.searchQuery)
                .font(.system(size: 14))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.bgCard)
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.borderCard, lineWidth: 1))
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    @ToolbarContentBuilder
    private var linkSheetToolbar: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button("Annuler") {
                dismiss()
            }
            .foregroundStyle(.accentPrimary)
        }
        ToolbarItem(placement: .topBarTrailing) {
            Button("Enregistrer") {
                Task {
                    await viewModel.updateImageRecipe(
                        imageId: image.id,
                        recipeId: viewModel.selectedRecipeId
                    )
                    dismiss()
                }
            }
            .foregroundStyle(.accentPrimary)
            .fontWeight(.semibold)
        }
    }
}

private struct RecipeLinkList: View {
    @Bindable var viewModel: GalleryViewModel

    var body: some View {
        LazyVStack(spacing: 0) {
            noneRecipeRow
            ForEach(viewModel.filteredRecipes) { recipe in
                RecipeLinkRow(
                    recipe: recipe,
                    isSelected: viewModel.selectedRecipeId == recipe.id
                ) {
                    viewModel.selectedRecipeId = recipe.id
                }
            }
        }
    }

    private var noneRecipeRow: some View {
        Button {
            viewModel.selectedRecipeId = nil
        } label: {
            HStack {
                Text("Aucune recette")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.textSecondary)
                Spacer()
                if viewModel.selectedRecipeId == nil {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.accentPrimary)
                        .font(.system(size: 20))
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .buttonStyle(.plain)
        .overlay(
            Divider()
                .padding(.leading, 16)
                .frame(maxHeight: .infinity, alignment: .bottom)
        )
    }
}

private struct RecipeLinkRow: View {
    let recipe: Recipe
    let isSelected: Bool
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                RecipeThumbnail(imageUrl: recipe.imageUrl)
                VStack(alignment: .leading, spacing: 2) {
                    Text(recipe.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.textMain)
                        .lineLimit(1)
                    Text(recipe.category == "dessert" ? "Dessert" : "Plat")
                        .font(.system(size: 12))
                        .foregroundStyle(.textSecondary)
                }
                Spacer()
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.accentPrimary)
                        .font(.system(size: 20))
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .buttonStyle(.plain)
        .accessible(label: "Sélectionner \(recipe.title)")
        .overlay(
            Divider()
                .padding(.leading, 76)
                .frame(maxHeight: .infinity, alignment: .bottom)
        )
    }
}

private struct RecipeThumbnail: View {
    let imageUrl: String?

    var body: some View {
        if let imageUrl, let url = URL(string: imageUrl) {
            AsyncImageView(url: url)
                .frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 8))
        } else {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.bgHover)
                .frame(width: 48, height: 48)
                .overlay(
                    Image(systemName: "photo")
                        .foregroundStyle(.textPlaceholder)
                )
        }
    }
}

#Preview {
    NavigationStack {
        GalleryView(
            viewModel: GalleryViewModel(),
            path: .constant(NavigationPath()),
            isAdmin: true
        )
    }
}
