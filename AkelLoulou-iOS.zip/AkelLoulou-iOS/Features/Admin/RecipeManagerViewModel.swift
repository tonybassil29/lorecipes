import Foundation
import SwiftUI

@Observable
final class RecipeManagerViewModel {
    var recipes: [Recipe] = []
    var search: String = ""
    var sortKey: SortKey = .newest
    var filterCategory: String = "all"
    var filterVisibility: String = "all"
    var filtered: [Recipe] = []
    var stats = Stats()
    var isLoading = false
    var confirmRecipe: Recipe? = nil
    var isDeleting = false
    var errorMessage: String?
    var showError = false

    struct Stats {
        var total = 0
        var plats = 0
        var desserts = 0
        var menuOnly = 0
        var hidden = 0
    }

    private let supabase = SupabaseService.shared

    func loadRecipes() async {
        isLoading = true
        errorMessage = nil
        do {
            let fetched = try await supabase.fetchRecipes(includeHidden: true, includeSecondary: true)
            recipes = fetched
            applyFilters()
        } catch {
            errorMessage = "Erreur de chargement des recettes: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func deleteRecipe(id: String) async {
        isDeleting = true
        errorMessage = nil
        do {
            try await supabase.deleteRecipe(id: id)
            recipes.removeAll { $0.id == id }
            applyFilters()
            confirmRecipe = nil
        } catch {
            errorMessage = "Erreur de suppression: \(error.localizedDescription)"
            showError = true
        }
        isDeleting = false
    }

    func applyFilters() {
        var result = recipes

        // Category filter
        if filterCategory != "all" {
            result = result.filter { $0.category == filterCategory }
        }

        // Visibility filter
        switch filterVisibility {
        case "visible":
            result = result.filter { $0.hidden != true }
        case "hidden":
            result = result.filter { $0.hidden == true }
        default:
            break
        }

        // Search by title, country, or ingredient
        if !search.isBlank {
            let query = search.normalizedForSearch()
            result = result.filter { recipe in
                let titleMatch = recipe.title.normalizedForSearch().contains(query)
                let countryMatch = (recipe.country ?? "").normalizedForSearch().contains(query)
                let ingredientMatch = recipe.ingredients.contains { $0.normalizedForSearch().contains(query) }
                return titleMatch || countryMatch || ingredientMatch
            }
        }

        // Sort
        switch sortKey {
        case .newest:
            result.sort {
                let d0 = $0.createdAt ?? ""
                let d1 = $1.createdAt ?? ""
                return d0 > d1
            }
        case .oldest:
            result.sort {
                let d0 = $0.createdAt ?? ""
                let d1 = $1.createdAt ?? ""
                return d0 < d1
            }
        case .title:
            result.sort {
                $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending
            }
        case .category:
            result.sort {
                let c0 = $0.category
                let c1 = $1.category
                if c0 == c1 {
                    return $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending
                }
                return c0.localizedCaseInsensitiveCompare(c1) == .orderedAscending
            }
        }

        filtered = result

        // Stats over all recipes
        stats = Stats(
            total: recipes.count,
            plats: recipes.filter { $0.category == "plat" }.count,
            desserts: recipes.filter { $0.category == "dessert" }.count,
            menuOnly: recipes.filter { $0.category == "menu_only" }.count,
            hidden: recipes.filter { $0.hidden == true }.count
        )
    }
}
