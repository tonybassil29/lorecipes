import SwiftUI

struct RecipeManagerView: View {
    @Bindable var viewModel: RecipeManagerViewModel
    @Binding var path: NavigationPath

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 20) {
                HeaderSection(onNewRecipe: {
                    path.append(NavigationDestination.addRecipe)
                })
                StatsStrip(stats: viewModel.stats)
                FiltersSection(viewModel: viewModel)
                ResultCount(count: viewModel.filtered.count)
                RecipeListSection(
                    recipes: viewModel.filtered,
                    isDeleting: viewModel.isDeleting,
                    onView: { recipe in
                        if let id = recipe.id {
                            path.append(NavigationDestination.recipe(id))
                        }
                    },
                    onEdit: { recipe in
                        if let id = recipe.id {
                            path.append(NavigationDestination.editRecipe(id))
                        }
                    },
                    onDelete: { recipe in
                        viewModel.confirmRecipe = recipe
                    }
                )
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
        }
        .background(Color.bgMain)
        .navigationTitle("Gestionnaire")
        .navigationBarTitleDisplayMode(.large)
        .task {
            await viewModel.loadRecipes()
        }
        .onChange(of: viewModel.search) { _, _ in
            viewModel.applyFilters()
        }
        .onChange(of: viewModel.sortKey) { _, _ in
            viewModel.applyFilters()
        }
        .onChange(of: viewModel.filterCategory) { _, _ in
            viewModel.applyFilters()
        }
        .onChange(of: viewModel.filterVisibility) { _, _ in
            viewModel.applyFilters()
        }
        .alert("Erreur", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
        }
        .alert("Confirmer la suppression", isPresented: Binding(
            get: { viewModel.confirmRecipe != nil },
            set: { if !$0 { viewModel.confirmRecipe = nil } }
        )) {
            Button("Annuler", role: .cancel) {}
            Button("Supprimer", role: .destructive) {
                if let recipe = viewModel.confirmRecipe, let id = recipe.id {
                    Task {
                        await viewModel.deleteRecipe(id: id)
                    }
                }
            }
        } message: {
            if let recipe = viewModel.confirmRecipe {
                Text("Voulez-vous vraiment supprimer « \(recipe.title) » ? Cette action est irréversible.")
            }
        }
    }
}

// MARK: - Header

private struct HeaderSection: View {
    let onNewRecipe: () -> Void

    var body: some View {
        HStack {
            Text("Toutes les recettes")
                .font(.system(size: 22, weight: .bold, design: .serif))
                .foregroundStyle(.textMain)
            Spacer()
            Button(action: onNewRecipe) {
                Label("Nouvelle recette", systemImage: "plus")
                    .font(.system(size: 14, weight: .medium))
            }
            .shimmerButtonStyle()
            .accessible(label: "Nouvelle recette", hint: "Crée une nouvelle recette")
        }
    }
}

// MARK: - Stats

private struct StatsStrip: View {
    let stats: RecipeManagerViewModel.Stats

    private var items: [(title: String, value: String, icon: String, color: Color)] {
        [
            ("Total", "\(stats.total)", "book.fill", .accentPrimary),
            ("Plats", "\(stats.plats)", "fork.knife", .badgePlatBg),
            ("Desserts", "\(stats.desserts)", "birthday.cake.fill", .badgeDessertBg),
            ("Menu", "\(stats.menuOnly)", "doc.text.fill", .textSecondary),
            ("Masquées", "\(stats.hidden)", "eye.slash.fill", .textPlaceholder)
        ]
    }

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(items, id: \.title) { item in
                    StatCard(title: item.title, value: item.value, icon: item.icon, color: item.color)
                }
            }
        }
    }
}

private struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundStyle(color)
            Text(value)
                .font(.system(size: 20, weight: .bold, design: .serif))
                .foregroundStyle(.textMain)
            Text(title)
                .font(.system(size: 10, weight: .medium))
                .tracking(0.28)
                .textCase(.uppercase)
                .foregroundStyle(.textSecondary)
        }
        .frame(width: 72)
        .padding(.vertical, 14)
        .background(Color.bgHover)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

// MARK: - Filters

private struct FiltersSection: View {
    @Bindable var viewModel: RecipeManagerViewModel

    var body: some View {
        VStack(spacing: 12) {
            SearchField(search: $viewModel.search)
            CategoryPills(filterCategory: $viewModel.filterCategory)
            VisibilityPills(filterVisibility: $viewModel.filterVisibility)
            SortPicker(sortKey: $viewModel.sortKey)
        }
    }
}

private struct SearchField: View {
    @Binding var search: String

    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.textPlaceholder)
            TextField("Rechercher par titre, pays ou ingrédient…", text: $search)
                .font(.system(size: 14))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.bgCard)
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.borderCard, lineWidth: 1))
        .accessibilityLabel("Recherche de recettes")
    }
}

private struct CategoryPills: View {
    @Binding var filterCategory: String

    private var categories: [(key: String, label: String)] {
        [
            ("all", "Tous"),
            ("plat", "Plats"),
            ("dessert", "Desserts"),
            ("menu_only", "Menu")
        ]
    }

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.key) { cat in
                    Button {
                        filterCategory = cat.key
                    } label: {
                        Text(cat.label)
                            .font(.system(size: 12, weight: .medium))
                            .tracking(0.06)
                    }
                    .pillStyle(isActive: filterCategory == cat.key)
                    .accessible(label: "Filtrer par \(cat.label)")
                }
            }
        }
    }
}

private struct VisibilityPills: View {
    @Binding var filterVisibility: String

    private var options: [(key: String, label: String)] {
        [
            ("all", "Tous"),
            ("visible", "Publiées"),
            ("hidden", "Masquées")
        ]
    }

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(options, id: \.key) { opt in
                    Button {
                        filterVisibility = opt.key
                    } label: {
                        Text(opt.label)
                            .font(.system(size: 12, weight: .medium))
                            .tracking(0.06)
                    }
                    .pillStyle(isActive: filterVisibility == opt.key)
                    .accessible(label: "Filtrer par \(opt.label)")
                }
            }
        }
    }
}

private struct SortPicker: View {
    @Binding var sortKey: RecipeManagerViewModel.SortKey

    var body: some View {
        HStack {
            Text("Trier par")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(.textSecondary)
            Spacer()
            Picker("Trier par", selection: $sortKey) {
                ForEach(RecipeManagerViewModel.SortKey.allCases, id: \.self) { key in
                    Text(key.displayName).tag(key)
                }
            }
            .pickerStyle(.menu)
            .font(.system(size: 13))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderCard, lineWidth: 1))
        .accessibilityLabel("Tri des recettes")
    }
}

// MARK: - Result Count

private struct ResultCount: View {
    let count: Int

    var body: some View {
        HStack {
            Text("\(count) \(count == 1 ? "recette" : "recettes")")
                .font(.system(size: 13, weight: .medium))
                .tracking(0.32)
                .textCase(.uppercase)
                .foregroundStyle(.textSecondary)
            Spacer()
        }
        .padding(.horizontal, 4)
    }
}

// MARK: - Recipe List

private struct RecipeListSection: View {
    let recipes: [Recipe]
    let isDeleting: Bool
    let onView: (Recipe) -> Void
    let onEdit: (Recipe) -> Void
    let onDelete: (Recipe) -> Void

    var body: some View {
        if recipes.isEmpty {
            Text("Aucune recette trouvée")
                .font(.system(size: 15))
                .foregroundStyle(.textSecondary)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.vertical, 40)
        } else {
            LazyVStack(spacing: 10) {
                ForEach(recipes) { recipe in
                    RecipeManagerRow(
                        recipe: recipe,
                        onView: { onView(recipe) },
                        onEdit: { onEdit(recipe) },
                        onDelete: { onDelete(recipe) }
                    )
                }
            }
            if isDeleting {
                ProgressView()
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity)
                    .accessibilityLabel("Suppression en cours")
            }
        }
    }
}

private struct RecipeManagerRow: View {
    let recipe: Recipe
    let onView: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            RecipeRowImage(imageUrl: recipe.imageUrl)
            RecipeRowInfo(recipe: recipe)
            Spacer()
            RecipeRowActions(
                recipeTitle: recipe.title,
                onView: onView,
                onEdit: onEdit,
                onDelete: onDelete
            )
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .contentShape(Rectangle())
    }
}

private struct RecipeRowImage: View {
    let imageUrl: String?

    var body: some View {
        if let imageUrl, let url = URL(string: imageUrl) {
            AsyncImageView(url: url)
                .frame(width: 56, height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 10))
        } else {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.bgHover)
                .frame(width: 56, height: 56)
                .overlay(
                    Image(systemName: "photo")
                        .foregroundStyle(.textPlaceholder)
                )
        }
    }
}

private struct RecipeRowInfo: View {
    let recipe: Recipe

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(recipe.title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.textMain)
                .lineLimit(1)

            HStack(spacing: 6) {
                CategoryBadge(category: recipe.category)
                if let country = recipe.country, !country.isEmpty {
                    Text(country)
                        .font(.system(size: 11))
                        .foregroundStyle(.textSecondary)
                }
                if recipe.hidden == true {
                    Image(systemName: "eye.slash.fill")
                        .font(.system(size: 10))
                        .foregroundStyle(.textPlaceholder)
                        .accessibilityLabel("Masquée")
                }
            }
        }
    }
}

private struct RecipeRowActions: View {
    let recipeTitle: String
    let onView: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Button(action: onView) {
                Image(systemName: "eye")
                    .font(.system(size: 14))
                    .foregroundStyle(.accentPrimary)
            }
            .accessible(label: "Voir \(recipeTitle)")

            Button(action: onEdit) {
                Image(systemName: "pencil")
                    .font(.system(size: 14))
                    .foregroundStyle(.accentGold)
            }
            .accessible(label: "Modifier \(recipeTitle)")

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .font(.system(size: 14))
                    .foregroundStyle(.red)
            }
            .accessible(label: "Supprimer \(recipeTitle)")
        }
    }
}

private struct CategoryBadge: View {
    let category: String

    var body: some View {
        Text(categoryLabel)
            .font(.system(size: 10, weight: .medium))
            .tracking(0.12)
            .textCase(.uppercase)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(backgroundColor)
            .foregroundStyle(foregroundColor)
            .clipShape(Capsule())
    }

    private var categoryLabel: String {
        switch category {
        case "plat": return "Plat"
        case "dessert": return "Dessert"
        case "menu_only": return "Menu"
        default: return category
        }
    }

    private var backgroundColor: Color {
        switch category {
        case "plat": return .badgePlatBg
        case "dessert": return .badgeDessertBg
        default: return .bgHover
        }
    }

    private var foregroundColor: Color {
        switch category {
        case "plat": return .badgePlatText
        case "dessert": return .badgeDessertText
        default: return .textSecondary
        }
    }
}

#Preview {
    NavigationStack {
        RecipeManagerView(
            viewModel: RecipeManagerViewModel(),
            path: .constant(NavigationPath())
        )
    }
}
