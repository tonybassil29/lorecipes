import SwiftUI

struct AdminLoginView: View {
    let onLogin: () -> Void
    @State private var viewModel = AdminLoginViewModel()

    var body: some View {
        ScrollView {
            VStack {
                Spacer(minLength: 60)
                AdminLoginCard(viewModel: viewModel)
                Spacer()
            }
        }
        .background(Color.bgMain)
        .task {
            await viewModel.loadHash()
        }
        .onChange(of: viewModel.isAuthenticated) { _, newValue in
            if newValue {
                onLogin()
            }
        }
    }
}

private struct AdminLoginCard: View {
    @Bindable var viewModel: AdminLoginViewModel

    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "lock.shield.fill")
                .font(.system(size: 48))
                .foregroundStyle(.accentPrimary)

            Text(viewModel.isSetupMode ? "Initialisation Admin" : "Espace Admin")
                .font(.system(size: 28, weight: .medium, design: .serif))
                .italic()

            if let error = viewModel.errorMessage {
                Text(error)
                    .font(.system(size: 13))
                    .foregroundStyle(.red)
                    .padding(.horizontal, 16)
                    .multilineTextAlignment(.center)
            }

            SecureField("Mot de passe", text: $viewModel.password)
                .textContentType(.password)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.bgInput)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderInput, lineWidth: 1))
                .accessibilityLabel("Mot de passe")
                .accessibilityHint("Entrez votre mot de passe admin")

            Button {
                Task {
                    await viewModel.handleLogin()
                }
            } label: {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .frame(maxWidth: .infinity)
                } else {
                    Text(viewModel.isSetupMode ? "Créer le mot de passe" : "Se connecter")
                        .font(.system(size: 15, weight: .semibold))
                        .frame(maxWidth: .infinity)
                }
            }
            .shimmerButtonStyle()
            .disabled(viewModel.isLoading || viewModel.password.isEmpty)
            .accessibilityLabel(viewModel.isSetupMode ? "Créer le mot de passe" : "Se connecter")
            .accessibilityHint("Valide le mot de passe et ouvre l'espace admin")
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 32)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.borderCard, lineWidth: 1))
        .padding(.horizontal, 24)
    }
}

#Preview {
    AdminLoginView(onLogin: {})
}
