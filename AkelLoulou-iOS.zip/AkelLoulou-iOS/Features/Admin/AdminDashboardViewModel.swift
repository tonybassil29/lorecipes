import Foundation
import SwiftUI

@Observable
final class AdminDashboardViewModel {
    var recipes: [Recipe] = []
    var suggestions: [RecipeSuggestion] = []
    var isLoading = false
    var stats = Stats()
    var errorMessage: String?
    var showError = false
    var uploadingLogo = false
    var uploadingFavicon = false
    var clearingMessages = false

    struct Stats {
        var total = 0
        var plats = 0
        var desserts = 0
        var uniqueCountries = 0
        var topCountries: [(name: String, count: Int)] = []
        var topIngredients: [(name: String, count: Int)] = []
        var missingPhotos = 0
        var hiddenRecipes = 0
        var secondaryRecipes = 0
    }

    private let supabase = SupabaseService.shared
    private let cloudinary = CloudinaryService.shared

    func loadRecipes() async {
        isLoading = true
        errorMessage = nil
        do {
            let fetched = try await supabase.fetchRecipes(includeHidden: true, includeSecondary: true)
            recipes = fetched
            calculateStats()
        } catch {
            errorMessage = "Erreur de chargement des recettes: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func loadSuggestions() async {
        isLoading = true
        errorMessage = nil
        do {
            suggestions = try await supabase.fetchSuggestions()
        } catch {
            errorMessage = "Erreur de chargement des suggestions: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func deleteSuggestion(id: String) async {
        do {
            try await supabase.deleteSuggestion(id: id)
            suggestions.removeAll { $0.id == id }
        } catch {
            errorMessage = "Erreur de suppression: \(error.localizedDescription)"
            showError = true
        }
    }

    func deleteAllSuggestions() async {
        isLoading = true
        let ids = suggestions.map(\.id)
        for id in ids {
            await deleteSuggestion(id: id)
        }
        isLoading = false
    }

    func uploadLogo(_ image: UIImage) async {
        uploadingLogo = true
        errorMessage = nil
        do {
            let url = try await cloudinary.uploadImage(image)
            try await supabase.upsertSetting(key: "app_logo_url", value: ["value": url])
        } catch {
            errorMessage = "Erreur d'upload du logo: \(error.localizedDescription)"
            showError = true
        }
        uploadingLogo = false
    }

    func uploadFavicon(_ image: UIImage) async {
        uploadingFavicon = true
        errorMessage = nil
        do {
            let url = try await cloudinary.uploadImage(image)
            try await supabase.upsertSetting(key: "app_favicon_url", value: ["value": url])
        } catch {
            errorMessage = "Erreur d'upload du favicon: \(error.localizedDescription)"
            showError = true
        }
        uploadingFavicon = false
    }

    func clearAllMessages() async {
        clearingMessages = true
        errorMessage = nil
        try? await Task.sleep(nanoseconds: 500_000_000)
        clearingMessages = false
    }

    private func calculateStats() {
        let visibleRecipes = recipes.filter { $0.hidden != true }
        let plats = visibleRecipes.filter { $0.category == "plat" }
        let desserts = visibleRecipes.filter { $0.category == "dessert" }

        let countries = visibleRecipes.compactMap { $0.country }
        let countryCounts = Dictionary(grouping: countries, by: { $0 }).mapValues { $0.count }

        let allIngredients = visibleRecipes.flatMap { $0.ingredients }
        let ingredientCounts = Dictionary(grouping: allIngredients, by: { $0 }).mapValues { $0.count }

        stats = Stats(
            total: visibleRecipes.count,
            plats: plats.count,
            desserts: desserts.count,
            uniqueCountries: Set(countries).count,
            topCountries: countryCounts.sorted { $0.value > $1.value }.prefix(5).map { (name: $0.key, count: $0.value) },
            topIngredients: ingredientCounts.sorted { $0.value > $1.value }.prefix(5).map { (name: $0.key, count: $0.value) },
            missingPhotos: visibleRecipes.filter { $0.imageUrl == nil || $0.imageUrl!.isEmpty }.count,
            hiddenRecipes: recipes.filter { $0.hidden == true }.count,
            secondaryRecipes: recipes.filter { $0.isSecondary == true }.count
        )
    }
}
