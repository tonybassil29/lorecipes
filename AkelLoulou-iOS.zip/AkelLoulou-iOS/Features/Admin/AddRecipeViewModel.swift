import Foundation
import SwiftUI

@Observable
final class AddRecipeViewModel {
    // MARK: - Form fields
    var name = ""
    var category = "plat"
    var country = ""
    var portions = 4
    var description = ""
    var showPortions = false
    var imageUrl = ""
    var isHidden = false
    var isSecondary = false
    var addToGallery = false

    // MARK: - Lists
    var ingredients: [String] = [""]
    var steps: [String] = [""]
    var spices: [String] = []
    var equipment: [EquipmentItem] = []
    var relatedRecipes: [RelatedRecipe] = []

    // MARK: - Data sources
    var availableSpices: [String] = []
    var availableEquipment: [EquipmentItem] = []
    var allRecipes: [Recipe] = []

    // MARK: - Search
    var recipeSearchQuery = ""
    var showRecipeDropdown = false

    // MARK: - States
    var isSaving = false
    var isGenerating = false
    var errorMessage: String?
    var showError = false
    var saveSuccess = false

    // MARK: - Image
    var cropImage: UIImage?
    var showCropper = false

    // MARK: - Dependencies
    private let supabase = SupabaseService.shared
    private let cloudinary = CloudinaryService.shared

    // MARK: - Editing mode
    let initialRecipe: Recipe?

    var isEditing: Bool {
        initialRecipe != nil
    }

    var isDessert: Bool {
        category == "dessert"
    }

    var filteredRecipes: [Recipe] {
        if recipeSearchQuery.isBlank { return [] }
        let query = recipeSearchQuery.normalizedForSearch()
        return allRecipes.filter { recipe in
            guard recipe.id != initialRecipe?.id else { return false }
            return recipe.title.normalizedForSearch().contains(query)
        }
    }

    init(initialRecipe: Recipe? = nil) {
        self.initialRecipe = initialRecipe
        if let recipe = initialRecipe {
            populate(from: recipe)
        }
    }

    private func populate(from recipe: Recipe) {
        name = recipe.title
        category = recipe.category
        country = recipe.country ?? ""
        portions = recipe.servings
        description = recipe.description ?? ""
        showPortions = recipe.showPortions ?? false
        imageUrl = recipe.imageUrl ?? ""
        isHidden = recipe.hidden ?? false
        isSecondary = recipe.isSecondary ?? false
        ingredients = recipe.ingredients.isEmpty ? [""] : recipe.ingredients
        steps = recipe.instructionsList.isEmpty ? [""] : recipe.instructionsList
        spices = recipe.spices ?? []
        equipment = recipe.equipment ?? []
        relatedRecipes = recipe.relatedRecipes ?? []
    }

    // MARK: - Data loading
    func loadData() async {
        do {
            allRecipes = try await supabase.fetchRecipes(includeHidden: true, includeSecondary: true)
        } catch {
            errorMessage = "Erreur de chargement des recettes: \(error.localizedDescription)"
            showError = true
        }

        if availableSpices.isEmpty {
            availableSpices = [
                "Sel", "Poivre", "Cumin", "Paprika", "Curry", "Cannelle", "Muscade",
                "Gingembre", "Ail en poudre", "Oignon en poudre", "Basilic", "Origan",
                "Thym", "Romarin", "Safran", "Coriandre", "Cayenne", "Piment", "Curcuma",
                "Vanille", "Cardamome", "Clou de girofle", "Laurier", "Anis", "Ciboulette"
            ].sorted()
        }

        if availableEquipment.isEmpty {
            availableEquipment = [
                EquipmentItem(name: "Mixeur", imageUrl: nil),
                EquipmentItem(name: "Robot culinaire", imageUrl: nil),
                EquipmentItem(name: "Four", imageUrl: nil),
                EquipmentItem(name: "Plaque de cuisson", imageUrl: nil),
                EquipmentItem(name: "Poêle", imageUrl: nil),
                EquipmentItem(name: "Casserole", imageUrl: nil),
                EquipmentItem(name: "Moule à gâteau", imageUrl: nil),
                EquipmentItem(name: "Balance de cuisine", imageUrl: nil),
                EquipmentItem(name: "Râpe", imageUrl: nil),
                EquipmentItem(name: "Passoire", imageUrl: nil),
                EquipmentItem(name: "Spatule", imageUrl: nil),
                EquipmentItem(name: "Cuillère en bois", imageUrl: nil),
                EquipmentItem(name: "Fouet", imageUrl: nil),
                EquipmentItem(name: "Louche", imageUrl: nil),
                EquipmentItem(name: "Couteau de chef", imageUrl: nil)
            ]
        }
    }

    // MARK: - Ingredients
    func addIngredient() {
        ingredients.append("")
    }

    func removeIngredient(at index: Int) {
        guard ingredients.indices.contains(index) else { return }
        if ingredients.count > 1 {
            ingredients.remove(at: index)
        } else {
            ingredients[0] = ""
        }
    }

    func updateIngredient(at index: Int, value: String) {
        guard ingredients.indices.contains(index) else { return }
        ingredients[index] = value
    }

    // MARK: - Steps
    func addStep() {
        steps.append("")
    }

    func removeStep(at index: Int) {
        guard steps.indices.contains(index) else { return }
        if steps.count > 1 {
            steps.remove(at: index)
        } else {
            steps[0] = ""
        }
    }

    func updateStep(at index: Int, value: String) {
        guard steps.indices.contains(index) else { return }
        steps[index] = value
    }

    func moveStep(from source: IndexSet, to destination: Int) {
        steps.move(fromOffsets: source, toOffset: destination)
    }

    // MARK: - Spices
    func toggleSpice(_ spice: String) {
        if spices.contains(spice) {
            spices.removeAll { $0 == spice }
        } else {
            spices.append(spice)
        }
    }

    // MARK: - Equipment
    func toggleEquipment(_ item: EquipmentItem) {
        if equipment.contains(where: { $0.name == item.name }) {
            equipment.removeAll { $0.name == item.name }
        } else {
            equipment.append(item)
        }
    }

    // MARK: - Related recipes
    func addRelatedRecipe(_ recipe: Recipe) {
        guard let id = recipe.id else { return }
        let related = RelatedRecipe(id: id, title: recipe.title)
        if !relatedRecipes.contains(where: { $0.id == id }) {
            relatedRecipes.append(related)
        }
        recipeSearchQuery = ""
        showRecipeDropdown = false
    }

    func removeRelatedRecipe(at index: Int) {
        guard relatedRecipes.indices.contains(index) else { return }
        relatedRecipes.remove(at: index)
    }

    // MARK: - Image upload
    func uploadImage(_ image: UIImage) async {
        isSaving = true
        defer { isSaving = false }
        do {
            let url = try await cloudinary.uploadImage(image)
            imageUrl = url
        } catch {
            errorMessage = "Erreur d'upload: \(error.localizedDescription)"
            showError = true
        }
    }

    func uploadImageData(_ data: Data) async {
        isSaving = true
        defer { isSaving = false }
        do {
            let url = try await cloudinary.uploadImageData(data, filename: "image.png", mimeType: "image/png")
            imageUrl = url
        } catch {
            errorMessage = "Erreur d'upload: \(error.localizedDescription)"
            showError = true
        }
    }

    // MARK: - Save
    func saveRecipe() async {
        isSaving = true
        errorMessage = nil
        defer { isSaving = false }

        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            errorMessage = "Le nom de la recette est requis"
            showError = true
            return
        }

        let validIngredients = ingredients
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        let validSteps = steps
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        guard !validIngredients.isEmpty else {
            errorMessage = "Au moins un ingrédient est requis"
            showError = true
            return
        }

        guard !validSteps.isEmpty else {
            errorMessage = "Au moins une étape est requise"
            showError = true
            return
        }

        let recipe = Recipe(
            id: initialRecipe?.id,
            title: trimmedName,
            description: description.isEmpty ? nil : description,
            ingredients: validIngredients,
            spices: spices.isEmpty ? nil : spices,
            equipment: equipment.isEmpty ? nil : equipment,
            instructions: validSteps.joined(separator: "\n"),
            category: category,
            servings: max(1, portions),
            showPortions: showPortions,
            imageUrl: imageUrl.isEmpty ? nil : imageUrl,
            country: country.isEmpty ? nil : country,
            hidden: isHidden,
            isSecondary: isSecondary,
            isFavorite: initialRecipe?.isFavorite,
            relatedRecipes: relatedRecipes.isEmpty ? nil : relatedRecipes,
            createdAt: initialRecipe?.createdAt,
            updatedAt: nil
        )

        do {
            if let existingId = initialRecipe?.id {
                try await supabase.updateRecipe(id: existingId, recipe)
            } else {
                _ = try await supabase.addRecipe(recipe)
            }

            if addToGallery && !imageUrl.isEmpty {
                _ = try? await supabase.addGalleryImage(url: imageUrl)
            }

            saveSuccess = true
        } catch {
            errorMessage = "Erreur de sauvegarde: \(error.localizedDescription)"
            showError = true
        }
    }

    // MARK: - AI Generation (mock)
    func generateRecipeWithAI(prompt: String) async {
        isGenerating = true
        errorMessage = nil
        defer { isGenerating = false }

        try? await Task.sleep(nanoseconds: 1_500_000_000)

        let topic = prompt.isEmpty ? name : prompt
        guard !topic.isEmpty else {
            errorMessage = "Veuillez entrer un nom ou une description pour générer"
            showError = true
            return
        }

        let isDessert = category == "dessert"

        if name.isEmpty || name == "Nouvelle recette" {
            name = topic
        }

        if description.isEmpty {
            description = isDessert
                ? "Un délicieux dessert inspiré par \(topic), préparé avec des ingrédients frais et beaucoup d'amour."
                : "Un plat savoureux autour de \(topic), réconfortant et parfait pour partager."
        }

        if ingredients.count == 1 && ingredients[0].isEmpty {
            ingredients = isDessert
                ? ["200g de farine", "100g de sucre", "3 œufs", "100g de beurre", "1 sachet de levure", "200ml de lait"]
                : ["500g de viande ou légumes", "2 oignons", "3 tomates", "Ail", "Huile d'olive", "Épices assorties"]
        }

        if steps.count == 1 && steps[0].isEmpty {
            steps = isDessert
                ? [
                    "Préchauffer le four à 180°C.",
                    "Mélanger les ingrédients secs dans un saladier.",
                    "Ajouter les ingrédients liquides et mélanger.",
                    "Verser dans un moule beurré.",
                    "Cuire 25-30 minutes jusqu'à dorure."
                ]
                : [
                    "Préparer et couper tous les ingrédients.",
                    "Faire revenir l'oignon et l'ail dans l'huile.",
                    "Ajouter la viande ou les légumes et faire dorer.",
                    "Incorporer les tomates et les épices.",
                    "Laisser mijoter à feu doux 30 minutes."
                ]
        }

        if spices.isEmpty && !isDessert {
            spices = ["Sel", "Poivre", "Paprika"]
        }
    }
}
