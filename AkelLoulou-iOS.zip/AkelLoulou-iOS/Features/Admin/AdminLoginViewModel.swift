import Foundation

@Observable
final class AdminLoginViewModel {
    var password = ""
    var errorMessage: String?
    var isLoading = false
    var isSetupMode = false
    var isAuthenticated = false
    var adminHash: String?

    private let supabase = SupabaseService.shared
    private static let fallbackPassword = "4I6#r2p7kZYkpSm"

    func loadHash() async {
        isLoading = true
        errorMessage = nil
        do {
            if let dict = try await supabase.fetchSetting(key: "admin_hash") {
                adminHash = dict["hash"] as? String
            }
            isSetupMode = (adminHash == nil)
        } catch {
            isSetupMode = false
            errorMessage = "Impossible de vérifier le mot de passe. Utilisation du mode fallback."
        }
        isLoading = false
    }

    func handleLogin() async {
        isLoading = true
        errorMessage = nil

        let trimmed = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            errorMessage = "Veuillez entrer un mot de passe"
            isLoading = false
            return
        }

        if isSetupMode {
            let hash = Self.hashPassword(trimmed)
            do {
                try await supabase.upsertSetting(key: "admin_hash", value: ["hash": hash])
                adminHash = hash
                isSetupMode = false
                isAuthenticated = true
            } catch {
                errorMessage = "Erreur lors de la création du mot de passe"
            }
        } else {
            let inputHash = Self.hashPassword(trimmed)
            if let storedHash = adminHash {
                if inputHash == storedHash {
                    isAuthenticated = true
                } else {
                    errorMessage = "Mot de passe incorrect"
                }
            } else {
                if trimmed == Self.fallbackPassword {
                    isAuthenticated = true
                } else {
                    errorMessage = "Mot de passe incorrect"
                }
            }
        }

        isLoading = false
    }

    private static func hashPassword(_ password: String) -> String {
        let salt = "akel_loulou_admin_salt_v1"
        var hash = 5381
        for byte in (salt + password).utf8 {
            hash = ((hash << 5) &+ hash) &+ Int(byte)
        }
        return String(hash)
    }
}
