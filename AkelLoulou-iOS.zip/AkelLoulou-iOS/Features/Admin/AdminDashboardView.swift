import SwiftUI
import PhotosUI

struct AdminDashboardView: View {
    @Bindable var viewModel: AdminDashboardViewModel
    @Binding var path: NavigationPath
    let isAdmin: Bool
    let onLogout: () -> Void

    @State private var selectedLogoItem: PhotosPickerItem?
    @State private var selectedFaviconItem: PhotosPickerItem?

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 20) {
                StatsGridSection(stats: viewModel.stats, suggestionsCount: viewModel.suggestions.count)
                DonutChartSection(stats: viewModel.stats)
                CountryChartSection(topCountries: viewModel.stats.topCountries)
                IngredientsChartSection(topIngredients: viewModel.stats.topIngredients)
                RecipeListSection(
                    title: "Recettes secondaires",
                    count: viewModel.stats.secondaryRecipes,
                    recipes: viewModel.recipes.filter { $0.isSecondary == true }
                )
                RecipeListSection(
                    title: "Photos manquantes",
                    count: viewModel.stats.missingPhotos,
                    recipes: viewModel.recipes.filter { ($0.imageUrl == nil || $0.imageUrl!.isEmpty) && $0.hidden != true }
                )
                RecipeListSection(
                    title: "Recettes masquées",
                    count: viewModel.stats.hiddenRecipes,
                    recipes: viewModel.recipes.filter { $0.hidden == true }
                )
                SuggestionsSection(
                    suggestions: viewModel.suggestions,
                    onDelete: { id in
                        Task { await viewModel.deleteSuggestion(id: id) }
                    },
                    onDeleteAll: {
                        Task { await viewModel.deleteAllSuggestions() }
                    }
                )
                AdminActionsSection(
                    uploadingLogo: viewModel.uploadingLogo,
                    uploadingFavicon: viewModel.uploadingFavicon,
                    clearingMessages: viewModel.clearingMessages,
                    onClearMessages: {
                        Task { await viewModel.clearAllMessages() }
                    },
                    selectedLogoItem: $selectedLogoItem,
                    selectedFaviconItem: $selectedFaviconItem
                )
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
        }
        .background(Color.bgMain)
        .navigationTitle("Tableau de bord")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    onLogout()
                } label: {
                    Image(systemName: "arrow.right.square")
                        .foregroundStyle(.red)
                }
                .accessible(label: "Déconnexion", hint: "Déconnecte l'administrateur")
            }
        }
        .task {
            await viewModel.loadRecipes()
            await viewModel.loadSuggestions()
        }
        .alert("Erreur", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
        }
        .onChange(of: selectedLogoItem) { _, newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    await viewModel.uploadLogo(image)
                }
            }
        }
        .onChange(of: selectedFaviconItem) { _, newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    await viewModel.uploadFavicon(image)
                }
            }
        }
    }
}

// MARK: - Stats Grid

private struct StatsGridSection: View {
    let stats: AdminDashboardViewModel.Stats
    let suggestionsCount: Int

    private var items: [(title: String, value: String, icon: String, color: Color)] {
        [
            ("Recettes", "\(stats.total)", "book.fill", .accentPrimary),
            ("Plats", "\(stats.plats)", "fork.knife", .badgePlatBg),
            ("Desserts", "\(stats.desserts)", "birthday.cake.fill", .badgeDessertBg),
            ("Pays", "\(stats.uniqueCountries)", "globe", .accentGold),
            ("Secondaires", "\(stats.secondaryRecipes)", "doc.text.fill", .textSecondary),
            ("Suggestions", "\(suggestionsCount)", "lightbulb.fill", .accentSecondary)
        ]
    }

    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(items, id: \.title) { item in
                StatCard(title: item.title, value: item.value, icon: item.icon, color: item.color)
            }
        }
    }
}

private struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundStyle(color)
            Text(value)
                .font(.system(size: 24, weight: .bold, design: .serif))
                .foregroundStyle(.textMain)
            Text(title)
                .font(.system(size: 10, weight: .medium))
                .tracking(0.28)
                .textCase(.uppercase)
                .foregroundStyle(.textSecondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color.bgHover)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - Donut Chart

private struct DonutChartSection: View {
    let stats: AdminDashboardViewModel.Stats

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Répartition Plats / Desserts")
                .font(.system(size: 18, weight: .semibold))

            let total = stats.plats + stats.desserts

            HStack(spacing: 0) {
                Spacer()
                ZStack {
                    Circle()
                        .trim(from: 0, to: total > 0 ? CGFloat(stats.plats) / CGFloat(total) : 0)
                        .stroke(.accentPrimary, style: StrokeStyle(lineWidth: 24, lineCap: .butt))
                        .rotationEffect(.degrees(-90))
                    Circle()
                        .trim(from: total > 0 ? CGFloat(stats.plats) / CGFloat(total) : 0, to: 1)
                        .stroke(.accentGold, style: StrokeStyle(lineWidth: 24, lineCap: .butt))
                        .rotationEffect(.degrees(-90))
                    VStack {
                        Text("\(total)")
                            .font(.system(size: 24, weight: .bold, design: .serif))
                        Text("total")
                            .font(.system(size: 11))
                            .foregroundStyle(.textSecondary)
                    }
                }
                .frame(width: 140, height: 140)
                Spacer()
            }

            HStack(spacing: 24) {
                ChartLegendItem(color: .accentPrimary, label: "Plats", value: stats.plats)
                ChartLegendItem(color: .accentGold, label: "Desserts", value: stats.desserts)
            }
            .frame(maxWidth: .infinity)
        }
        .padding()
        .cardStyle()
    }
}

private struct ChartLegendItem: View {
    let color: Color
    let label: String
    let value: Int

    var body: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(color)
                .frame(width: 10, height: 10)
            Text(label)
                .font(.system(size: 13))
            Text("\(value)")
                .font(.system(size: 13, weight: .bold))
        }
        .foregroundStyle(.textSecondary)
    }
}

// MARK: - Bar Charts

private struct CountryChartSection: View {
    let topCountries: [(name: String, count: Int)]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Top Pays")
                .font(.system(size: 18, weight: .semibold))

            if topCountries.isEmpty {
                Text("Aucune donnée")
                    .font(.system(size: 13))
                    .foregroundStyle(.textSecondary)
            } else {
                let maxCount = max(topCountries.map(\.count).max() ?? 1, 1)
                VStack(spacing: 10) {
                    ForEach(topCountries, id: \.name) { country in
                        BarRow(label: country.name, value: country.count, maxValue: maxCount, color: .accentPrimary)
                    }
                }
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct IngredientsChartSection: View {
    let topIngredients: [(name: String, count: Int)]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Top Ingrédients")
                .font(.system(size: 18, weight: .semibold))

            if topIngredients.isEmpty {
                Text("Aucune donnée")
                    .font(.system(size: 13))
                    .foregroundStyle(.textSecondary)
            } else {
                let maxCount = max(topIngredients.map(\.count).max() ?? 1, 1)
                VStack(spacing: 10) {
                    ForEach(topIngredients, id: \.name) { ingredient in
                        BarRow(label: ingredient.name, value: ingredient.count, maxValue: maxCount, color: .accentSecondary)
                    }
                }
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct BarRow: View {
    let label: String
    let value: Int
    let maxValue: Int
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Text(label)
                .font(.system(size: 13))
                .frame(width: 90, alignment: .leading)
                .lineLimit(1)

            HStack(spacing: 0) {
                RoundedRectangle(cornerRadius: 4)
                    .fill(color)
                    .frame(height: 12)
                    .containerRelativeFrame(.horizontal) { length, _ in
                        let ratio = CGFloat(value) / CGFloat(maxValue)
                        return max(length * ratio * 0.55, 4)
                    }
                Spacer()
            }

            Text("\(value)")
                .font(.system(size: 12, weight: .medium))
                .frame(width: 28, alignment: .trailing)
        }
    }
}

// MARK: - Recipe Lists

private struct RecipeListSection: View {
    let title: String
    let count: Int
    let recipes: [Recipe]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("\(title) (\(count))")
                .font(.system(size: 18, weight: .semibold))

            if recipes.isEmpty {
                Text("Aucune recette")
                    .font(.system(size: 13))
                    .foregroundStyle(.textSecondary)
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(recipes) { recipe in
                        RecipeRow(recipe: recipe)
                    }
                }
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct RecipeRow: View {
    let recipe: Recipe

    var body: some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(recipe.category == "plat" ? Color.badgePlatBg : Color.badgeDessertBg)
                .frame(width: 8, height: 32)

            VStack(alignment: .leading, spacing: 2) {
                Text(recipe.title)
                    .font(.system(size: 14, weight: .medium))
                if let country = recipe.country, !country.isEmpty {
                    Text(country)
                        .font(.system(size: 11))
                        .foregroundStyle(.textSecondary)
                }
            }

            Spacer()

            if recipe.imageUrl == nil || recipe.imageUrl!.isEmpty {
                Image(systemName: "photo.badge.exclamationmark")
                    .foregroundStyle(.red)
                    .font(.system(size: 14))
                    .accessibilityLabel("Photo manquante")
            }

            if recipe.hidden == true {
                Image(systemName: "eye.slash.fill")
                    .foregroundStyle(.textPlaceholder)
                    .font(.system(size: 14))
                    .accessibilityLabel("Recette masquée")
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.bgHover)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Suggestions

private struct SuggestionsSection: View {
    let suggestions: [RecipeSuggestion]
    let onDelete: (String) -> Void
    let onDeleteAll: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Suggestions (\(suggestions.count))")
                    .font(.system(size: 18, weight: .semibold))
                Spacer()
                if !suggestions.isEmpty {
                    Button {
                        onDeleteAll()
                    } label: {
                        Text("Tout supprimer")
                            .font(.system(size: 12))
                            .foregroundStyle(.red)
                    }
                    .accessible(label: "Supprimer toutes les suggestions")
                }
            }

            if suggestions.isEmpty {
                Text("Aucune suggestion")
                    .font(.system(size: 13))
                    .foregroundStyle(.textSecondary)
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(suggestions) { suggestion in
                        SuggestionRow(suggestion: suggestion, onDelete: {
                            onDelete(suggestion.id)
                        })
                    }
                }
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct SuggestionRow: View {
    let suggestion: RecipeSuggestion
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(suggestion.recipeName)
                    .font(.system(size: 14, weight: .medium))
                if let user = suggestion.userName, !user.isEmpty {
                    Text("Par \(user)")
                        .font(.system(size: 11))
                        .foregroundStyle(.textSecondary)
                }
            }

            Spacer()

            Button {
                onDelete()
            } label: {
                Image(systemName: "trash")
                    .foregroundStyle(.red)
                    .font(.system(size: 14))
            }
            .accessible(label: "Supprimer la suggestion", hint: "Supprime \(suggestion.recipeName)")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.bgHover)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Admin Actions

private struct AdminActionsSection: View {
    let uploadingLogo: Bool
    let uploadingFavicon: Bool
    let clearingMessages: Bool
    let onClearMessages: () -> Void
    @Binding var selectedLogoItem: PhotosPickerItem?
    @Binding var selectedFaviconItem: PhotosPickerItem?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Actions")
                .font(.system(size: 18, weight: .semibold))

            VStack(spacing: 8) {
                Button(action: onClearMessages) {
                    AdminActionButton(title: "Effacer tous les messages", icon: "trash", isLoading: clearingMessages)
                }
                .accessible(label: "Effacer tous les messages")

                PhotosPicker(selection: $selectedLogoItem, matching: .images) {
                    AdminActionButton(title: "Changer le logo", icon: "photo", isLoading: uploadingLogo)
                }
                .accessible(label: "Changer le logo", hint: "Ouvre le sélecteur de photos")

                PhotosPicker(selection: $selectedFaviconItem, matching: .images) {
                    AdminActionButton(title: "Changer le favicon", icon: "app.badge", isLoading: uploadingFavicon)
                }
                .accessible(label: "Changer le favicon", hint: "Ouvre le sélecteur de photos")
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct AdminActionButton: View {
    let title: String
    let icon: String
    let isLoading: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .frame(width: 28, height: 28)
                .foregroundStyle(.accentPrimary)
            Text(title)
                .font(.system(size: 14, weight: .medium))
            Spacer()
            if isLoading {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle())
            } else {
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.textPlaceholder)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.bgHover)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .contentShape(RoundedRectangle(cornerRadius: 12))
    }
}

#Preview {
    NavigationStack {
        AdminDashboardView(
            viewModel: AdminDashboardViewModel(),
            path: .constant(NavigationPath()),
            isAdmin: true,
            onLogout: {}
        )
    }
}
