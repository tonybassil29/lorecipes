import SwiftUI
import PhotosUI

struct AddRecipeView: View {
    @Bindable var viewModel: AddRecipeViewModel
    @Binding var path: NavigationPath
    @Environment(\.dismiss) private var dismiss
    @State private var selectedPhotoItem: PhotosPickerItem?

    init(viewModel: AddRecipeViewModel, path: Binding<NavigationPath>) {
        self.viewModel = viewModel
        _path = path
    }

    var body: some View {
        ScrollView {
            AddRecipeFormContent(viewModel: viewModel, selectedPhotoItem: $selectedPhotoItem)
        }
        .background(Color.bgMain)
        .navigationTitle(viewModel.isEditing ? "Modifier la recette" : "Nouvelle recette")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Text("Annuler")
                        .foregroundStyle(.accentPrimary)
                }
                .accessible(label: "Annuler", hint: "Ferme le formulaire sans sauvegarder")
            }
        }
        .task {
            await viewModel.loadData()
        }
        .alert("Erreur", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
        }
        .onChange(of: viewModel.saveSuccess) { _, success in
            if success { dismiss() }
        }
        .onChange(of: selectedPhotoItem) { _, newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    viewModel.cropImage = image
                    viewModel.showCropper = true
                }
            }
        }
        .sheet(isPresented: $viewModel.showCropper) {
            ImageCropperSheet(viewModel: viewModel)
        }
    }
}

// MARK: - Form Content

private struct AddRecipeFormContent: View {
    @Bindable var viewModel: AddRecipeViewModel
    @Binding var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        LazyVStack(spacing: 20) {
            InformationSection(viewModel: viewModel, selectedPhotoItem: $selectedPhotoItem)
            IngredientsSection(viewModel: viewModel)
            if !viewModel.isDessert {
                SpicesSection(viewModel: viewModel)
            }
            EquipmentSection(viewModel: viewModel)
            RelatedRecipesSection(viewModel: viewModel)
            PreparationSection(viewModel: viewModel)
            SaveSection(viewModel: viewModel)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 20)
    }
}

private struct ImageCropperSheet: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        if let image = viewModel.cropImage {
            ImageCropperView(
                image: image,
                onCrop: { cropped in
                    Task {
                        await viewModel.uploadImage(cropped)
                    }
                    viewModel.showCropper = false
                    viewModel.cropImage = nil
                },
                onCancel: {
                    viewModel.showCropper = false
                    viewModel.cropImage = nil
                }
            )
        }
    }
}

// MARK: - Information Section

private struct InformationSection: View {
    @Bindable var viewModel: AddRecipeViewModel
    @Binding var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Informations")
                .font(.system(size: 18, weight: .semibold))

            TextField("Nom de la recette", text: $viewModel.name)
                .textFieldStyle(.roundedBorder)
                .accessibilityLabel("Nom de la recette")

            CategoryToggle(category: $viewModel.category)

            TextField("Pays d'origine", text: $viewModel.country)
                .textFieldStyle(.roundedBorder)
                .accessibilityLabel("Pays d'origine")

            HStack {
                Text("Portions")
                Spacer()
                Stepper("\(viewModel.portions)", value: $viewModel.portions, in: 1...50)
                    .accessibilityLabel("Nombre de portions")
            }

            Toggle("Afficher les portions", isOn: $viewModel.showPortions)
                .accessibilityLabel("Afficher les portions")

            TextField("Description", text: $viewModel.description, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .lineLimit(3...6)
                .accessibilityLabel("Description")

            ImageInputSection(imageUrl: $viewModel.imageUrl, selectedPhotoItem: $selectedPhotoItem)
            TogglesSection(viewModel: viewModel)
        }
        .padding()
        .cardStyle()
    }
}

private struct CategoryToggle: View {
    @Binding var category: String

    var body: some View {
        HStack(spacing: 0) {
            Button("Plat") { category = "plat" }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(category == "plat" ? Color.accentPrimary : Color.bgHover)
                .foregroundStyle(category == "plat" ? .white : .textSecondary)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .accessibilityLabel("Catégorie plat")

            Button("Dessert") { category = "dessert" }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(category == "dessert" ? Color.accentGold : Color.bgHover)
                .foregroundStyle(category == "dessert" ? .white : .textSecondary)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .accessibilityLabel("Catégorie dessert")
        }
        .background(Color.bgHover)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

private struct ImageInputSection: View {
    @Binding var imageUrl: String
    @Binding var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        VStack(spacing: 8) {
            TextField("URL de l'image", text: $imageUrl)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.URL)
                .textInputAutocapitalization(.none)
                .accessibilityLabel("URL de l'image")

            if !imageUrl.isEmpty {
                AsyncImageView(url: URL(string: imageUrl))
                    .frame(height: 150)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                Label("Choisir une photo", systemImage: "photo")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.bgHover)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.accentPrimary)
            }
            .accessible(label: "Choisir une photo", hint: "Ouvre le sélecteur de photos")
        }
    }
}

private struct TogglesSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(spacing: 8) {
            Toggle("Recette masquée", isOn: $viewModel.isHidden)
                .accessibilityLabel("Recette masquée")
            Toggle("Recette secondaire", isOn: $viewModel.isSecondary)
                .accessibilityLabel("Recette secondaire")
            Toggle("Ajouter à la galerie", isOn: $viewModel.addToGallery)
                .accessibilityLabel("Ajouter à la galerie")
        }
    }
}

// MARK: - Ingredients Section

private struct IngredientsSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Ingrédients")
                .font(.system(size: 18, weight: .semibold))

            ForEach(viewModel.ingredients.indices, id: \.self) { index in
                IngredientRow(
                    index: index,
                    value: viewModel.ingredients[index],
                    onUpdate: { viewModel.updateIngredient(at: index, value: $0) },
                    onRemove: { viewModel.removeIngredient(at: index) }
                )
            }

            Button {
                viewModel.addIngredient()
            } label: {
                Label("Ajouter un ingrédient", systemImage: "plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.bgHover)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.accentPrimary)
            }
            .accessible(label: "Ajouter un ingrédient")
        }
        .padding()
        .cardStyle()
    }
}

private struct IngredientRow: View {
    let index: Int
    var value: String
    let onUpdate: (String) -> Void
    let onRemove: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            TextField("Ingrédient \(index + 1)", text: Binding(
                get: { value },
                set: { onUpdate($0) }
            ))
            .textFieldStyle(.roundedBorder)
            .accessibilityLabel("Ingrédient \(index + 1)")

            Button {
                onRemove()
            } label: {
                Image(systemName: "minus.circle.fill")
                    .foregroundStyle(.red)
            }
            .accessible(label: "Supprimer l'ingrédient")
        }
    }
}

// MARK: - Spices Section

private struct SpicesSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Épices")
                .font(.system(size: 18, weight: .semibold))

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 8) {
                ForEach(viewModel.availableSpices, id: \.self) { spice in
                    SpiceChip(
                        name: spice,
                        isSelected: viewModel.spices.contains(spice),
                        onTap: { viewModel.toggleSpice(spice) }
                    )
                }
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct SpiceChip: View {
    let name: String
    let isSelected: Bool
    let onTap: () -> Void

    var body: some View {
        Button {
            onTap()
        } label: {
            Text(name)
                .font(.system(size: 13, weight: .medium))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(isSelected ? Color.accentPrimary : Color.bgHover)
                .foregroundStyle(isSelected ? .white : .textSecondary)
                .clipShape(Capsule())
        }
        .accessible(label: "Épice \(name)", hint: isSelected ? "Désélectionner" : "Sélectionner")
    }
}

// MARK: - Equipment Section

private struct EquipmentSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Matériel")
                .font(.system(size: 18, weight: .semibold))

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 8) {
                ForEach(viewModel.availableEquipment, id: \.self) { item in
                    EquipmentChip(
                        name: item.name,
                        isSelected: viewModel.equipment.contains(where: { $0.name == item.name }),
                        onTap: { viewModel.toggleEquipment(item) }
                    )
                }
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct EquipmentChip: View {
    let name: String
    let isSelected: Bool
    let onTap: () -> Void

    var body: some View {
        Button {
            onTap()
        } label: {
            Text(name)
                .font(.system(size: 13, weight: .medium))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(isSelected ? Color.accentSecondary : Color.bgHover)
                .foregroundStyle(isSelected ? .white : .textSecondary)
                .clipShape(Capsule())
        }
        .accessible(label: "Matériel \(name)", hint: isSelected ? "Désélectionner" : "Sélectionner")
    }
}

// MARK: - Related Recipes Section

private struct RelatedRecipesSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Recettes liées")
                .font(.system(size: 18, weight: .semibold))

            if !viewModel.relatedRecipes.isEmpty {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 8) {
                    ForEach(viewModel.relatedRecipes.indices, id: \.self) { index in
                        RelatedRecipeChip(
                            title: viewModel.relatedRecipes[index].title,
                            onRemove: { viewModel.removeRelatedRecipe(at: index) }
                        )
                    }
                }
            }

            TextField("Rechercher une recette", text: $viewModel.recipeSearchQuery)
                .textFieldStyle(.roundedBorder)
                .onTapGesture {
                    viewModel.showRecipeDropdown = true
                }
                .accessibilityLabel("Rechercher une recette liée")

            if viewModel.showRecipeDropdown && !viewModel.filteredRecipes.isEmpty {
                LazyVStack(spacing: 0) {
                    ForEach(viewModel.filteredRecipes) { recipe in
                        Button {
                            viewModel.addRelatedRecipe(recipe)
                        } label: {
                            Text(recipe.title)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                        }
                        .foregroundStyle(.textMain)
                        .background(Color.bgHover)
                        .accessible(label: "Lier \(recipe.title)")
                    }
                }
                .background(Color.bgCard)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderCard, lineWidth: 1))
            }
        }
        .padding()
        .cardStyle()
    }
}

private struct RelatedRecipeChip: View {
    let title: String
    let onRemove: () -> Void

    var body: some View {
        HStack(spacing: 4) {
            Text(title)
                .font(.system(size: 12, weight: .medium))
            Button {
                onRemove()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 14))
            }
            .accessible(label: "Retirer \(title)")
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(Color.accentPrimary.opacity(0.15))
        .foregroundStyle(.accentPrimary)
        .clipShape(Capsule())
    }
}

// MARK: - Preparation Section

private struct PreparationSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Préparation")
                .font(.system(size: 18, weight: .semibold))

            ForEach(viewModel.steps.indices, id: \.self) { index in
                StepRow(
                    number: index + 1,
                    value: viewModel.steps[index],
                    canMoveUp: index > 0,
                    canMoveDown: index < viewModel.steps.count - 1,
                    onUpdate: { viewModel.updateStep(at: index, value: $0) },
                    onMoveUp: { viewModel.moveStep(from: IndexSet([index]), to: index - 1) },
                    onMoveDown: { viewModel.moveStep(from: IndexSet([index]), to: index + 1) },
                    onRemove: { viewModel.removeStep(at: index) }
                )
            }

            Button {
                viewModel.addStep()
            } label: {
                Label("Ajouter une étape", systemImage: "plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.bgHover)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.accentPrimary)
            }
            .accessible(label: "Ajouter une étape")
        }
        .padding()
        .cardStyle()
    }
}

private struct StepRow: View {
    let number: Int
    var value: String
    let canMoveUp: Bool
    let canMoveDown: Bool
    let onUpdate: (String) -> Void
    let onMoveUp: () -> Void
    let onMoveDown: () -> Void
    let onRemove: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            Text("\(number).")
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(.accentPrimary)
                .frame(width: 24)

            TextField("Étape \(number)", text: Binding(
                get: { value },
                set: { onUpdate($0) }
            ), axis: .vertical)
            .textFieldStyle(.roundedBorder)
            .lineLimit(2...4)
            .accessibilityLabel("Étape \(number)")

            VStack(spacing: 4) {
                Button {
                    onMoveUp()
                } label: {
                    Image(systemName: "chevron.up")
                        .font(.system(size: 10))
                }
                .disabled(!canMoveUp)
                .accessible(label: "Monter l'étape")

                Button {
                    onMoveDown()
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 10))
                }
                .disabled(!canMoveDown)
                .accessible(label: "Descendre l'étape")
            }
            .foregroundStyle(.textSecondary)

            Button {
                onRemove()
            } label: {
                Image(systemName: "minus.circle.fill")
                    .foregroundStyle(.red)
            }
            .accessible(label: "Supprimer l'étape")
        }
    }
}

// MARK: - Save Section

private struct SaveSection: View {
    @Bindable var viewModel: AddRecipeViewModel

    var body: some View {
        VStack(spacing: 12) {
            Button {
                Task {
                    await viewModel.generateRecipeWithAI(prompt: viewModel.name)
                }
            } label: {
                if viewModel.isGenerating {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                } else {
                    Label("Générer avec l'IA", systemImage: "wand.and.stars")
                        .frame(maxWidth: .infinity)
                }
            }
            .shimmerButtonStyle()
            .disabled(viewModel.isGenerating || viewModel.isSaving)
            .accessible(label: "Générer avec l'IA", hint: "Remplit automatiquement la recette")

            Button {
                Task {
                    await viewModel.saveRecipe()
                }
            } label: {
                if viewModel.isSaving {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                } else {
                    Text(viewModel.isEditing ? "Mettre à jour" : "Sauvegarder")
                        .font(.system(size: 15, weight: .semibold))
                        .frame(maxWidth: .infinity)
                }
            }
            .shimmerButtonStyle()
            .disabled(viewModel.isSaving || viewModel.isGenerating || viewModel.name.isEmpty)
            .accessible(label: viewModel.isEditing ? "Mettre à jour la recette" : "Sauvegarder la recette")
        }
    }
}

// MARK: - Image Cropper

private struct ImageCropperView: View {
    let image: UIImage
    let onCrop: (UIImage) -> Void
    let onCancel: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text("Recadrer l'image")
                .font(.system(size: 18, weight: .semibold))

            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(.horizontal)

            Spacer()

            HStack(spacing: 16) {
                Button("Annuler", role: .cancel) {
                    onCancel()
                }
                .buttonStyle(.bordered)
                .frame(maxWidth: .infinity)

                Button("Utiliser") {
                    onCrop(image)
                }
                .buttonStyle(.borderedProminent)
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal)
            .padding(.bottom)
        }
        .padding(.top)
        .background(Color.bgMain)
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        AddRecipeView(viewModel: AddRecipeViewModel(), path: .constant(NavigationPath()))
    }
}
