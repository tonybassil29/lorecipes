import SwiftUI
import PhotosUI

struct RecipeDetailView: View {
    @Bindable var viewModel: RecipeDetailViewModel
    var isAdmin: Bool
    var onEdit: () -> Void
    var onDelete: () -> Void
    var onBack: () -> Void

    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var showDeleteAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                heroSection
                contentSection
            }
        }
        .background(Color.bgMain)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Retour") {
                    onBack()
                }
                .foregroundStyle(.accentPrimary)
            }
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 8) {
                    Button {
                        viewModel.toggleFavorite()
                    } label: {
                        Image(systemName: viewModel.recipe.isFavorite == true ? "heart.fill" : "heart")
                            .foregroundStyle(viewModel.recipe.isFavorite == true ? .accentPrimary : .textMain)
                    }
                    .accessible(label: viewModel.recipe.isFavorite == true ? "Retirer des favoris" : "Ajouter aux favoris")

                    Button {
                        viewModel.copyLink()
                    } label: {
                        Image(systemName: viewModel.isCopied ? "checkmark" : "square.and.arrow.up")
                            .foregroundStyle(viewModel.isCopied ? .accentPrimary : .textMain)
                    }
                    .accessible(label: "Partager la recette")

                    if isAdmin {
                        Button("Modifier") {
                            onEdit()
                        }
                        .foregroundStyle(.accentPrimary)

                        Button {
                            showDeleteAlert = true
                        } label: {
                            Image(systemName: "trash")
                                .foregroundStyle(.red)
                        }
                        .accessible(label: "Supprimer la recette")
                    }

                    Button {
                        viewModel.showShoppingList = true
                    } label: {
                        Image(systemName: "cart")
                            .foregroundStyle(.textMain)
                    }
                    .accessible(label: "Liste de courses")
                }
            }
        }
        .task {
            await viewModel.loadSettings()
        }
        .alert("Supprimer la recette ?", isPresented: $showDeleteAlert) {
            Button("Annuler", role: .cancel) {}
            Button("Supprimer", role: .destructive) {
                Task {
                    do {
                        try await viewModel.deleteRecipe()
                        onDelete()
                    } catch {
                        // handle error
                    }
                }
            }
        } message: {
            Text("Cette action est irréversible. Es-tu sûr de vouloir supprimer \"\(viewModel.recipe.title)\" ?")
        }
        .sheet(isPresented: $viewModel.showShoppingList) {
            ShoppingListView(recipe: viewModel.recipe)
        }
        .sheet(isPresented: $viewModel.showImageGenerationSheet) {
            Text("Génération d'image d'ingrédient")
        }
        .alert("Erreur", isPresented: $viewModel.showGenerationError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.generationError ?? "")
        }
    }

    private var heroSection: some View {
        ZStack(alignment: .bottomLeading) {
            if let imageUrl = viewModel.recipe.imageUrl, let url = URL(string: imageUrl) {
                AsyncImageView(url: url)
                    .frame(height: 280)
                    .clipped()
            } else {
                LinearGradient(
                    colors: [.accentPrimary.opacity(0.3), .accentSecondary.opacity(0.3)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .frame(height: 280)
                .overlay(
                    Image(systemName: "photo")
                        .font(.system(size: 48))
                        .foregroundStyle(.white)
                )
            }

            LinearGradient(
                colors: [.clear, .bgMain.opacity(0.97)],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(height: 280)

            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 8) {
                    HStack(spacing: 4) {
                        Text(viewModel.categoryEmojis[viewModel.recipe.category] ?? "🍽️")
                        Text(viewModel.recipe.category == "dessert" ? "Dessert" : "Plat")
                    }
                    .font(.system(size: 10, weight: .bold))
                    .tracking(1.5)
                    .textCase(.uppercase)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.bgCard)
                    .clipShape(Capsule())
                    .shadow(color: .shadowCard.opacity(0.06), radius: 4, x: 0, y: 2)

                    if let country = viewModel.recipe.country {
                        HStack(spacing: 4) {
                            Text(country)
                        }
                        .font(.system(size: 10, weight: .bold))
                        .tracking(1.5)
                        .textCase(.uppercase)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.bgCard)
                        .clipShape(Capsule())
                        .shadow(color: .shadowCard.opacity(0.06), radius: 4, x: 0, y: 2)
                    }
                }

                Text(viewModel.recipe.title.htmlStripped())
                    .font(.system(size: 32, weight: .bold, design: .serif))
                    .foregroundStyle(.textMain)
                    .lineLimit(2)
            }
            .padding(20)
        }
    }

    private var contentSection: some View {
        VStack(alignment: .leading, spacing: 24) {
            if let desc = viewModel.recipe.description, !desc.isBlank {
                HStack(spacing: 12) {
                    Image(systemName: "quote.opening")
                        .font(.system(size: 16))
                        .foregroundStyle(.accentPrimary)
                        .frame(width: 32, height: 32)
                        .background(
                            LinearGradient(colors: [.accentPrimary, .accentSecondary], startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 10))

                    Text(desc)
                        .font(.system(size: 14, design: .serif))
                        .italic()
                        .foregroundStyle(.textMain)
                        .lineSpacing(4)
                }
                .padding(12)
                .background(Color.bgCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(Color.borderCard, lineWidth: 1)
                )
            }

            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    SectionHeader(title: "Ingrédients")

                    if viewModel.showPortions {
                        HStack(spacing: 12) {
                            Text("Personnes")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(.textSecondary)

                            HStack(spacing: 12) {
                                Button {
                                    viewModel.changePortions(delta: -1)
                                } label: {
                                    Text("−")
                                        .font(.system(size: 18, weight: .bold))
                                        .frame(width: 32, height: 32)
                                        .background(
                                            LinearGradient(colors: [.accentPrimary, .accentSecondary], startPoint: .topLeading, endPoint: .bottomTrailing)
                                        )
                                        .foregroundStyle(.white)
                                        .clipShape(Circle())
                                }
                                .accessible(label: "Diminuer les portions")

                                Text("\(viewModel.currentPortions)")
                                    .font(.system(size: 20, weight: .bold, design: .serif))
                                    .foregroundStyle(.accentPrimary)
                                    .frame(minWidth: 28)

                                Button {
                                    viewModel.changePortions(delta: 1)
                                } label: {
                                    Text("+")
                                        .font(.system(size: 18, weight: .bold))
                                        .frame(width: 32, height: 32)
                                        .background(
                                            LinearGradient(colors: [.accentPrimary, .accentSecondary], startPoint: .topLeading, endPoint: .bottomTrailing)
                                        )
                                        .foregroundStyle(.white)
                                        .clipShape(Circle())
                                }
                                .accessible(label: "Augmenter les portions")
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color.bgHover)
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(Color.borderInput, lineWidth: 1.5))
                    }

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 90))], spacing: 12) {
                        ForEach(Array(viewModel.cleanIngredients.enumerated()), id: \.offset) { idx, ingredient in
                            IngredientRow(
                                ingredient: viewModel.scaleIngredient(ingredient, index: idx),
                                originalIngredient: ingredient,
                                hasAlternative: ingredient.contains("||"),
                                isSwapped: viewModel.swappedIngredients[idx] ?? false,
                                imageUrl: viewModel.ingredientImageUrl(name: viewModel.scaleIngredient(ingredient, index: idx)),
                                isAdmin: isAdmin,
                                onSwap: {
                                    viewModel.toggleSwapIngredient(index: idx)
                                },
                                onTap: {
                                    if isAdmin {
                                        viewModel.selectedIngredient = ingredient
                                        viewModel.showIngredientImagePicker = true
                                    }
                                }
                            )
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            if !viewModel.foundSpices.isEmpty && viewModel.recipe.category != "dessert" {
                VStack(alignment: .leading, spacing: 8) {
                    SectionHeader(title: "Épices & Assaisonnements")

                    FlowLayout(spacing: 8) {
                        ForEach(viewModel.foundSpices, id: \.self) { spice in
                            Text("🌿 \(spice.capitalized)")
                                .font(.system(size: 12, weight: .bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.bgHover)
                                .foregroundStyle(.accentPrimary)
                                .clipShape(Capsule())
                                .overlay(Capsule().stroke(Color.borderInput, lineWidth: 1))
                        }
                    }
                }
            }

            if !viewModel.equipment.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    SectionHeader(title: "Matériel")

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 12) {
                        ForEach(viewModel.equipment, id: \.name) { item in
                            VStack(spacing: 6) {
                                if let urlString = item.imageUrl, let url = URL(string: urlString) {
                                    AsyncImage(url: url) { phase in
                                        switch phase {
                                        case .success(let image):
                                            image.resizable().scaledToFit()
                                        default:
                                            Image(systemName: "fork.knife")
                                                .foregroundStyle(.textPlaceholder)
                                        }
                                    }
                                    .frame(width: 60, height: 60)
                                    .background(Color.bgCard)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))
                                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderInput, lineWidth: 1))
                                } else {
                                    Image(systemName: "fork.knife")
                                        .font(.system(size: 24))
                                        .frame(width: 60, height: 60)
                                        .background(Color.bgCard)
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderInput, lineWidth: 1))
                                }
                                Text(item.name)
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundStyle(.textMain)
                                    .multilineTextAlignment(.center)
                            }
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                SectionHeader(title: "Préparation")

                VStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(viewModel.instructions.enumerated()), id: \.offset) { idx, step in
                        HStack(alignment: .top, spacing: 12) {
                            Text("\(idx + 1)")
                                .font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(width: 36, height: 36)
                                .background(
                                    LinearGradient(colors: [.accentPrimary, .accentSecondary], startPoint: .topLeading, endPoint: .bottomTrailing)
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .shadow(color: .shadowAccent.opacity(0.2), radius: 5, x: 0, y: 3)

                            Text(step)
                                .font(.system(size: 15))
                                .foregroundStyle(.textMain)
                                .lineSpacing(6)
                                .padding(.top, 6)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding(.vertical, 12)
                        .if(idx < viewModel.instructions.count - 1) { view in
                            view.overlay(
                                Divider()
                                    .padding(.leading, 48)
                                    .padding(.top, 12)
                                    .frame(maxHeight: .infinity, alignment: .bottom)
                            )
                        }
                    }
                }
            }

            if let related = viewModel.recipe.relatedRecipes, !related.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    SectionHeader(title: "Recettes liées")
                    ForEach(related, id: \.id) { r in
                        Text(r.title)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(.accentPrimary)
                    }
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .padding(.bottom, 40)
    }
}

private struct SectionHeader: View {
    let title: String

    var body: some View {
        HStack(spacing: 8) {
            Text(title)
                .font(.system(size: 11, weight: .bold))
                .tracking(0.25)
                .textCase(.uppercase)
                .foregroundStyle(.accentPrimary)
            Divider()
                .background(
                    LinearGradient(colors: [.accentGold, .clear], startPoint: .leading, endPoint: .trailing)
                )
        }
    }
}

private struct IngredientRow: View {
    let ingredient: String
    let originalIngredient: String
    let hasAlternative: Bool
    let isSwapped: Bool
    let imageUrl: String?
    let isAdmin: Bool
    let onSwap: () -> Void
    let onTap: () -> Void

    var body: some View {
        VStack(spacing: 6) {
            ZStack(alignment: .topTrailing) {
                Button(action: onTap) {
                    IngredientImage(name: ingredient, imageUrl: imageUrl, size: 80)
                }
                .disabled(!isAdmin)

                if hasAlternative {
                    Button(action: onSwap) {
                        Image(systemName: "arrow.2.circlepath")
                            .font(.system(size: 10))
                            .frame(width: 22, height: 22)
                            .background(Color.bgCard)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.borderCard, lineWidth: 1))
                    }
                    .offset(x: 8, y: -8)
                    .accessible(label: "Remplacer l'ingrédient")
                }
            }

            Text(ingredient)
                .font(.system(size: 12))
                .multilineTextAlignment(.center)
                .foregroundStyle(.textMain)
                .lineLimit(2)
        }
    }
}

private struct ShoppingListView: View {
    let recipe: Recipe
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(recipe.ingredients, id: \.self) { ingredient in
                    Text(ingredient)
                }
            }
            .navigationTitle("Liste de courses")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Fermer") {
                        dismiss()
                    }
                }
            }
        }
    }
}

private struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let result = FlowResult(in: proposal.width ?? 0, subviews: subviews, spacing: spacing)
        return result.size
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = FlowResult(in: bounds.width, subviews: subviews, spacing: spacing)
        for (index, subview) in subviews.enumerated() {
            subview.place(at: CGPoint(x: bounds.minX + result.positions[index].x, y: bounds.minY + result.positions[index].y), proposal: .unspecified)
        }
    }

    struct FlowResult {
        var size: CGSize = .zero
        var positions: [CGPoint] = []

        init(in maxWidth: CGFloat, subviews: Subviews, spacing: CGFloat) {
            var x: CGFloat = 0
            var y: CGFloat = 0
            var lineHeight: CGFloat = 0
            var positions: [CGPoint] = []

            for subview in subviews {
                let size = subview.sizeThatFits(.unspecified)
                if x + size.width > maxWidth && x > 0 {
                    x = 0
                    y += lineHeight + spacing
                    lineHeight = 0
                }
                positions.append(CGPoint(x: x, y: y))
                x += size.width + spacing
                lineHeight = max(lineHeight, size.height)
            }

            self.positions = positions
            self.size = CGSize(width: maxWidth, height: y + lineHeight)
        }
    }
}

private extension View {
    @ViewBuilder func if<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}

#Preview {
    NavigationStack {
        RecipeDetailView(
            viewModel: RecipeDetailViewModel(
                recipe: Recipe(
                    id: "1",
                    title: "Tarte aux Pommes",
                    description: "Une tarte classique",
                    ingredients: ["3 pommes", "200g farine", "100g sucre || 100g cassonade", "100g beurre"],
                    spices: ["cannelle"],
                    equipment: [EquipmentItem(name: "Four", imageUrl: nil)],
                    instructions: "1. Préparer la pâte\n2. Éplucher les pommes\n3. Cuire 30 min à 180°C",
                    category: "dessert",
                    servings: 6,
                    showPortions: true,
                    imageUrl: nil,
                    country: "France",
                    hidden: false,
                    isSecondary: false,
                    isFavorite: false,
                    relatedRecipes: nil,
                    createdAt: nil,
                    updatedAt: nil
                )
            ),
            isAdmin: false,
            onEdit: {},
            onDelete: {},
            onBack: {}
        )
    }
}
