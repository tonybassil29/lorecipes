import SwiftUI
import UIKit

@Observable
final class RecipeDetailViewModel {
    var recipe: Recipe
    var currentPortions: Int
    var showDeleteConfirm = false
    var showShoppingList = false
    var isCopied = false
    var showIngredientImagePicker = false
    var selectedIngredient: String?
    var customImages: [String: String] = [:]
    var isLoadingImages = false
    var globalSpices: [String] = []
    var showImageGenerationSheet = false
    var generationError: String?
    var showGenerationError = false
    var isGenerating = false
    var swappedIngredients: [Int: Bool] = [:]
    var categoryEmojis: [String: String] = ["plat": "🍽️", "dessert": "🍰"]

    private let supabase = SupabaseService.shared
    private let favorites = FavoritesService.shared
    private let settings = SettingsService.shared
    private let cloudinary = CloudinaryService.shared

    init(recipe: Recipe) {
        self.recipe = recipe
        self.currentPortions = recipe.servings
    }

    var basePortions: Int { recipe.servings }
    var showPortions: Bool { recipe.showPortions ?? (recipe.category == "dessert") }

    var cleanIngredients: [String] {
        recipe.ingredients.filter { ing in
            !globalSpices.contains(where: { spice in
                ing.lowercased().trimmingCharacters(in: .whitespaces) == spice.lowercased()
            })
        }
    }

    var foundSpices: [String] {
        var result = Set<String>()
        let allText = recipe.ingredients.joined(separator: " ") + " " + recipe.instructions
        for spice in globalSpices {
            if allText.lowercased().contains(spice.lowercased()) {
                result.insert(spice)
            }
        }
        if let spices = recipe.spices {
            for s in spices {
                result.insert(s.lowercased())
            }
        }
        return Array(result)
    }

    var equipment: [EquipmentItem] {
        recipe.equipment ?? []
    }

    var instructions: [String] {
        recipe.instructionsList
    }

    func loadSettings() async {
        let settings = await settings.loadSettings()
        if let emojis = settings.categoryEmojis {
            categoryEmojis.merge(emojis) { _, new in new }
        }
        if let custom = settings.customIngredientImages {
            customImages = custom
        }
        do {
            globalSpices = try await fetchGlobalSpices()
        } catch {
            print("Error loading spices: \(error)")
        }
    }

    func toggleFavorite() {
        guard let id = recipe.id else { return }
        favorites.toggleFavorite(recipeId: id)
        recipe.isFavorite = favorites.isFavorite(recipeId: id)
    }

    func shareRecipe() {
        let text = "Découvre la recette : \(recipe.title) 🍽️"
        let url = "https://akel-loulou.app/recette/\(recipe.title.slugified())"
        let activityItems: [Any] = [text, url]
        let activityVC = UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let root = windowScene.windows.first?.rootViewController {
            root.present(activityVC, animated: true)
        }
    }

    func copyLink() {
        let url = "https://akel-loulou.app/recette/\(recipe.title.slugified())"
        UIPasteboard.general.string = url
        isCopied = true
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            isCopied = false
        }
    }

    func changePortions(delta: Int) {
        let next = currentPortions + delta
        if next >= 1 && next <= 20 {
            currentPortions = next
        }
    }

    func toggleSwapIngredient(index: Int) {
        swappedIngredients[index] = !(swappedIngredients[index] ?? false)
    }

    func ingredientImageUrl(name: String) -> String? {
        let lower = name.lowercased()
        if let custom = customImages[lower] { return custom }
        return mealDBIngredientImage(name: name)
    }

    func uploadIngredientImage(_ image: UIImage, for name: String) async {
        isLoadingImages = true
        defer { isLoadingImages = false }
        do {
            let url = try await cloudinary.uploadImage(image)
            customImages[name.lowercased()] = url
            var settings = await settings.loadSettings()
            settings.customIngredientImages = customImages
            try await self.settings.saveSettings(settings)
        } catch {
            generationError = "Erreur d'upload: \(error.localizedDescription)"
            showGenerationError = true
        }
    }

    func deleteRecipe() async throws {
        guard let id = recipe.id else { throw AppError.recipeNotFound }
        try await supabase.deleteRecipe(id: id)
    }

    private func fetchGlobalSpices() async throws -> [String] {
        let url = URL(string: "https://dkxtmhlrewmueuwcxeki.supabase.co/rest/v1/settings?key=eq.all_spices&select=value&limit=1")!
        var request = URLRequest(url: url)
        request.setValue("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRreHRtaGxyZXdtdWV1d2N4ZWtpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM1MDAxODUsImV4cCI6MjA4OTA3NjE4NX0.bwf9Bqt0N7QCV7sX9SHQPOqt2G8CGJv6WSmrp-iqrW0", forHTTPHeaderField: "apikey")
        let (data, _) = try await URLSession.shared.data(for: request)
        let json = try JSONSerialization.jsonObject(with: data) as? [[String: Any]]
        if let value = json?.first?["value"] as? [String] {
            return value
        }
        return []
    }

    private func mealDBIngredientImage(name: String) -> String? {
        let map: [String: String] = [
            "farine": "Flour", "sucre vanillé": "Vanilla%20extract", "cassonade": "Brown%20Sugar",
            "sucre glace": "Icing%20Sugar", "sucre": "Sugar", "levure chimique": "Baking%20Powder",
            "levure boulangère": "Yeast", "levure": "Baking%20Powder", "bicarbonate": "Baking%20Soda",
            "maïzena": "Cornstarch", "fécule": "Cornstarch", "beurre de cacahuète": "Peanut%20Butter",
            "peanut butter": "Peanut%20Butter", "beurre": "Butter", "lait": "Milk",
            "oeufs": "Egg", "oeuf": "Egg", "chocolat": "Chocolate", "sel": "Salt",
            "poivre": "Pepper", "huile": "Olive%20Oil", "miel": "Honey", "banane": "Banana",
            "pomme": "Apple", "tomate": "Tomato", "oignon": "Onion", "ail": "Garlic",
            "poulet": "Chicken", "boeuf": "Beef", "saumon": "Salmon", "eau": "Water",
            "crème fraîche": "Cream", "crème": "Cream", "fromage": "Cheese", "gruyère": "Cheese",
            "parmesan": "Parmesan%20Cheese", "citron": "Lemon", "fraise": "Strawberries",
            "framboise": "Raspberries", "amande": "Almonds", "noix": "Walnuts",
            "noisette": "Hazelnuts", "cacao": "Cocoa", "moutarde": "Mustard",
            "vinaigre": "Vinegar", "bouillon": "Chicken%20Stock", "vin blanc": "White%20Wine",
            "vin rouge": "Red%20Wine", "riz": "Rice", "pâtes": "Penne%20Rigate",
            "pomme de terre": "Potatoes", "carotte": "Carrots"
        ]
        let lower = name.lowercased()
        for (key, value) in map {
            if lower.contains(key) {
                return "https://www.themealdb.com/images/ingredients/\(value).png"
            }
        }
        return nil
    }

    func scaleIngredient(_ ingredient: String, index: Int) -> String {
        let isSwapped = swappedIngredients[index] ?? false
        let parts = ingredient.split(separator: "||").map { String($0).trimmingCharacters(in: .whitespaces) }
        let active = (isSwapped && parts.count > 1) ? parts[1] : parts[0]

        if currentPortions == basePortions { return active }
        let ratio = Double(currentPortions) / Double(basePortions)

        // Simple regex to find quantity at start
        let pattern = "^(\\d+(?:[.,]\\d+)?(?:/\\d+)?(?:-\\d+)?)\\s*(g|kg|ml|cl|l|càs|càc|cuillère|pincée|sachet|gousse|tranche|cc|cs)?s?\\s*(de|d')?\\s*(.*)$"
        if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive),
           let match = regex.firstMatch(in: active, options: [], range: NSRange(location: 0, length: active.utf16.count)) {
            let qtyRange = match.range(at: 1)
            let unitRange = match.range(at: 2)
            let restRange = match.range(at: 4)

            if let qtyRange = Range(qtyRange, in: active) {
                let qtyStr = String(active[qtyRange])
                let scaledQty = parseAndScale(qtyStr, ratio: ratio)
                let unit = Range(unitRange, in: active).map { String(active[$0]) } ?? ""
                let rest = Range(restRange, in: active).map { String(active[$0]) } ?? ""
                return "\(scaledQty) \(unit) \(rest)".trimmingCharacters(in: .whitespaces)
            }
        }
        return active
    }

    private func parseAndScale(_ qtyStr: String, ratio: Double) -> String {
        if qtyStr.contains("/") {
            let parts = qtyStr.split(separator: "/")
            if parts.count == 2,
               let num = Double(parts[0].replacingOccurrences(of: ",", with: ".")),
               let den = Double(parts[1]) {
                let result = num / den * ratio
                return formatNumber(result)
            }
        }
        if qtyStr.contains("-") {
            let parts = qtyStr.split(separator: "-")
            if parts.count == 2,
               let a = Double(parts[0].replacingOccurrences(of: ",", with: ".")),
               let b = Double(parts[1].replacingOccurrences(of: ",", with: ".")) {
                let result = (a + b) / 2 * ratio
                return formatNumber(result)
            }
        }
        if let val = Double(qtyStr.replacingOccurrences(of: ",", with: ".")) {
            return formatNumber(val * ratio)
        }
        return qtyStr
    }

    private func formatNumber(_ num: Double) -> String {
        if num == Double(Int(num)) { return String(Int(num)) }
        let rounded = round(num * 10) / 10
        if rounded == Double(Int(rounded)) { return String(Int(rounded)) }
        return String(rounded)
    }
}
