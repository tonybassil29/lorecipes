import Foundation
import SwiftUI

@Observable
final class RecipeSuggestionViewModel {
    var userName: String = ""
    var recipeName: String = ""
    var description: String = ""
    var isSubmitting: Bool = false
    var errorMessage: String = ""
    var showError: Bool = false
    var showSuccess: Bool = false

    func submit() async {
        let trimmedRecipeName = recipeName.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedRecipeName.isEmpty else {
            errorMessage = "Le nom de la recette est requis"
            showError = true
            return
        }

        isSubmitting = true
        defer { isSubmitting = false }

        let suggestion = RecipeSuggestion(
            id: UUID().uuidString,
            userName: userName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : userName.trimmingCharacters(in: .whitespacesAndNewlines),
            recipeName: trimmedRecipeName,
            description: description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : description.trimmingCharacters(in: .whitespacesAndNewlines),
            createdAt: nil
        )

        do {
            try await SupabaseService.shared.addSuggestion(suggestion)
            userName = ""
            recipeName = ""
            description = ""
            showSuccess = true
        } catch {
            errorMessage = "Erreur lors de l'envoi : \(error.localizedDescription)"
            showError = true
        }
    }
}
