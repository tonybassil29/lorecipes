import SwiftUI

struct RecipeSuggestionView: View {
    let onClose: () -> Void
    @State private var viewModel = RecipeSuggestionViewModel()
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Votre nom (optionnel)", text: $viewModel.userName)
                        .accessibilityLabel("Nom de l'utilisateur")
                        .accessibilityHint("Entrez votre nom, optionnel")

                    TextField("Nom de la recette *", text: $viewModel.recipeName)
                        .accessibilityLabel("Nom de la recette")
                        .accessibilityHint("Entrez le nom de la recette suggérée, obligatoire")

                    TextEditor(text: $viewModel.description)
                        .frame(minHeight: 100)
                        .accessibilityLabel("Description de la recette")
                        .accessibilityHint("Entrez une description de la recette, optionnel")
                }

                Section {
                    Button {
                        Task {
                            await viewModel.submit()
                        }
                    } label: {
                        if viewModel.isSubmitting {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle())
                                .accessibilityLabel("Envoi en cours")
                        } else {
                            Text("Soumettre")
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .disabled(viewModel.isSubmitting || viewModel.recipeName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityLabel("Soumettre la suggestion")
                    .accessibilityHint("Soumet votre suggestion de recette")
                }
            }
            .navigationTitle("Suggérer une recette")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        dismiss()
                        onClose()
                    } label: {
                        Text("Fermer")
                    }
                    .accessibilityLabel("Fermer")
                    .accessibilityHint("Ferme la fenêtre de suggestion")
                }
            }
            .alert("Erreur", isPresented: $viewModel.showError) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(viewModel.errorMessage)
            }
            .alert("Succès", isPresented: $viewModel.showSuccess) {
                Button("OK", role: .cancel) {
                    dismiss()
                    onClose()
                }
            } message: {
                Text("Merci pour votre suggestion ! Elle sera examinée par l'équipe.")
            }
        }
    }
}

#Preview {
    RecipeSuggestionView(onClose: {})
}
