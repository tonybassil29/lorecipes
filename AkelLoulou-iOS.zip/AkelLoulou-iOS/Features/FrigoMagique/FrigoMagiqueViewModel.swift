import SwiftUI

struct MatchedRecipe: Identifiable, Sendable {
    let id: String
    let recipe: Recipe
    let matchedIngredients: [String]
    let missingIngredients: [String]
    let staplesUsed: [String]
    let matchPercentage: Double

    init(
        recipe: Recipe,
        matchedIngredients: [String],
        missingIngredients: [String],
        staplesUsed: [String],
        matchPercentage: Double
    ) {
        self.id = recipe.id ?? UUID().uuidString
        self.recipe = recipe
        self.matchedIngredients = matchedIngredients
        self.missingIngredients = missingIngredients
        self.staplesUsed = staplesUsed
        self.matchPercentage = matchPercentage
    }
}

@Observable
final class FrigoMagiqueViewModel {
    var recipes: [Recipe] = []
    var ingredients: [String] = []
    var inputText: String = ""
    var filterCategory: String = "all"
    var filterCountry: String = "all"
    var isLoading: Bool = false
    var isParsing: Bool = false
    var matchedRecipes: [MatchedRecipe] = []
    var errorMessage: String?
    var showError: Bool = false

    private let supabase = SupabaseService.shared
    private let staples = ["sel", "poivre", "eau", "huile", "epices", "vinaigre"]

    var availableCategories: [String] {
        Array(Set(recipes.map { $0.category })).sorted()
    }

    var availableCountries: [String] {
        Array(Set(recipes.compactMap { $0.country })).sorted()
    }

    func loadRecipes() async {
        isLoading = true
        errorMessage = nil
        do {
            let fetched = try await supabase.fetchRecipes(
                includeHidden: false,
                includeSecondary: false
            )
            recipes = fetched.filter { $0.isVisible && $0.isMainRecipe }
            calculateMatches()
        } catch {
            errorMessage = "Erreur de chargement: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func addIngredient() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let normalized = trimmed.normalizedForSearch()
        guard !normalized.isEmpty,
              !ingredients.contains(normalized),
              !isStaple(normalized) else { return }
        ingredients.append(normalized)
        inputText = ""
        calculateMatches()
    }

    func removeIngredient(at index: Int) {
        guard ingredients.indices.contains(index) else { return }
        ingredients.remove(at: index)
        calculateMatches()
    }

    func handleMagicParse() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        isParsing = true

        let separators = CharacterSet(charactersIn: ",;.-")
        let components = trimmed.components(separatedBy: separators)

        var newIngredients: [String] = []
        for component in components {
            let clean = component.trimmingCharacters(in: .whitespacesAndNewlines)
            let normalized = clean.normalizedForSearch()
            guard !normalized.isEmpty,
                  !ingredients.contains(normalized),
                  !isStaple(normalized) else { continue }
            newIngredients.append(normalized)
        }

        ingredients.append(contentsOf: newIngredients)
        inputText = ""
        isParsing = false
        calculateMatches()
    }

    func calculateMatches() {
        var results: [MatchedRecipe] = []
        let userIngredients = ingredients

        for recipe in recipes {
            let recipeIngredients = recipe.ingredients.map { $0.normalizedForSearch() }

            var matched: [String] = []
            var missing: [String] = []
            var usedStaples: [String] = []

            for ing in recipeIngredients {
                if isStaple(ing) {
                    usedStaples.append(ing)
                    continue
                }

                if isIngredientMatched(ing, against: userIngredients) {
                    matched.append(ing)
                } else {
                    missing.append(ing)
                }
            }

            let totalNonStaple = recipeIngredients.filter { !isStaple($0) }.count
            guard totalNonStaple > 0 else { continue }

            let matchPercentage = Double(matched.count) / Double(totalNonStaple) * 100.0
            guard matchPercentage >= 50, !matched.isEmpty else { continue }

            results.append(MatchedRecipe(
                recipe: recipe,
                matchedIngredients: matched,
                missingIngredients: missing,
                staplesUsed: usedStaples,
                matchPercentage: matchPercentage
            ))
        }

        if filterCategory != "all" {
            results = results.filter { $0.recipe.category == filterCategory }
        }

        if filterCountry != "all" {
            results = results.filter { $0.recipe.country == filterCountry }
        }

        results.sort {
            if $0.matchPercentage != $1.matchPercentage {
                return $0.matchPercentage > $1.matchPercentage
            }
            if $0.missingIngredients.count != $1.missingIngredients.count {
                return $0.missingIngredients.count < $1.missingIngredients.count
            }
            return $0.matchedIngredients.count > $1.matchedIngredients.count
        }

        matchedRecipes = results
    }

    private func isStaple(_ ingredient: String) -> Bool {
        let normalized = ingredient.normalizedForSearch()
        return staples.contains { staple in
            normalized.contains(staple) || staple.contains(normalized)
        }
    }

    private func isIngredientMatched(
        _ recipeIngredient: String,
        against userIngredients: [String]
    ) -> Bool {
        let recipeNormalized = recipeIngredient.normalizedForSearch()

        for userIng in userIngredients {
            let userNormalized = userIng.normalizedForSearch()

            if userNormalized == recipeNormalized {
                return true
            }

            if userNormalized.contains(recipeNormalized) {
                return true
            }

            if recipeNormalized.contains(userNormalized) {
                let userWords = userNormalized.split(separator: " ").count
                if userWords > 1 {
                    return true
                }
            }
        }

        return false
    }
}
