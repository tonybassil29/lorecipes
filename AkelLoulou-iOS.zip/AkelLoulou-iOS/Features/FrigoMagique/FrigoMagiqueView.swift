import SwiftUI

struct FrigoMagiqueView: View {
    @Bindable var viewModel: FrigoMagiqueViewModel
    @Binding var path: NavigationPath

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                heroSection
                ingredientsSection
                filtersSection
                resultsSection
            }
        }
        .background(Color.bgMain)
        .navigationTitle("Frigo Magique")
        .navigationBarTitleDisplayMode(.large)
        .task {
            await viewModel.loadRecipes()
        }
        .alert("Erreur", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
        }
    }

    // MARK: - Sections

    private var heroSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 8) {
                Rectangle()
                    .frame(width: 28, height: 1)
                    .foregroundStyle(.accentGold)
                Text("ingrédients")
                    .font(.system(size: 11, weight: .medium))
                    .tracking(0.32)
                    .textCase(.uppercase)
                    .foregroundStyle(.accentPrimary)
                Rectangle()
                    .frame(width: 28, height: 1)
                    .foregroundStyle(.accentGold)
            }

            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("Frigo")
                    .font(.system(size: 42, weight: .medium, design: .serif))
                    .italic()
                Text("Magique")
                    .font(.system(size: 42, weight: .medium, design: .serif))
                    .italic()
                    .gradientText()
                Text("✨")
                    .font(.system(size: 20))
            }

            Text("Saisissez les ingrédients de votre frigo et laissez la magie opérer.")
                .font(.system(size: 15))
                .foregroundStyle(.textSecondary)
                .lineSpacing(4)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 24)
    }

    private var ingredientsSection: some View {
        VStack(spacing: 12) {
            HStack(spacing: 8) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.textPlaceholder)
                    TextField(
                        "Ex: poulet, riz, carottes…",
                        text: $viewModel.inputText
                    )
                    .font(.system(size: 13.5))
                    .onSubmit {
                        viewModel.addIngredient()
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color.bgCard)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.borderCard, lineWidth: 1))

                Button {
                    viewModel.handleMagicParse()
                } label: {
                    Text("✦")
                        .font(.system(size: 18))
                        .frame(width: 44, height: 44)
                        .background(Color.bgCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.borderCard, lineWidth: 1))
                }
                .accessible(label: "Ajouter plusieurs ingrédients")
                .disabled(viewModel.inputText.isBlank)
            }

            if !viewModel.ingredients.isEmpty {
                FlowLayout(spacing: 8) {
                    ForEach(
                        Array(viewModel.ingredients.enumerated()),
                        id: \.offset
                    ) { index, ingredient in
                        IngredientChip(
                            ingredient: ingredient,
                            onRemove: {
                                viewModel.removeIngredient(at: index)
                            }
                        )
                    }
                }
                .padding(.horizontal, 4)
            }
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    private var filtersSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                FilterPill(
                    label: "Tous",
                    emoji: "◯",
                    isActive: viewModel.filterCategory == "all"
                ) {
                    viewModel.filterCategory = "all"
                    viewModel.calculateMatches()
                }

                ForEach(viewModel.availableCategories, id: \.self) { category in
                    FilterPill(
                        label: category.capitalized,
                        emoji: categoryEmoji(for: category),
                        isActive: viewModel.filterCategory == category
                    ) {
                        viewModel.filterCategory = category
                        viewModel.calculateMatches()
                    }
                }

                if !viewModel.availableCountries.isEmpty {
                    Menu {
                        Button("Tous les pays") {
                            viewModel.filterCountry = "all"
                            viewModel.calculateMatches()
                        }
                        ForEach(viewModel.availableCountries, id: \.self) { country in
                            Button(country) {
                                viewModel.filterCountry = country
                                viewModel.calculateMatches()
                            }
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Text("◯")
                            Text(
                                viewModel.filterCountry == "all"
                                    ? "Pays"
                                    : viewModel.filterCountry
                            )
                            Image(systemName: "chevron.down")
                                .font(.system(size: 10))
                        }
                        .font(.system(size: 12, weight: .medium))
                        .tracking(0.06)
                        .textCase(.uppercase)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(
                            viewModel.filterCountry != "all"
                                ? Color.accentPrimary
                                : Color.clear
                        )
                        .foregroundStyle(
                            viewModel.filterCountry != "all"
                                ? Color.white
                                : Color.textSecondary
                        )
                        .clipShape(Capsule())
                        .overlay(
                            Capsule().stroke(
                                viewModel.filterCountry != "all"
                                    ? Color.accentPrimary
                                    : Color.borderCard,
                                lineWidth: 1
                            )
                        )
                    }
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    private var resultsSection: some View {
        VStack(spacing: 12) {
            if viewModel.isLoading {
                ProgressView()
                    .padding(.top, 40)
            } else if viewModel.matchedRecipes.isEmpty {
                emptyState
            } else {
                LazyVGrid(
                    columns: [GridItem(.flexible()), GridItem(.flexible())],
                    spacing: 12
                ) {
                    ForEach(viewModel.matchedRecipes) { matched in
                        MatchedRecipeCard(
                            matched: matched,
                            onTap: {
                                if let id = matched.recipe.id {
                                    path.append(NavigationDestination.recipe(id))
                                }
                            }
                        )
                    }
                }
                .padding(.horizontal, 16)
            }
        }
        .padding(.bottom, 24)
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "refrigerator")
                .font(.system(size: 48))
                .foregroundStyle(.textPlaceholder)
            Text("Aucune recette trouvée")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.textSecondary)
            Text("Ajoutez des ingrédients pour découvrir des recettes.")
                .font(.system(size: 13))
                .foregroundStyle(.textPlaceholder)
                .multilineTextAlignment(.center)
        }
        .padding(.top, 40)
        .padding(.horizontal, 20)
    }

    // MARK: - Helpers

    private func categoryEmoji(for category: String) -> String {
        switch category {
        case "plat": return "🍽️"
        case "dessert": return "🍰"
        default: return "🍽️"
        }
    }
}

// MARK: - Subviews

private struct IngredientChip: View {
    let ingredient: String
    let onRemove: () -> Void

    var body: some View {
        HStack(spacing: 4) {
            Text(ingredient)
                .font(.system(size: 12, weight: .medium))
            Button(action: onRemove) {
                Image(systemName: "xmark")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.textSecondary)
            }
            .accessible(label: "Supprimer \(ingredient)")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.bgHover)
        .foregroundStyle(.textMain)
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.borderInput, lineWidth: 1))
    }
}

private struct FilterPill: View {
    let label: String
    let emoji: String
    let isActive: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Text(emoji)
                    .font(.system(size: 14))
                Text(label)
                    .font(.system(size: 12, weight: .medium))
                    .tracking(0.06)
                    .textCase(.uppercase)
            }
        }
        .pillStyle(isActive: isActive)
        .accessible(label: "Filtrer par \(label)")
    }
}

private struct MatchedRecipeCard: View {
    let matched: MatchedRecipe
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 12) {
                imageSection
                infoSection
                ingredientsSection
            }
            .padding(12)
            .background(Color.bgCard)
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(
                RoundedRectangle(cornerRadius: 18)
                    .stroke(Color.borderCard, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessible(
            label: "Recette \(matched.recipe.title), \(Int(matched.matchPercentage)) pour cent de correspondance"
        )
    }

    private var imageSection: some View {
        ZStack(alignment: .topTrailing) {
            if let imageUrl = matched.recipe.imageUrl,
               let url = URL(string: imageUrl) {
                AsyncImageView(url: url)
                    .frame(height: 160)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            } else {
                placeholderImage
                    .frame(height: 160)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }

            HStack(spacing: 4) {
                if let country = matched.recipe.country {
                    Text(country)
                        .font(.system(size: 10, weight: .bold))
                        .tracking(1.5)
                        .textCase(.uppercase)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.bgCard)
                        .clipShape(Capsule())
                }
                Text(matched.recipe.category.capitalized)
                    .font(.system(size: 10, weight: .bold))
                    .tracking(1.5)
                    .textCase(.uppercase)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.bgCard)
                    .clipShape(Capsule())
            }
            .padding(8)
        }
    }

    private var placeholderImage: some View {
        LinearGradient(
            colors: [
                .accentPrimary.opacity(0.3),
                .accentSecondary.opacity(0.3)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .overlay(
            Image(systemName: "photo")
                .font(.system(size: 48))
                .foregroundStyle(.white)
        )
    }

    private var infoSection: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(matched.recipe.title.htmlStripped())
                    .font(.system(size: 16, weight: .bold, design: .serif))
                    .foregroundStyle(.textMain)
                    .lineLimit(2)

                Text(
                    "\(matched.matchedIngredients.count) sur \(matched.matchedIngredients.count + matched.missingIngredients.count) ingrédients"
                )
                .font(.system(size: 12))
                .foregroundStyle(.textSecondary)
            }

            Spacer()

            CircularProgress(percentage: matched.matchPercentage, size: 48)
        }
    }

    private var ingredientsSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            if !matched.matchedIngredients.isEmpty {
                ingredientRow(
                    title: "Vous avez",
                    items: matched.matchedIngredients,
                    color: .green
                )
            }
            if !matched.staplesUsed.isEmpty {
                ingredientRow(
                    title: "Staples",
                    items: matched.staplesUsed,
                    color: .blue
                )
            }
            if !matched.missingIngredients.isEmpty {
                ingredientRow(
                    title: "Manque",
                    items: matched.missingIngredients,
                    color: .orange
                )
            }
        }
    }

    private func ingredientRow(
        title: String,
        items: [String],
        color: Color
    ) -> some View {
        HStack(alignment: .top, spacing: 4) {
            Text(title)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(color)
                .frame(width: 60, alignment: .leading)

            Text(items.joined(separator: ", "))
                .font(.system(size: 11))
                .foregroundStyle(.textSecondary)
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

// MARK: - Layout

private struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(
        proposal: ProposedViewSize,
        subviews: Subviews,
        cache: inout ()
    ) -> CGSize {
        let result = FlowResult(
            in: proposal.width ?? 0,
            subviews: subviews,
            spacing: spacing
        )
        return result.size
    }

    func placeSubviews(
        in bounds: CGRect,
        proposal: ProposedViewSize,
        subviews: Subviews,
        cache: inout ()
    ) {
        let result = FlowResult(
            in: bounds.width,
            subviews: subviews,
            spacing: spacing
        )
        for (index, subview) in subviews.enumerated() {
            subview.place(
                at: CGPoint(
                    x: bounds.minX + result.positions[index].x,
                    y: bounds.minY + result.positions[index].y
                ),
                proposal: .unspecified
            )
        }
    }

    struct FlowResult {
        var size: CGSize = .zero
        var positions: [CGPoint] = []

        init(in maxWidth: CGFloat, subviews: Subviews, spacing: CGFloat) {
            var x: CGFloat = 0
            var y: CGFloat = 0
            var lineHeight: CGFloat = 0
            var positions: [CGPoint] = []

            for subview in subviews {
                let size = subview.sizeThatFits(.unspecified)
                if x + size.width > maxWidth && x > 0 {
                    x = 0
                    y += lineHeight + spacing
                    lineHeight = 0
                }
                positions.append(CGPoint(x: x, y: y))
                x += size.width + spacing
                lineHeight = max(lineHeight, size.height)
            }

            self.positions = positions
            self.size = CGSize(width: maxWidth, height: y + lineHeight)
        }
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        FrigoMagiqueView(
            viewModel: FrigoMagiqueViewModel(),
            path: .constant(NavigationPath())
        )
    }
}
