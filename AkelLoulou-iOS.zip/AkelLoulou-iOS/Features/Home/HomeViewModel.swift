import SwiftUI

@Observable
final class HomeViewModel {
    var recipes: [Recipe] = []
    var filteredRecipes: [Recipe] = []
    var searchQuery = ""
    var activeFilter: CategoryFilter = .all
    var activeCountry = "all"
    var visibilityFilter: VisibilityFilter = .all
    var isLoading = false
    var errorMessage: String?
    var showError = false
    var isAdmin = false
    var isEditingHeader = false
    var headerData = HeaderSettings()
    var availableCountries: [String] = []
    var showCountryMenu = false
    var showVisibilityMenu = false
    var showSuggestionSheet = false

    private let supabase = SupabaseService.shared
    private let favorites = FavoritesService.shared
    private let settings = SettingsService.shared

    func loadRecipes() async {
        isLoading = true
        errorMessage = nil
        do {
            let fetched = try await supabase.fetchRecipes(includeHidden: isAdmin, includeSecondary: isAdmin)
            recipes = fetched.map { recipe in
                var r = recipe
                if let id = r.id {
                    r.isFavorite = favorites.isFavorite(recipeId: id)
                }
                return r
            }
            availableCountries = Array(Set(recipes.compactMap { $0.country })).sorted()
            applyFilters()
        } catch {
            errorMessage = "Erreur de chargement: \(error.localizedDescription)"
            showError = true
        }
        isLoading = false
    }

    func loadHeader() async {
        headerData = await settings.loadHeaderSettings()
    }

    func applyFilters() {
        var result = recipes

        if !isAdmin {
            result = result.filter { $0.hidden != true }
        } else {
            switch visibilityFilter {
            case .visible: result = result.filter { $0.hidden != true }
            case .hidden: result = result.filter { $0.hidden == true }
            case .all: break
            }
        }

        switch activeFilter {
        case .favorite:
            result = result.filter { $0.isFavorite == true }
        case .plat:
            result = result.filter { $0.category == "plat" }
        case .dessert:
            result = result.filter { $0.category == "dessert" }
        case .all:
            break
        }

        if activeCountry != "all" {
            result = result.filter { $0.country == activeCountry }
        }

        if !searchQuery.isBlank {
            let query = searchQuery.normalizedForSearch()
            result = result.filter { recipe in
                let nameMatch = recipe.title.normalizedForSearch().contains(query)
                let ingMatch = recipe.ingredients.contains { $0.normalizedForSearch().contains(query) }
                let spiceMatch = (recipe.spices ?? []).contains { $0.normalizedForSearch().contains(query) }
                let equipMatch = (recipe.equipment ?? []).contains { $0.name.normalizedForSearch().contains(query) }
                let descMatch = (recipe.description ?? "").normalizedForSearch().contains(query)
                let countryMatch = (recipe.country ?? "").normalizedForSearch().contains(query)
                let instrMatch = recipe.instructions.normalizedForSearch().contains(query)
                return nameMatch || ingMatch || spiceMatch || equipMatch || descMatch || countryMatch || instrMatch
            }
        }

        result = result.filter { $0.category != "menu_only" && $0.isSecondary != true }
        result = result.filter { $0.title != "Nom de la recette" }

        filteredRecipes = result
    }

    func toggleFavorite(for recipe: Recipe) {
        guard let id = recipe.id else { return }
        favorites.toggleFavorite(recipeId: id)
        if let idx = recipes.firstIndex(where: { $0.id == id }) {
            recipes[idx].isFavorite = favorites.isFavorite(recipeId: id)
        }
        applyFilters()
    }

    func saveHeader() async {
        do {
            var settings = AppSettings()
            settings.header = headerData
            try await self.settings.saveSettings(settings)
            isEditingHeader = false
        } catch {
            errorMessage = "Erreur de sauvegarde: \(error.localizedDescription)"
            showError = true
        }
    }

    var displayRecipeCount: Int {
        recipes.filter { $0.category != "menu_only" && $0.isSecondary != true }.count
    }
}
