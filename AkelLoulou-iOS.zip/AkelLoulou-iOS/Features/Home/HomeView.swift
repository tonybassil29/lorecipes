import SwiftUI

struct HomeView: View {
    @Bindable var viewModel: HomeViewModel
    @Binding var path: NavigationPath
    var isAdmin: Bool

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                headerSection
                filterSection
                resultsSection
            }
        }
        .background(Color.bgMain)
        .navigationTitle("Recettes")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if isAdmin {
                    Button("Éditer") {
                        viewModel.isEditingHeader.toggle()
                    }
                    .foregroundStyle(.accentPrimary)
                }
            }
        }
        .task {
            await viewModel.loadRecipes()
            await viewModel.loadHeader()
        }
        .onChange(of: viewModel.searchQuery) { _, _ in
            viewModel.applyFilters()
        }
        .onChange(of: viewModel.activeFilter) { _, _ in
            viewModel.applyFilters()
        }
        .onChange(of: viewModel.activeCountry) { _, _ in
            viewModel.applyFilters()
        }
        .onChange(of: viewModel.visibilityFilter) { _, _ in
            viewModel.applyFilters()
        }
        .alert("Erreur", isPresented: $viewModel.showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Une erreur est survenue")
        }
        .sheet(isPresented: $viewModel.showSuggestionSheet) {
            RecipeSuggestionView(onClose: { viewModel.showSuggestionSheet = false })
        }
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 8) {
                Rectangle()
                    .frame(width: 28, height: 1)
                    .foregroundStyle(.accentGold)
                Text(viewModel.headerData.topBadge)
                    .font(.system(size: 11, weight: .medium))
                    .tracking(0.32)
                    .textCase(.uppercase)
                    .foregroundStyle(.accentPrimary)
                Rectangle()
                    .frame(width: 28, height: 1)
                    .foregroundStyle(.accentGold)
            }

            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(viewModel.headerData.titlePart1)
                    .font(.system(size: 42, weight: .medium, design: .serif))
                    .italic()
                Text(viewModel.headerData.titleHighlight)
                    .font(.system(size: 42, weight: .medium, design: .serif))
                    .italic()
                    .gradientText()
                Text("🌸")
                    .font(.system(size: 20))
            }

            Text(viewModel.headerData.subtitle)
                .font(.system(size: 15))
                .foregroundStyle(.textSecondary)
                .lineSpacing(4)

            HStack(spacing: 20) {
                StatItem(value: "\(viewModel.displayRecipeCount)", label: "Recettes")
                Divider().frame(height: 40)
                StatItem(value: "5+", label: "Pays")
                Divider().frame(height: 40)
                StatItem(value: "∞", label: "Amour")
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 24)
    }

    private var filterSection: some View {
        VStack(spacing: 12) {
            HStack(spacing: 8) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.textPlaceholder)
                    TextField("Rechercher une recette, un ingrédient, un pays…", text: $viewModel.searchQuery)
                        .font(.system(size: 13.5))
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color.bgCard)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.borderCard, lineWidth: 1))

                Button {
                    viewModel.showSuggestionSheet = true
                } label: {
                    Text("✦")
                        .font(.system(size: 18))
                        .frame(width: 44, height: 44)
                        .background(Color.bgCard)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.borderCard, lineWidth: 1))
                }
                .accessible(label: "Suggérer une recette")
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    FilterPill(
                        label: viewModel.headerData.filterAllText,
                        emoji: viewModel.headerData.filterAllEmoji,
                        isActive: viewModel.activeFilter == .all
                    ) {
                        viewModel.activeFilter = .all
                    }
                    FilterPill(
                        label: viewModel.headerData.filterPlatText,
                        emoji: viewModel.headerData.filterPlatEmoji,
                        isActive: viewModel.activeFilter == .plat
                    ) {
                        viewModel.activeFilter = .plat
                    }
                    FilterPill(
                        label: viewModel.headerData.filterDessertText,
                        emoji: viewModel.headerData.filterDessertEmoji,
                        isActive: viewModel.activeFilter == .dessert
                    ) {
                        viewModel.activeFilter = .dessert
                    }
                    FilterPill(
                        label: "Favoris",
                        emoji: "♥",
                        isActive: viewModel.activeFilter == .favorite
                    ) {
                        viewModel.activeFilter = .favorite
                    }

                    if !viewModel.availableCountries.isEmpty {
                        Menu {
                            Button("Tous les pays") {
                                viewModel.activeCountry = "all"
                            }
                            ForEach(viewModel.availableCountries, id: \.self) { country in
                                Button(country) {
                                    viewModel.activeCountry = country
                                }
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Text("◯")
                                Text(viewModel.activeCountry == "all" ? "Pays" : viewModel.activeCountry)
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 10))
                            }
                            .font(.system(size: 12, weight: .medium))
                            .tracking(0.06)
                            .textCase(.uppercase)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(viewModel.activeCountry != "all" ? Color.accentPrimary : Color.clear)
                            .foregroundStyle(viewModel.activeCountry != "all" ? Color.white : Color.textSecondary)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(viewModel.activeCountry != "all" ? Color.accentPrimary : Color.borderCard, lineWidth: 1))
                        }
                    }

                    if isAdmin {
                        Menu {
                            Button("Toutes") { viewModel.visibilityFilter = .all }
                            Button("Publiées") { viewModel.visibilityFilter = .visible }
                            Button("Masquées") { viewModel.visibilityFilter = .hidden }
                        } label: {
                            HStack(spacing: 4) {
                                Text(viewModel.visibilityFilter == .all ? "◐ Visibilité" : viewModel.visibilityFilter == .visible ? "● Publiées" : "○ Masquées")
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 10))
                            }
                            .font(.system(size: 12, weight: .medium))
                            .tracking(0.06)
                            .textCase(.uppercase)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(viewModel.visibilityFilter != .all ? Color.textMain : Color.clear)
                            .foregroundStyle(viewModel.visibilityFilter != .all ? Color.bgMain : Color.textSecondary)
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(viewModel.visibilityFilter != .all ? Color.textMain : Color.borderCard, lineWidth: 1))
                        }
                    }
                }
            }

            HStack {
                Text("\(viewModel.filteredRecipes.count) \(viewModel.filteredRecipes.count == 1 ? "recette" : "recettes")")
                    .font(.system(size: 11, weight: .medium))
                    .tracking(0.32)
                    .textCase(.uppercase)
                    .foregroundStyle(.textSecondary)
                Divider()
            }
            .padding(.horizontal, 4)
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    private var resultsSection: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(viewModel.filteredRecipes) { recipe in
                RecipeCard(
                    recipe: recipe,
                    onTap: {
                        if let id = recipe.id {
                            path.append(NavigationDestination.recipe(id))
                        }
                    },
                    onFavoriteTap: {
                        viewModel.toggleFavorite(for: recipe)
                    },
                    isAdmin: isAdmin
                )
            }
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 24)
    }
}

private struct StatItem: View {
    let value: String
    let label: String

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(.system(size: 28, weight: .medium, design: .serif))
                .italic()
                .foregroundStyle(.accentPrimary)
            Text(label)
                .font(.system(size: 10, weight: .medium))
                .tracking(0.28)
                .textCase(.uppercase)
                .foregroundStyle(.textSecondary)
        }
    }
}

private struct FilterPill: View {
    let label: String
    let emoji: String
    let isActive: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Text(emoji)
                    .font(.system(size: 14))
                Text(label)
                    .font(.system(size: 12, weight: .medium))
                    .tracking(0.06)
                    .textCase(.uppercase)
            }
        }
        .pillStyle(isActive: isActive)
        .accessible(label: "Filtrer par \(label)")
    }
}

#Preview {
    NavigationStack {
        HomeView(
            viewModel: HomeViewModel(),
            path: .constant(NavigationPath()),
            isAdmin: false
        )
    }
}
