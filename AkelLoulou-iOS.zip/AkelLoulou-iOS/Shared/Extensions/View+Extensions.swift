import SwiftUI

extension View {
    func cardStyle() -> some View {
        self
            .background(Color.bgCard)
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(
                RoundedRectangle(cornerRadius: 18)
                    .stroke(Color.borderCard, lineWidth: 1)
            )
    }

    func pillStyle(isActive: Bool = false) -> some View {
        self
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(isActive ? Color.textMain : Color.clear)
            .foregroundStyle(isActive ? Color.bgMain : Color.textSecondary)
            .clipShape(Capsule())
            .overlay(
                Capsule()
                    .stroke(isActive ? Color.textMain : Color.borderCard, lineWidth: 1)
            )
    }

    func shimmerButtonStyle() -> some View {
        self
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(
                LinearGradient(colors: [.accentPrimary, .accentSecondary], startPoint: .leading, endPoint: .trailing)
            )
            .foregroundStyle(.white)
            .clipShape(Capsule())
            .shadow(color: .shadowAccent.opacity(0.3), radius: 8, x: 0, y: 4)
    }

    func gradientText() -> some View {
        self
            .foregroundStyle(
                LinearGradient(
                    colors: [.accentPrimary, .accentSecondary, .accentGold],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
    }

    func glassStyle() -> some View {
        self
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(Color.navDivider, lineWidth: 1)
            )
    }

    func accessible(label: String, hint: String? = nil, trait: AccessibilityTraits = .button) -> some View {
        self
            .accessibilityLabel(label)
            .accessibilityHint(hint ?? "")
            .accessibilityAddTraits(trait)
    }
}

struct AnimatedGradientBackground: View {
    @State private var animate = false

    var body: some View {
        LinearGradient(
            colors: [.accentPrimary.opacity(0.1), .accentGold.opacity(0.1)],
            startPoint: animate ? .topLeading : .bottomLeading,
            endPoint: animate ? .bottomTrailing : .topTrailing
        )
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 5).repeatForever(autoreverses: true)) {
                animate.toggle()
            }
        }
    }
}
