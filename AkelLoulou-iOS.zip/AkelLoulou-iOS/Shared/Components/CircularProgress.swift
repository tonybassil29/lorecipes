import SwiftUI

struct CircularProgress: View {
    let percentage: Double
    var size: CGFloat = 48
    var strokeWidth: CGFloat = 4

    private var radius: CGFloat {
        (size - strokeWidth) / 2
    }

    private var circumference: CGFloat {
        radius * 2 * .pi
    }

    private var offset: CGFloat {
        circumference - (percentage / 100) * circumference
    }

    private var color: Color {
        if percentage >= 80 { return .green }
        if percentage >= 60 { return .orange }
        return .accentPrimary
    }

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.borderCard, style: StrokeStyle(lineWidth: strokeWidth))
            Circle()
                .trim(from: 0, to: percentage / 100)
                .stroke(color, style: StrokeStyle(lineWidth: strokeWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 1), value: percentage)
            Text("\(Int(percentage))%")
                .font(.system(size: size * 0.25, weight: .bold))
                .foregroundStyle(.textMain)
        }
        .frame(width: size, height: size)
    }
}

#Preview {
    CircularProgress(percentage: 75)
        .padding()
}
