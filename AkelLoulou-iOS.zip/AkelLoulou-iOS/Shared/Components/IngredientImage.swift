import SwiftUI

struct IngredientImage: View {
    let name: String
    let imageUrl: String?
    let size: CGFloat = 80

    var body: some View {
        ZStack {
            Color.bgCard
                .clipShape(RoundedRectangle(cornerRadius: 14))
            if let urlString = imageUrl, let url = URL(string: urlString) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                            .padding(8)
                    case .failure:
                        fallbackContent
                    @unknown default:
                        fallbackContent
                    }
                }
            } else {
                fallbackContent
            }
        }
        .frame(width: size, height: size)
        .shadow(color: .shadowCard.opacity(0.06), radius: 4, x: 0, y: 2)
    }

    private var fallbackContent: some View {
        Image(systemName: "photo")
            .font(.system(size: 24))
            .foregroundStyle(.textPlaceholder)
    }
}

#Preview {
    IngredientImage(name: "farine", imageUrl: nil)
        .padding()
}
