import SwiftUI

struct AsyncImageView: View {
    let url: URL?
    var contentMode: ContentMode = .fill

    var body: some View {
        AsyncImage(url: url) { phase in
            switch phase {
            case .empty:
                ProgressView()
            case .success(let image):
                image
                    .resizable()
                    .aspectRatio(contentMode: contentMode)
            case .failure:
                Color.bgHover
                    .overlay(
                        Image(systemName: "photo")
                            .foregroundStyle(.textPlaceholder)
                    )
            @unknown default:
                EmptyView()
            }
        }
    }
}

#Preview {
    AsyncImageView(url: URL(string: "https://example.com/image.jpg"))
        .frame(width: 200, height: 200)
}
