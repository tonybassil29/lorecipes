import SwiftUI

struct RecipeCard: View {
    let recipe: Recipe
    let onTap: () -> Void
    let onFavoriteTap: () -> Void
    let isAdmin: Bool

    private var gradientColors: [Color] {
        let gradients: [[Color]] = [
            [.pink.opacity(0.3), .purple.opacity(0.3)],
            [.purple.opacity(0.3), .pink.opacity(0.3)],
            [.orange.opacity(0.3), .pink.opacity(0.3)],
            [.blue.opacity(0.3), .purple.opacity(0.3)],
            [.green.opacity(0.3), .blue.opacity(0.3)],
            [.orange.opacity(0.3), .yellow.opacity(0.3)],
            [.red.opacity(0.3), .orange.opacity(0.3)],
            [.teal.opacity(0.3), .blue.opacity(0.3)],
            [.purple.opacity(0.3), .indigo.opacity(0.3)],
            [.pink.opacity(0.3), .red.opacity(0.3)]
        ]
        let idx = (recipe.title.count + (recipe.ingredients.count * 3)) % gradients.count
        return gradients[idx]
    }

    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 0) {
                ZStack(alignment: .topLeading) {
                    if let imageUrl = recipe.imageUrl, let url = URL(string: imageUrl) {
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .empty:
                                LinearGradient(colors: gradientColors, startPoint: .topLeading, endPoint: .bottomTrailing)
                                    .overlay(ProgressView())
                            case .success(let image):
                                image
                                    .resizable()
                                    .scaledToFill()
                            case .failure:
                                LinearGradient(colors: gradientColors, startPoint: .topLeading, endPoint: .bottomTrailing)
                                    .overlay(Image(systemName: "photo").foregroundStyle(.white))
                            @unknown default:
                                EmptyView()
                            }
                        }
                        .frame(height: 180)
                        .clipped()
                    } else {
                        LinearGradient(colors: gradientColors, startPoint: .topLeading, endPoint: .bottomTrailing)
                            .frame(height: 180)
                            .overlay(Image(systemName: "photo").foregroundStyle(.white))
                    }

                    HStack(spacing: 6) {
                        if let country = recipe.country {
                            Text(country)
                                .font(.system(size: 10, weight: .medium))
                                .tracking(0.12)
                                .textCase(.uppercase)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                        }
                        if recipe.isSecondary == true {
                            Text("Sec.")
                                .font(.system(size: 10, weight: .medium))
                                .tracking(0.12)
                                .textCase(.uppercase)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                        }
                        if isAdmin && recipe.hidden == true {
                            Text("Masqué")
                                .font(.system(size: 10, weight: .medium))
                                .tracking(0.12)
                                .textCase(.uppercase)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(.black.opacity(0.7))
                                .foregroundStyle(.white)
                                .clipShape(Capsule())
                        }
                        Spacer()
                        Button(action: onFavoriteTap) {
                            Image(systemName: recipe.isFavorite == true ? "heart.fill" : "heart")
                                .font(.system(size: 14))
                                .foregroundStyle(recipe.isFavorite == true ? .accentPrimary : .white)
                                .frame(width: 32, height: 32)
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                        }
                        .accessible(label: recipe.isFavorite == true ? "Retirer des favoris" : "Ajouter aux favoris")
                    }
                    .padding(10)

                    HStack {
                        Spacer()
                        Text(recipe.category == "dessert" ? "✦ Dessert" : "◆ Plat")
                            .font(.system(size: 10, weight: .medium))
                            .tracking(0.14)
                            .textCase(.uppercase)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(
                                recipe.category == "dessert"
                                    ? Color.badgeDessertBg
                                    : Color.badgePlatBg
                            )
                            .foregroundStyle(
                                recipe.category == "dessert"
                                    ? Color.badgeDessertText
                                    : Color.badgePlatText
                            )
                            .clipShape(Capsule())
                    }
                    .padding(10)
                    .frame(maxHeight: .infinity, alignment: .bottom)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(recipe.title.htmlStripped())
                        .font(.system(size: 16, weight: .bold, design: .serif))
                        .lineLimit(2)
                        .foregroundStyle(.textMain)
                    if let desc = recipe.description, !desc.isBlank {
                        Text(desc)
                            .font(.system(size: 12))
                            .lineLimit(2)
                            .foregroundStyle(.textSecondary)
                    }
                }
                .padding(12)
            }
        }
        .buttonStyle(.plain)
        .background(Color.bgCard)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.borderCard, lineWidth: 1)
        )
        .shadow(color: .shadowCard.opacity(0.06), radius: 8, x: 0, y: 4)
        .accessible(label: "Recette \(recipe.title)")
    }
}

#Preview {
    RecipeCard(
        recipe: Recipe(
            id: "1",
            title: "Tarte aux Pommes",
            description: "Une tarte classique et délicieuse",
            ingredients: ["pommes", "sucre", "pâte"],
            spices: nil,
            equipment: nil,
            instructions: "1. Préparer la pâte\n2. Ajouter les pommes",
            category: "dessert",
            servings: 6,
            showPortions: true,
            imageUrl: nil,
            country: "France",
            hidden: false,
            isSecondary: false,
            isFavorite: true,
            relatedRecipes: nil,
            createdAt: nil,
            updatedAt: nil
        ),
        onTap: {},
        onFavoriteTap: {},
        isAdmin: false
    )
    .padding()
    .background(Color.bgMain)
}
