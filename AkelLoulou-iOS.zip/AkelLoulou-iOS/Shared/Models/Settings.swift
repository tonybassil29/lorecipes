import Foundation

struct AppSettings: Codable, Sendable {
    var header: HeaderSettings?
    var about: AboutSettings?
    var appLogoUrl: String?
    var appFaviconUrl: String?
    var customIngredientImages: [String: String]?
    var categoryEmojis: [String: String]?

    enum CodingKeys: String, CodingKey {
        case header
        case about
        case appLogoUrl = "app_logo_url"
        case appFaviconUrl = "app_favicon_url"
        case customIngredientImages = "custom_ingredient_images"
        case categoryEmojis = "category_emojis"
    }
}

struct HeaderSettings: Codable, Sendable {
    var topBadge: String = "Cuisine Maison"
    var titlePart1: String = "Akel "
    var titleHighlight: String = "Loulou"
    var subtitle: String = "Des recettes simples, gourmandes & maison"
    var recipeCountEmoji: String = "📖"
    var recipeCountText: String = "recettes dans le carnet"
    var navRecipesEmoji: String = "🍽️"
    var navRecipesText: String = "Recettes"
    var navAboutEmoji: String = "🌷"
    var navAboutText: String = "À propos"
    var navGalleryEmoji: String = "📸"
    var navGalleryText: String = "Galerie"
    var navFrigoEmoji: String = "🧊"
    var navFrigoText: String = "Frigo Magique"
    var navMenuEmoji: String = "📅"
    var navMenuText: String = "Menu"
    var navAddEmoji: String = "➕"
    var navAddText: String = "Ajouter une recette"
    var filterAllEmoji: String = "✨"
    var filterAllText: String = "Tout"
    var filterDessertEmoji: String = "🍰"
    var filterDessertText: String = "Desserts"
    var filterPlatEmoji: String = "🍽️"
    var filterPlatText: String = "Plats"
}

struct AboutSettings: Codable, Sendable {
    var imageUrl: String = "https://i.imgur.com/xbtM02c.jpg"
    var badgeText: String = "🌸 Akel Loulou"
    var titlePart1: String = "La "
    var titleHighlight: String = "Cheffe"
    var titlePart2: String = "de la famille"
    var description: String = "Cuisinière du monde entier, créatrice de bonheur et meilleure cousine au monde, sans aucun doute."
    var stat1Num: String = "19"
    var stat1Label: String = "Recettes"
    var stat2Num: String = "5+"
    var stat2Label: String = "Pays"
    var stat3Num: String = "∞"
    var stat3Label: String = "Amour"
    var storyTitle: String = "✦ Son histoire"
    var storyText: String = "Derrière chaque recette de ce carnet se cache la meilleure cousine au monde d'une gentillesse sans égale et d'un talent culinaire qui laisse vraiment sans voix.\n\nElle voyage à travers les saveurs du monde entier sans jamais quitter sa cuisine. Du Liban au Japon, de l'Inde à l'Amérique, chaque plat qu'elle prépare est une explosion de goûts, de couleurs et d'amour.\n\nSes recettes sont bien plus que des instructions ce sont des moments de bonheur partagés, préparés avec le cœur pour les gens qu'elle aime. Trop trop bon. 💛\n\nJe suis obligée de cuisiner pour mon gros cousin"
    var quote: String = "La cuisine, c'est l'amour qu'on peut goûter. Chaque plat préparé avec le cœur devient un souvenir que l'on garde toute sa vie."
    var quoteAuthor: String = "La Cheffe 🌸"
}

enum AdminTab: String, Sendable {
    case site = "site"
    case gallery = "gallery"
    case manual = "manual"
}

enum SortKey: String, Sendable {
    case newest = "newest"
    case oldest = "oldest"
    case title = "title"
    case category = "category"
}
