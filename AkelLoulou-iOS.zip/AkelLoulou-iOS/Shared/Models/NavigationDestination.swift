import Foundation

enum NetworkError: Error, LocalizedError {
    case invalidURL
    case invalidResponse
    case decodingError(Error)
    case serverError(Int, String)
    case noData
    case uploadFailed(String)
    case unauthorized
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid URL"
        case .invalidResponse: return "Invalid response from server"
        case .decodingError(let err): return "Decoding error: \(err.localizedDescription)"
        case .serverError(let code, let msg): return "Server error \(code): \(msg)"
        case .noData: return "No data received"
        case .uploadFailed(let msg): return "Upload failed: \(msg)"
        case .unauthorized: return "Unauthorized"
        case .unknown(let err): return "Unknown error: \(err.localizedDescription)"
        }
    }
}

enum AppError: Error, LocalizedError {
    case recipeNotFound
    case adminNotAuthenticated
    case invalidInput(String)
    case imageProcessingFailed

    var errorDescription: String? {
        switch self {
        case .recipeNotFound: return "Recipe not found"
        case .adminNotAuthenticated: return "Admin authentication required"
        case .invalidInput(let msg): return "Invalid input: \(msg)"
        case .imageProcessingFailed: return "Image processing failed"
        }
    }
}
