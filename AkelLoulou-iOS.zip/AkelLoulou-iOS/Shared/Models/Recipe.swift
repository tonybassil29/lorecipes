import Foundation

struct Recipe: Identifiable, Codable, Sendable, Hashable {
    let id: String?
    var title: String
    var description: String?
    var ingredients: [String]
    var spices: [String]?
    var equipment: [EquipmentItem]?
    var instructions: String
    var category: String
    var servings: Int
    var showPortions: Bool?
    var imageUrl: String?
    var country: String?
    var hidden: Bool?
    var isSecondary: Bool?
    var isFavorite: Bool?
    var relatedRecipes: [RelatedRecipe]?
    var createdAt: String?
    var updatedAt: String?

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case description
        case ingredients
        case spices
        case equipment
        case instructions
        case category
        case servings
        case showPortions = "show_portions"
        case imageUrl = "image_url"
        case country
        case hidden
        case isSecondary = "is_secondary"
        case isFavorite = "is_favorite"
        case relatedRecipes = "related_recipes"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }

    var isVisible: Bool {
        hidden != true
    }

    var isMainRecipe: Bool {
        isSecondary != true && category != "menu_only"
    }

    var instructionsList: [String] {
        instructions.split(separator: "\n").map { String($0) }.filter { !$0.isEmpty }
    }
}

struct EquipmentItem: Codable, Sendable, Hashable {
    let name: String
    let imageUrl: String?

    enum CodingKeys: String, CodingKey {
        case name
        case imageUrl = "image_url"
    }
}

struct RelatedRecipe: Codable, Sendable, Hashable {
    let id: String
    let title: String
}

struct GalleryImage: Identifiable, Codable, Sendable, Hashable {
    let id: String
    var url: String
    var createdAt: String?
    var recipeId: String?
    var name: String?

    enum CodingKeys: String, CodingKey {
        case id
        case url
        case createdAt = "created_at"
        case recipeId = "recipe_id"
        case name
    }
}

struct RecipeSuggestion: Identifiable, Codable, Sendable {
    let id: String
    let userName: String?
    let recipeName: String
    let description: String?
    let createdAt: String?

    enum CodingKeys: String, CodingKey {
        case id
        case userName = "user_name"
        case recipeName = "recipe_name"
        case description
        case createdAt = "created_at"
    }
}

struct PushSubscription: Codable, Sendable {
    let endpoint: String
    let keys: PushKeys
    let userAgent: String?
    let platform: String?
    let lastSeenAt: String?

    enum CodingKeys: String, CodingKey {
        case endpoint
        case keys
        case userAgent = "user_agent"
        case platform
        case lastSeenAt = "last_seen_at"
    }
}

struct PushKeys: Codable, Sendable {
    let p256dh: String
    let auth: String
}

struct WeekMenu: Codable, Sendable {
    var days: [DayMenu]

    init() {
        self.days = WeekMenu.defaultDays
    }

    static var defaultDays: [DayMenu] {
        ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"].map { DayMenu(day: $0) }
    }
}

struct DayMenu: Identifiable, Codable, Sendable {
    let id: String
    var day: String
    var midi: Recipe?
    var gouter: Recipe?
    var soir: Recipe?

    init(day: String, midi: Recipe? = nil, gouter: Recipe? = nil, soir: Recipe? = nil) {
        self.id = day
        self.day = day
        self.midi = midi
        self.gouter = gouter
        self.soir = soir
    }
}

enum MealType: String, Codable, Sendable, CaseIterable {
    case midi = "midi"
    case gouter = "gouter"
    case soir = "soir"

    var displayName: String {
        switch self {
        case .midi: return "Midi"
        case .gouter: return "Goûter"
        case .soir: return "Soir"
        }
    }
}

enum NavigationDestination: Hashable, Sendable {
    case home
    case recipe(String)
    case gallery
    case about
    case frigoMagique
    case menuPlanner
    case adminDashboard
    case recipeManager
    case addRecipe
    case editRecipe(String)
    case adminLogin
    case recipeSuggestion
}

enum CategoryFilter: String, Sendable {
    case all = "all"
    case plat = "plat"
    case dessert = "dessert"
    case favorite = "favorite"
}

enum VisibilityFilter: String, Sendable {
    case all = "all"
    case visible = "visible"
    case hidden = "hidden"
}
