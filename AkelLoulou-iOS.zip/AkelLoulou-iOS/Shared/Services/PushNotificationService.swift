import Foundation
import UserNotifications

@Observable
final class PushNotificationService {
    static let shared = PushNotificationService()

    var isSubscribed = false
    var isLoading = false

    private let supabaseService = SupabaseService.shared
    private let vapidPublicKey = "BFu-UobSt80dQQBx5Q8h2F2cW9kyZOTb-N0dnZGoaIjDPh7GJ2Z9cj0Kr08aJJb-OIT6D_sllih4CSjcyMsJdiQ"

    private init() {}

    func requestAuthorization() async -> Bool {
        let center = UNUserNotificationCenter.current()
        do {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            return granted
        } catch {
            return false
        }
    }

    func checkSubscriptionStatus() async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        isSubscribed = settings.authorizationStatus == .authorized
    }

    func registerForPushNotifications() async {
        isLoading = true
        defer { isLoading = false }
        let granted = await requestAuthorization()
        if granted {
            await UIApplication.shared.registerForRemoteNotifications()
            isSubscribed = true
        }
    }

    func unregister() async {
        isLoading = true
        defer { isLoading = false }
        UIApplication.shared.unregisterForRemoteNotifications()
        isSubscribed = false
    }
}
