import Foundation

final class SupabaseService {
    static let shared = SupabaseService()

    private let baseURL = "https://dkxtmhlrewmueuwcxeki.supabase.co"
    private let apiKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRreHRtaGxyZXdtdWV1d2N4ZWtpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM1MDAxODUsImV4cCI6MjA4OTA3NjE4NX0.bwf9Bqt0N7QCV7sX9SHQPOqt2G8CGJv6WSmrp-iqrW0"

    private var headers: [String: String] {
        [
            "apikey": apiKey,
            "Authorization": "Bearer \(apiKey)",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        ]
    }

    private init() {}

    // MARK: - Recipes

    func fetchRecipes(includeHidden: Bool = false, includeSecondary: Bool = false) async throws -> [Recipe] {
        var url = URL(string: "\(baseURL)/rest/v1/recipes?select=*&order=created_at.desc,id.desc")!
        if !includeHidden {
            url = URL(string: "\(baseURL)/rest/v1/recipes?or=(hidden.eq.false,hidden.is.null)&select=*&order=created_at.desc,id.desc")!
        }
        if !includeSecondary {
            url = URL(string: "\(baseURL)/rest/v1/recipes?or=(is_secondary.eq.false,is_secondary.is.null)&select=*&order=created_at.desc,id.desc")!
        }
        let (data, response) = try await URLSession.shared.data(for: makeRequest(url: url))
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.invalidResponse
        }
        do {
            return try JSONDecoder().decode([Recipe].self, from: data)
        } catch {
            throw NetworkError.decodingError(error)
        }
    }

    func addRecipe(_ recipe: Recipe) async throws -> Recipe {
        let url = URL(string: "\(baseURL)/rest/v1/recipes")!
        var request = makeRequest(url: url, method: "POST")
        let body = try JSONEncoder().encode(recipe)
        request.httpBody = body
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NetworkError.invalidResponse
        }
        do {
            let recipes = try JSONDecoder().decode([Recipe].self, from: data)
            return recipes.first!
        } catch {
            throw NetworkError.decodingError(error)
        }
    }

    func updateRecipe(id: String, _ recipe: Recipe) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/recipes?id=eq.\(id)")!
        var request = makeRequest(url: url, method: "PATCH")
        let body = try JSONEncoder().encode(recipe)
        request.httpBody = body
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw NetworkError.invalidResponse
        }
    }

    func deleteRecipe(id: String) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/recipes?id=eq.\(id)")!
        let request = makeRequest(url: url, method: "DELETE")
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw NetworkError.invalidResponse
        }
    }

    // MARK: - Gallery

    func fetchGalleryImages() async throws -> [GalleryImage] {
        let url = URL(string: "\(baseURL)/rest/v1/gallery?select=*&order=created_at.desc")!
        let (data, response) = try await URLSession.shared.data(for: makeRequest(url: url))
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.invalidResponse
        }
        do {
            return try JSONDecoder().decode([GalleryImage].self, from: data)
        } catch {
            throw NetworkError.decodingError(error)
        }
    }

    func addGalleryImage(url imageUrl: String) async throws -> GalleryImage {
        let url = URL(string: "\(baseURL)/rest/v1/gallery")!
        var request = makeRequest(url: url, method: "POST")
        let body = try JSONEncoder().encode(["url": imageUrl])
        request.httpBody = body
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NetworkError.invalidResponse
        }
        do {
            let images = try JSONDecoder().decode([GalleryImage].self, from: data)
            return images.first!
        } catch {
            throw NetworkError.decodingError(error)
        }
    }

    func deleteGalleryImage(id: String) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/gallery?id=eq.\(id)")!
        let request = makeRequest(url: url, method: "DELETE")
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw NetworkError.invalidResponse
        }
    }

    func updateGalleryImageRecipe(id: String, recipeId: String?) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/gallery?id=eq.\(id)")!
        var request = makeRequest(url: url, method: "PATCH")
        let body = try JSONEncoder().encode(["recipe_id": recipeId])
        request.httpBody = body
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw NetworkError.invalidResponse
        }
    }

    // MARK: - Settings

    func fetchSetting(key: String) async throws -> [String: Any]? {
        let url = URL(string: "\(baseURL)/rest/v1/settings?key=eq.\(key)&select=value&limit=1")!
        let (data, response) = try await URLSession.shared.data(for: makeRequest(url: url))
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.invalidResponse
        }
        do {
            let arr = try JSONSerialization.jsonObject(with: data) as? [[String: Any]]
            return arr?.first?["value"] as? [String: Any]
        } catch {
            throw NetworkError.decodingError(error)
        }
    }

    func upsertSetting(key: String, value: Any) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/settings")!
        var request = makeRequest(url: url, method: "POST")
        let body = try JSONSerialization.data(withJSONObject: ["key": key, "value": value])
        request.httpBody = body
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NetworkError.invalidResponse
        }
    }

    // MARK: - Suggestions

    func fetchSuggestions() async throws -> [RecipeSuggestion] {
        let url = URL(string: "\(baseURL)/rest/v1/recipe_suggestions?select=*&order=created_at.desc")!
        let (data, response) = try await URLSession.shared.data(for: makeRequest(url: url))
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.invalidResponse
        }
        do {
            return try JSONDecoder().decode([RecipeSuggestion].self, from: data)
        } catch {
            throw NetworkError.decodingError(error)
        }
    }

    func addSuggestion(_ suggestion: RecipeSuggestion) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/recipe_suggestions")!
        var request = makeRequest(url: url, method: "POST")
        let body = try JSONEncoder().encode(suggestion)
        request.httpBody = body
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NetworkError.invalidResponse
        }
    }

    func deleteSuggestion(id: String) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/recipe_suggestions?id=eq.\(id)")!
        let request = makeRequest(url: url, method: "DELETE")
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw NetworkError.invalidResponse
        }
    }

    // MARK: - Push Subscriptions

    func upsertPushSubscription(_ subscription: PushSubscription) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/push_subscriptions")!
        var request = makeRequest(url: url, method: "POST")
        request.setValue("resolution=merge-duplicates", forHTTPHeaderField: "Prefer")
        let body = try JSONEncoder().encode(subscription)
        request.httpBody = body
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 else {
            throw NetworkError.invalidResponse
        }
    }

    func deletePushSubscription(endpoint: String) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/push_subscriptions?endpoint=eq.\(endpoint.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? endpoint)")!
        let request = makeRequest(url: url, method: "DELETE")
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw NetworkError.invalidResponse
        }
    }

    // MARK: - Private

    private func makeRequest(url: URL, method: String = "GET") -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        for (key, value) in headers {
            request.setValue(value, forHTTPHeaderField: key)
        }
        return request
    }
}
