import Foundation
import UIKit

final class CloudinaryService {
    static let shared = CloudinaryService()

    private let cloudName = "dtv0rzcra"
    private let uploadPreset = "mon_preset_image"

    private init() {}

    func uploadImage(_ image: UIImage) async throws -> String {
        guard let imageData = image.jpegData(compressionQuality: 0.85) else {
            throw NetworkError.imageProcessingFailed
        }
        return try await uploadData(imageData, filename: "image.jpg", mimeType: "image/jpeg")
    }

    func uploadImageData(_ data: Data, filename: String = "image.png", mimeType: String = "image/png") async throws -> String {
        return try await uploadData(data, filename: filename, mimeType: mimeType)
    }

    private func uploadData(_ data: Data, filename: String, mimeType: String) async throws -> String {
        let url = URL(string: "https://api.cloudinary.com/v1_1/\(cloudName)/image/upload")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"upload_preset\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(uploadPreset)\r\n".data(using: .utf8)!)
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NetworkError.uploadFailed("HTTP \( (response as? HTTPURLResponse)?.statusCode ?? 0)")
        }

        do {
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            guard let urlString = json?["secure_url"] as? String else {
                throw NetworkError.uploadFailed("No secure_url in response")
            }
            return urlString.replacingOccurrences(of: "/upload/", with: "/upload/w_1200,c_limit,q_auto,f_auto/")
        } catch {
            throw NetworkError.decodingError(error)
        }
    }
}
