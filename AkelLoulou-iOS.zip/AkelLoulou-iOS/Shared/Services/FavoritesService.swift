import Foundation

final class FavoritesService {
    static let shared = FavoritesService()

    private let userDefaults = UserDefaults.standard
    private let key = "recipe_favorites"

    private init() {}

    var favorites: [String] {
        get {
            userDefaults.stringArray(forKey: key) ?? []
        }
        set {
            userDefaults.set(newValue, forKey: key)
        }
    }

    func isFavorite(recipeId: String) -> Bool {
        favorites.contains(recipeId)
    }

    func toggleFavorite(recipeId: String) {
        var current = favorites
        if current.contains(recipeId) {
            current.removeAll { $0 == recipeId }
        } else {
            current.append(recipeId)
        }
        favorites = current
    }

    func setFavorite(recipeId: String, isFavorite: Bool) {
        var current = favorites
        if isFavorite {
            if !current.contains(recipeId) {
                current.append(recipeId)
            }
        } else {
            current.removeAll { $0 == recipeId }
        }
        favorites = current
    }
}
