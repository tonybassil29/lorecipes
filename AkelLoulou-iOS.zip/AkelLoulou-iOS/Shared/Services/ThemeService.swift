import Foundation
import SwiftUI

@Observable
final class ThemeService {
    static let shared = ThemeService()

    private let userDefaults = UserDefaults.standard
    private let key = "isDarkMode"

    var isDarkMode: Bool {
        didSet {
            userDefaults.set(isDarkMode, forKey: key)
        }
    }

    var colorScheme: ColorScheme {
        isDarkMode ? .dark : .light
    }

    private init() {
        self.isDarkMode = userDefaults.bool(forKey: key)
    }

    func toggle() {
        isDarkMode.toggle()
    }
}

extension Color {
    static let accentPrimary = Color("AccentPrimary")
    static let accentSecondary = Color("AccentSecondary")
    static let accentGold = Color("AccentGold")
    static let accentDeep = Color("AccentDeep")
    static let textMain = Color("TextMain")
    static let textSecondary = Color("TextSecondary")
    static let textPlaceholder = Color("TextPlaceholder")
    static let textMuted = Color("TextMuted")
    static let bgMain = Color("BgMain")
    static let bgCard = Color("BgCard")
    static let bgHover = Color("BgHover")
    static let bgInput = Color("BgInput")
    static let borderCard = Color("BorderCard")
    static let borderInput = Color("BorderInput")
    static let badgeDessertBg = Color("BadgeDessertBg")
    static let badgeDessertText = Color("BadgeDessertText")
    static let badgePlatBg = Color("BadgePlatBg")
    static let badgePlatText = Color("BadgePlatText")
    static let shadowCard = Color("ShadowCard")
    static let shadowAccent = Color("ShadowAccent")
    static let navText = Color("NavText")
    static let navTextSoft = Color("NavTextSoft")
    static let navDivider = Color("NavDivider")
    static let navIconBg = Color("NavIconBg")
    static let navAccent = Color("NavAccent")
}
