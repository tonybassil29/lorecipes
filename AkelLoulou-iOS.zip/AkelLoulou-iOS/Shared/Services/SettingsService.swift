import Foundation

final class SettingsService {
    static let shared = SettingsService()

    private let supabase = SupabaseService.shared
    private let userDefaults = UserDefaults.standard
    private let cacheKey = "app_settings_cache"
    private let cacheTimestampKey = "app_settings_cache_time"
    private let cacheTTL: TimeInterval = 300 // 5 minutes

    private init() {}

    func loadSettings() async -> AppSettings {
        let now = Date().timeIntervalSince1970
        if let cachedData = userDefaults.data(forKey: cacheKey),
           let timestamp = userDefaults.object(forKey: cacheTimestampKey) as? TimeInterval,
           now - timestamp < cacheTTL {
            do {
                return try JSONDecoder().decode(AppSettings.self, from: cachedData)
            } catch {
                // fallthrough to fetch
            }
        }

        var settings = AppSettings()
        do {
            if let headerDict = try await supabase.fetchSetting(key: "header") {
                let data = try JSONSerialization.data(withJSONObject: headerDict)
                settings.header = try JSONDecoder().decode(HeaderSettings.self, from: data)
            }
            if let aboutDict = try await supabase.fetchSetting(key: "about") {
                let data = try JSONSerialization.data(withJSONObject: aboutDict)
                settings.about = try JSONDecoder().decode(AboutSettings.self, from: data)
            }
            if let logoDict = try await supabase.fetchSetting(key: "app_logo_url") {
                settings.appLogoUrl = logoDict["value"] as? String
            }
            if let faviconDict = try await supabase.fetchSetting(key: "app_favicon_url") {
                settings.appFaviconUrl = faviconDict["value"] as? String
            }
            if let customImagesDict = try await supabase.fetchSetting(key: "custom_ingredient_images") {
                settings.customIngredientImages = customImagesDict["value"] as? [String: String]
            }
            if let emojisDict = try await supabase.fetchSetting(key: "category_emojis") {
                settings.categoryEmojis = emojisDict["value"] as? [String: String]
            }
        } catch {
            print("Error loading settings: \(error)")
        }

        // Cache
        do {
            let data = try JSONEncoder().encode(settings)
            userDefaults.set(data, forKey: cacheKey)
            userDefaults.set(now, forKey: cacheTimestampKey)
        } catch {
            print("Error caching settings: \(error)")
        }

        return settings
    }

    func saveSettings(_ settings: AppSettings) async throws {
        if let header = settings.header {
            try await supabase.upsertSetting(key: "header", value: header)
        }
        if let about = settings.about {
            try await supabase.upsertSetting(key: "about", value: about)
        }
        // Update cache
        do {
            let data = try JSONEncoder().encode(settings)
            userDefaults.set(data, forKey: cacheKey)
            userDefaults.set(Date().timeIntervalSince1970, forKey: cacheTimestampKey)
        } catch {
            print("Error caching settings: \(error)")
        }
    }

    func loadHeaderSettings() async -> HeaderSettings {
        let settings = await loadSettings()
        return settings.header ?? HeaderSettings()
    }

    func loadAboutSettings() async -> AboutSettings {
        let settings = await loadSettings()
        return settings.about ?? AboutSettings()
    }
}
