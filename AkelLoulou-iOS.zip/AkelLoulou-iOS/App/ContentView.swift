import SwiftUI

struct ContentView: View {
    @State private var path = NavigationPath()
    @State private var isAdmin = false
    @State private var isAdminAuthenticated = false
    @State private var selectedTab: NavigationDestination = .home
    @State private var showSuggestionSheet = false

    private let theme = ThemeService.shared
    private let favorites = FavoritesService.shared

    var body: some View {
        NavigationStack(path: $path) {
            TabView(selection: tabBinding) {
                HomeContainer(path: $path, isAdmin: isAdmin)
                    .tabItem {
                        Label("Recettes", systemImage: "fork.knife")
                    }
                    .tag(NavigationDestination.home)

                FrigoMagiqueContainer(path: $path)
                    .tabItem {
                        Label("Frigo", systemImage: "refrigerator")
                    }
                    .tag(NavigationDestination.frigoMagique)

                MenuPlannerContainer(path: $path, isAdmin: isAdmin)
                    .tabItem {
                        Label("Menu", systemImage: "calendar")
                    }
                    .tag(NavigationDestination.menuPlanner)

                GalleryContainer(path: $path, isAdmin: isAdmin)
                    .tabItem {
                        Label("Galerie", systemImage: "photo.on.rectangle")
                    }
                    .tag(NavigationDestination.gallery)

                AboutContainer(isAdmin: isAdmin)
                    .tabItem {
                        Label("À propos", systemImage: "info.circle")
                    }
                    .tag(NavigationDestination.about)
            }
            .tint(.accentPrimary)
            .navigationDestination(for: NavigationDestination.self) { destination in
                switch destination {
                case .recipe(let id):
                    RecipeDetailContainer(recipeId: id, path: $path, isAdmin: isAdmin)
                case .addRecipe:
                    AddRecipeContainer(path: $path, isAdmin: isAdmin)
                case .editRecipe(let id):
                    AddRecipeContainer(path: $path, isAdmin: isAdmin, editingRecipeId: id)
                case .adminLogin:
                    AdminLoginView(onLogin: {
                        isAdminAuthenticated = true
                        isAdmin = true
                        path.removeLast()
                    })
                case .adminDashboard:
                    AdminDashboardContainer(path: $path, isAdmin: isAdmin, onLogout: handleLogout)
                case .recipeManager:
                    RecipeManagerContainer(path: $path, isAdmin: isAdmin)
                case .recipeSuggestion:
                    RecipeSuggestionView(onClose: { path.removeLast() })
                default:
                    EmptyView()
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    HStack(spacing: 12) {
                        Button {
                            theme.toggle()
                        } label: {
                            Image(systemName: theme.isDarkMode ? "moon.fill" : "sun.max.fill")
                                .foregroundStyle(.textMain)
                        }
                        .accessible(label: theme.isDarkMode ? "Mode clair" : "Mode sombre")

                        if !isAdmin {
                            Button {
                                path.append(NavigationDestination.adminLogin)
                            } label: {
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 14))
                                    .foregroundStyle(.textPlaceholder.opacity(0.5))
                            }
                            .accessible(label: "Espace Admin")
                        } else {
                            Menu {
                                Button {
                                    path.append(NavigationDestination.addRecipe)
                                } label: {
                                    Label("Nouvelle recette", systemImage: "plus")
                                }
                                Button {
                                    path.append(NavigationDestination.recipeManager)
                                } label: {
                                    Label("Gérer les recettes", systemImage: "square.grid.2x2")
                                }
                                Button {
                                    path.append(NavigationDestination.adminDashboard)
                                } label: {
                                    Label("Statistiques", systemImage: "chart.bar")
                                }
                                Divider()
                                Button(role: .destructive) {
                                    handleLogout()
                                } label: {
                                    Label("Déconnexion", systemImage: "arrow.right.square")
                                }
                            } label: {
                                Text("Admin")
                                    .font(.system(size: 12, weight: .medium))
                                    .tracking(0.06)
                                    .textCase(.uppercase)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(Color.bgHover)
                                    .clipShape(Capsule())
                                    .foregroundStyle(.accentPrimary)
                            }
                        }
                    }
                }
            }
        }
        .preferredColorScheme(theme.colorScheme)
        .onAppear {
            checkAdminStatus()
        }
    }

    private var tabBinding: Binding<NavigationDestination> {
        Binding(
            get: { selectedTab },
            set: { newValue in
                selectedTab = newValue
            }
        )
    }

    private func checkAdminStatus() {
        // In production, check secure storage
        isAdmin = isAdminAuthenticated
    }

    private func handleLogout() {
        isAdmin = false
        isAdminAuthenticated = false
    }
}

// MARK: - Container Views

struct HomeContainer: View {
    @Binding var path: NavigationPath
    let isAdmin: Bool
    @State private var viewModel = HomeViewModel()

    var body: some View {
        HomeView(viewModel: viewModel, path: $path, isAdmin: isAdmin)
    }
}

struct FrigoMagiqueContainer: View {
    @Binding var path: NavigationPath
    @State private var viewModel = FrigoMagiqueViewModel()

    var body: some View {
        FrigoMagiqueView(viewModel: viewModel, path: $path)
    }
}

struct MenuPlannerContainer: View {
    @Binding var path: NavigationPath
    let isAdmin: Bool
    @State private var viewModel = MenuPlannerViewModel()

    var body: some View {
        MenuPlannerView(viewModel: viewModel, path: $path, isAdmin: isAdmin)
    }
}

struct GalleryContainer: View {
    @Binding var path: NavigationPath
    let isAdmin: Bool
    @State private var viewModel = GalleryViewModel()

    var body: some View {
        GalleryView(viewModel: viewModel, path: $path, isAdmin: isAdmin)
    }
}

struct AboutContainer: View {
    let isAdmin: Bool
    @State private var viewModel = AboutViewModel()

    var body: some View {
        AboutView(viewModel: viewModel, isAdmin: isAdmin)
    }
}

struct RecipeDetailContainer: View {
    let recipeId: String
    @Binding var path: NavigationPath
    let isAdmin: Bool
    @State private var viewModel: RecipeDetailViewModel?
    @State private var isLoading = true
    @State private var errorMessage: String?

    var body: some View {
        Group {
            if let viewModel = viewModel {
                RecipeDetailView(
                    viewModel: viewModel,
                    isAdmin: isAdmin,
                    onEdit: {
                        path.append(NavigationDestination.editRecipe(recipeId))
                    },
                    onDelete: {
                        path.removeLast()
                    },
                    onBack: {
                        path.removeLast()
                    }
                )
            } else if let error = errorMessage {
                Text(error)
                    .foregroundStyle(.red)
                    .padding()
            } else {
                ProgressView("Chargement...")
            }
        }
        .task {
            await loadRecipe()
        }
    }

    private func loadRecipe() async {
        do {
            let recipes = try await SupabaseService.shared.fetchRecipes(includeHidden: isAdmin, includeSecondary: isAdmin)
            if let recipe = recipes.first(where: { $0.id == recipeId }) {
                var r = recipe
                r.isFavorite = FavoritesService.shared.isFavorite(recipeId: recipeId)
                viewModel = RecipeDetailViewModel(recipe: r)
            } else {
                errorMessage = "Recette non trouvée"
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

struct AddRecipeContainer: View {
    @Binding var path: NavigationPath
    let isAdmin: Bool
    var editingRecipeId: String?
    @State private var viewModel: AddRecipeViewModel?

    var body: some View {
        Group {
            if let viewModel = viewModel {
                AddRecipeView(viewModel: viewModel, path: $path)
            } else {
                ProgressView()
            }
        }
        .task {
            if let editingId = editingRecipeId {
                do {
                    let recipes = try await SupabaseService.shared.fetchRecipes(includeHidden: true, includeSecondary: true)
                    if let recipe = recipes.first(where: { $0.id == editingId }) {
                        viewModel = AddRecipeViewModel(initialRecipe: recipe)
                    } else {
                        viewModel = AddRecipeViewModel()
                    }
                } catch {
                    viewModel = AddRecipeViewModel()
                }
            } else {
                viewModel = AddRecipeViewModel()
            }
        }
    }
}

struct AdminDashboardContainer: View {
    @Binding var path: NavigationPath
    let isAdmin: Bool
    let onLogout: () -> Void
    @State private var viewModel = AdminDashboardViewModel()

    var body: some View {
        AdminDashboardView(
            viewModel: viewModel,
            path: $path,
            isAdmin: isAdmin,
            onLogout: onLogout
        )
    }
}

struct RecipeManagerContainer: View {
    @Binding var path: NavigationPath
    let isAdmin: Bool
    @State private var viewModel = RecipeManagerViewModel()

    var body: some View {
        RecipeManagerView(
            viewModel: viewModel,
            path: $path,
            isAdmin: isAdmin
        )
    }
}

#Preview {
    ContentView()
}
