# Akel Loulou — iOS SwiftUI Rebuild

A native iOS SwiftUI rebuild of **Akel Loulou** (Lau Recipes), 100% faithful to the original React web app.

## Project Structure

```
AkelLoulou-iOS/
├── App/
│   ├── AkelLoulouApp.swift      # App entry point & push delegate
│   └── ContentView.swift        # Main navigation shell, TabView, containers
├── Features/
│   ├── Home/
│   │   ├── HomeView.swift       # Recipe grid, search, filters, hero
│   │   └── HomeViewModel.swift  # Load recipes, apply filters, favorites
│   ├── RecipeDetail/
│   │   ├── RecipeDetailView.swift    # Full recipe with ingredients, instructions, portions
│   │   └── RecipeDetailViewModel.swift # Portion scaling, ingredient images, shopping list
│   ├── Gallery/
│   │   ├── GalleryView.swift
│   │   └── GalleryViewModel.swift
│   ├── About/
│   │   ├── AboutView.swift
│   │   └── AboutViewModel.swift
│   ├── FrigoMagique/
│   │   ├── FrigoMagiqueView.swift
│   │   └── FrigoMagiqueViewModel.swift
│   ├── MenuPlanner/
│   │   ├── MenuPlannerView.swift
│   │   └── MenuPlannerViewModel.swift
│   ├── Admin/
│   │   ├── AdminDashboardView.swift
│   │   ├── AdminDashboardViewModel.swift
│   │   ├── RecipeManagerView.swift
│   │   ├── RecipeManagerViewModel.swift
│   │   ├── AddRecipeView.swift
│   │   ├── AddRecipeViewModel.swift
│   │   ├── AdminLoginView.swift
│   │   └── AdminLoginViewModel.swift
│   └── RecipeSuggestion/
│       ├── RecipeSuggestionView.swift
│       └── RecipeSuggestionViewModel.swift
├── Shared/
│   ├── Components/
│   │   ├── RecipeCard.swift
│   │   ├── CircularProgress.swift
│   │   ├── IngredientImage.swift
│   │   └── AsyncImageView.swift
│   ├── Services/
│   │   ├── SupabaseService.swift
│   │   ├── CloudinaryService.swift
│   │   ├── SettingsService.swift
│   │   ├── FavoritesService.swift
│   │   ├── PushNotificationService.swift
│   │   └── ThemeService.swift
│   ├── Extensions/
│   │   ├── String+Extensions.swift
│   │   └── View+Extensions.swift
│   └── Models/
│       ├── Recipe.swift
│       ├── Settings.swift
│       └── NavigationDestination.swift
└── Resources/
    └── Assets.xcassets
```

## Setup Instructions

1. **Open in Xcode**
   - Create a new iOS App project in Xcode
   - Set the target to iOS 17.0+
   - Replace the generated files with the files from this directory
   - Add your own `Assets.xcassets` with the color definitions below

2. **Color Assets (Assets.xcassets)**
   Create the following Color Sets:
   - `AccentPrimary` — Light: #FF6B9D, Dark: #FF87B5
   - `AccentSecondary` — Light: #FFA94D, Dark: #FFB876
   - `AccentGold` — Light: #FFC2E2, Dark: #F5C2DC
   - `AccentDeep` — Light: #C2185B, Dark: #FF6B9D
   - `TextMain` — Light: #1A0A1E, Dark: #FFE0EE
   - `TextSecondary` — Light: #B090A8, Dark: #D5B6CA
   - `TextPlaceholder` — Light: #C8B0C0, Dark: #8A6A82
   - `TextMuted` — Light: #8A6A82, Dark: #B090A8
   - `BgMain` — Light: #FDF6FB, Dark: #14091A
   - `BgCard` — Light: #FFFFFF, Dark: #1F0E26
   - `BgHover` — Light: #FFF0F8, Dark: #2A1438
   - `BgInput` — Light: #FFFFFF, Dark: #2A1438
   - `BorderCard` — Light: #FFEEF4, Dark: #2D1638
   - `BorderInput` — Light: #FFD6EB, Dark: #3D1F4A
   - `BadgeDessertBg` — Light: #FFE4F0, Dark: #2A1830
   - `BadgeDessertText` — Light: #C2185B, Dark: #FF87B5
   - `BadgePlatBg` — Light: #FFF3CD, Dark: #2A2010
   - `BadgePlatText` — Light: #C87800, Dark: #FFB876
   - `ShadowCard` — Light: rgba(255,107,157,0.06), Dark: rgba(0,0,0,0.55)
   - `ShadowAccent` — Light: rgba(255,107,157,0.30), Dark: rgba(255,135,181,0.20)
   - `NavText` — Light: #1A0A1E, Dark: #FFE0EE
   - `NavTextSoft` — Light: #8A6A82, Dark: #B090A8
   - `NavDivider` — Light: rgba(255,107,157,0.18), Dark: rgba(255,135,181,0.18)
   - `NavIconBg` — Light: rgba(255,240,248,0.6), Dark: rgba(255,224,238,0.05)
   - `NavAccent` — Light: #FF6B9D, Dark: #FF87B5

3. **Backend Configuration**
   The app connects to the existing Supabase and Cloudinary backends:
   - Supabase URL: `https://dkxtmhlrewmueuwcxeki.supabase.co`
   - Cloudinary Cloud Name: `dtv0rzcra`
   - Admin password: `4I6#r2p7kZYkpSm`

4. **Build & Run**
   - Select your target device/simulator
   - Press Cmd+R to build and run

## Architecture

- **MVVM** with strict View/ViewModel separation
- **@Observable** (iOS 17+) for all state — no ObservableObject
- **NavigationStack** with typed `NavigationDestination` enum
- **async/await + Task** for all async operations
- **LazyVStack/LazyHStack** for all scrollable lists
- **AsyncImage** with downsampling for all network images
- **Accessibility** labels, hints, and traits on all interactive elements

## Features

- **Home** — Recipe grid with search, category/country/visibility filters, favorites
- **Recipe Detail** — Ingredient images, portion scaling, equipment, instructions, related recipes, share, shopping list
- **Gallery** — Photo gallery with admin upload, link to recipes
- **About** — Chef profile with editable content (admin)
- **Frigo Magique** — AI-powered ingredient matching to find recipes
- **Menu Planner** — Weekly meal planner with shopping list generation and export
- **Admin Dashboard** — Stats, suggestions, logo/favicon management, bulk cleanup
- **Recipe Manager** — Admin table with search, filter, sort, delete
- **Add/Edit Recipe** — Full form with AI generation, image upload, spices, equipment
- **Dark Mode** — System-aware with custom color tokens
- **Push Notifications** — iOS native push registration

## Compliance

- iOS 17+ minimum deployment target
- No deprecated APIs (NavigationView, ObservableObject, GeometryReader for layout)
- Pure SwiftUI — no UIKit except where strictly necessary
